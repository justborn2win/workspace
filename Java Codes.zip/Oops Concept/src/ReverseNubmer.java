
public class ReverseNubmer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int rem=0;
		int rev=0;
		int x=123;
		int c=x;
		while(x>0)
		{
			rem=x%10;
			rev=rem;
			x=x/10;
			System.out.println(rev);
		}
//		if(c==rev)
//		{
//			System.out.println(c+" yes its palidrome");
//		}
//		else
//		{
//			System.out.println("Not a palindrome");
//		}
	}

}
