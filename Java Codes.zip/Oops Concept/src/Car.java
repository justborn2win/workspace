
public class Car {
	String carName;
	String carModel;
	double carPrice;
	int carCapacity;
	
	
	public void setCarDetails(String cName, String cMod, double cPrice, int cCap){
		carName=cName;
		carModel=cMod;
		carPrice=cPrice;
		carCapacity=cCap;
		
	}
	
	public void printCarNamesOnly()
	{
		System.out.println("Car name: "+carName);
		
	}
}	
