package com.ust_global;
import java.util.*;

import javax.ejb.Remote;

@Remote
public interface StudentBeanRemote {
	
	public void addStudent(Student s);
	public Student readStudent(int id);
	public List<Student> readAllStudents();
	public Student updateStudent(int id,String name);
	public Student deleteStudent(int id);

}
