import java.io.*;
import java.util.*;
public class UID {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		HashMap hm=new HashMap();
		
		hm.put(1, "Jesvin");
		hm.put(2, "Sreenath");
		hm.put(3, "Vaishakh");
		hm.put(4, "Clinton");
		hm.put(5, "Keith");
		hm.put(6, "Abhirami");
		hm.put(7, "Nikhil");
		hm.put(8, "Rahul");
		hm.put(9, "Eliza");
		hm.put(10, "Riya");
		hm.put(11, "Anjumol");
		hm.put(12, "Hari");
		hm.put(13, "Fihadh");
		hm.put(14, "Jackson");

	    InputStreamReader isr=new InputStreamReader(System.in);
	    BufferedReader br=new BufferedReader(isr);
	    System.out.println("Enter an ID");
	    int key=Integer.parseInt(br.readLine());
	    
	   if(hm.containsKey(key))
	    {
	    	System.out.println(hm.get(key));
	    }
	   else
	   {
		   System.out.println("Please input a valid ID");
	   }

		
		

	}

}
