package com.ust_global;
import javax.ejb.*;

@Stateless
public class HelloBean implements HelloRemote {
	public String sayHello(String s){
		return "Welcome "+s;
	}

}
