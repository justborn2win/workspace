import java.util.*;


public class TreeSet1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TreeSet hs=new TreeSet();
		
		String s1=new String("Jesvin");
		String s2=new String("Joy");
		String s3=new String("Koshy");
		
		
		hs.add(s1); 
		hs.add(s2); 
		hs.add(s3); 
		
		
		
		System.out.println(hs);

	}

}
