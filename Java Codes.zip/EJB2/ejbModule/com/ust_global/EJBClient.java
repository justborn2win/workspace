package com.ust_global;

import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EJBClient {

	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		HelloRemote h = (HelloRemote) ctx.lookup("HelloBean/remote");
		System.out.println(h.sayHello("Jesvin"));
	}

}
