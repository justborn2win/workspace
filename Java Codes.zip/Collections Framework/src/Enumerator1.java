import java.util.*;
public class Enumerator1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector days=new Vector();
		Enumeration weekdays;
		days.add("Sunday");
		days.add("Monday");
		days.add("Tuesday");
		days.add("Wednesday");
		days.add("Thursday");
		days.add("Friday");
		days.add("Saturday");
		
		weekdays=days.elements();
		while(weekdays.hasMoreElements())
		{
			System.out.println(weekdays.nextElement());
		}
		
		

	}

}
