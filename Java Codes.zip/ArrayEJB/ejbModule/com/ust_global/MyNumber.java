package com.ust_global;

import java.io.Serializable;

public class MyNumber implements Serializable {
	double sum;
	double average;
	
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	
}
