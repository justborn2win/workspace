
public class Pr41 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=7;
		do
		{
			System.out.print(i+" ");
			i=i+7;
		}
		while(i<=70);

	}

}
