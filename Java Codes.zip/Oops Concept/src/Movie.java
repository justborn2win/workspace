
public class Movie {
	
	String nameOfTheMovie;
	String language;
	String nameOfTheHero;
	String nameOfTheHeroine;
	String nameOfTheVillian;
	String durationOfTheMovie;
	
	Movie movie[];
	public void setMovieDetails(String nm, String l, String nH, String nHr, String nV, String dM, Movie m )
	{
		nameOfTheMovie=nm;
		language=l;
		nameOfTheHero=nH;
		nameOfTheHeroine=nHr;
		nameOfTheVillian=nV;
		durationOfTheMovie=dM;
		
	}
	
	public void printMovieDetails()
	{
		System.out.println("Name of the movie: "+nameOfTheMovie);
		System.out.println("Language of the movie: "+language);
		System.out.println("Name of the Hero: "+nameOfTheHero);
		System.out.println("Name of the Heroine: "+nameOfTheHeroine);
		System.out.println("Name of the villian: "+nameOfTheVillian);
		System.out.println("Duration of the movie: "+durationOfTheMovie);
		
		
		System.out.println();
		
	}
	public void whichMovie()
	{
		for(int i=0;i<movie.length;i++)
		{
			if(nameOfTheHero.equalsIgnoreCase("Rajnikanth"));
			{
				System.out.println("Name of the movie: "+nameOfTheMovie);
			}
		}
	}
}
