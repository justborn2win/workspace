package com.ust_global;

public class TestEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee e1=Employee.getInstance();
		e1.name="Jesvin";
		System.out.println(e1.name);
		System.out.println(e1);
		
		Employee e2=Employee.getInstance();
		e2.name="Clinton";
		System.out.println(e2.name);
		System.out.println(e2);

		System.out.println(e1.name);
	}

}
