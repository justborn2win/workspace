
public class Viewers {
	String viewerName;
	String viewerEmailId;
	String viewerFeedbackIsFor;
	String viewerFeedback;
	
	public void setViewerFeedbackDetails(String vName, String vEid, String vFeedbackFor, String vFeedback)
	//method to set feedback details
	{
		viewerName=vName;
		viewerEmailId=vEid;
		viewerFeedbackIsFor=vFeedbackFor;
		viewerFeedback=vFeedback;
		
	}
	
	public void printViewerFeedbackDetails()
	//method to print feedback details
	{
		System.out.println("Viewer feedback details: ");
		System.out.println("Viewer name: "+viewerName);
		System.out.println("Email id: "+viewerEmailId);
		System.out.println("Feedback is regarding: "+viewerFeedbackIsFor);
		System.out.println("Feedback Message: "+viewerFeedback);
	}
	
	public void viewerFeedbackType()
	{
		//checking feedback is for News or not 
		if(viewerFeedbackIsFor.equalsIgnoreCase("News"))
		{
			System.out.println(viewerFeedbackIsFor);
		}
	}
	 
	
}
