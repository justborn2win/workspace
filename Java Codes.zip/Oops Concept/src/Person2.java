public class Person2 {
			
	String name;
	int age;
	
	public void setPersonDetails(String n,int a)
	{
		name=n;
		age=a;
	}
	public void printDetails()
	{
		System.out.println("My name is "+name);
		System.out.println("I am "+age+" years old");
	}
}
