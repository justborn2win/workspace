import java.util.*;
import java.io.*;
public class Color2 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		
			HashMap co=new HashMap();
			
			Col c1=new Col();
			c1.color="Orange";
			c1.shape="Triangle";
			
			Col c2=new Col();
			c2.color="Red";
			c2.shape="Square";
			
			Col c3=new Col();
			c3.color="White";
			c3.shape="Circle";
			
			Col c4=new Col();
			c4.color="Green";
			c4.shape="Polygon";
			
			Col c5=new Col();
			c5.color="Pink";
			c5.shape="Parallelopipe";
			
			Col c6=new Col();
			c6.color="Gray";
			c6.shape="Rhombus";
			
			Col c7=new Col();
			c7.color="Yellow";
			c7.shape="Right Angled Triangle";
			
			Col c8=new Col();
			c8.color="Magenta";
			c8.shape="Cylinder";
			
			Col c9=new Col();
			c9.color="Black";
			c9.shape="Line";
			
			Col c10=new Col();
			c10.color="Rainbow";
			c10.shape="Plane";
		
			co.put(1,c1);
			co.put(2,c2);
			co.put(3,c3);
			co.put(4,c4);
			co.put(5,c5);
			co.put(6,c6);
			co.put(7,c7);
			co.put(8,c8);
			co.put(9,c9);
			co.put(10,c10);
			
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			System.out.println("Enter your favourite color");
			String key=(String)br.readLine();
			
			
			Set keys=co.keySet();
			Iterator it=keys.iterator();
			
			while(it.hasNext())
			{
				int key1=(Integer)it.next();
				Col col2=(Col)co.get(key1);
				
				String cid=col2.color;
				
//				System.out.println("user input "+key);
//				System.out.println("Object color "+cid);
				if(key.equalsIgnoreCase(cid))
				{
					String cc=col2.shape;
					System.out.println(cc);
				}

			}}

	
}

