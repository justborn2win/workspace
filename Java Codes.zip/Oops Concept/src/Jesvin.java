
public class Jesvin {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[]={8,1,5,1,2};
		
		int d=0;
		for(int i=0;i<a.length;i++)
		{	
			int c=0;
			for(int j=0;j<=i;j++)
				{
					if(a[i]==a[j])
					{
						c++;
					}
				}
			
			
			System.out.println(a[i]+" is repeated "+c+" time");
		}
		
		
		
	}
	

}
