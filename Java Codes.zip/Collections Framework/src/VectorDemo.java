import java.util.*;
public class VectorDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector v=new Vector(); //default capacity is 10
		System.out.println(v.capacity());
		
		v.add("Jesvin");
		v.add("Joy");
		v.add("Vaisakh");
		v.add("Riya");
		v.add("Anju");
		v.add("Jackson");
		v.add("Clinton");
		v.add("Rahul");
		v.add("Hari");
		v.add("Fihad");
		v.add("Nikhil");
		v.add("Eliza");
		v.add("Abhirami");
		v.add("Keith");
		
		System.out.println(v.size()); //how many elements are there
		System.out.println(v.capacity());
		System.out.println((String)v.get(0)+ " " +(String)v.get(1));
		
		
		Vector a=new Vector(3); //default capacity is 3
		a.add(1);
		a.add(9);
		a.add(18);
		a.add(27); //4th element
		a.add(36);
		a.add(45);
		a.add(54);
		
		System.out.println(a.size()); //how many elements are there
		System.out.println(a.capacity());
		System.out.println((Integer)a.get(0)+(Integer)a.get(1));
		
		
		
	}

}
