import java.util.*;
public class HashSet1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet hs=new HashSet();
		
		hs.add("one"); //add method returns true
		hs.add("two"); //add method returns true
		hs.add("three"); //add method returns true
		hs.add("two");  // duplicate values are not added, add method returns false 
		hs.add("Three"); // Its character specific, it considers 'three' and 'Three' as different values
		
		System.out.println(hs.add("five"));
		System.out.println(hs);
	}

}
