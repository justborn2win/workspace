
public class Alternate_numbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=0;i<args.length;i=i+2)
		{
			System.out.println(args[i]);
		}
	}

}
