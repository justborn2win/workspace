
public class Pr8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20,c=30;
		int average=(a+b+c)/3;
		System.out.println("Average is: " +average);

	}

}
