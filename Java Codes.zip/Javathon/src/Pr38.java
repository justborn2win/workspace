
public class Pr38 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=5;
		do
		{
			System.out.print(i+" ");
			i=i+5;
		}
		while(i<=25);

	}

}
