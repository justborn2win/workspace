package com.ust.global.vowels;
import java.io.*;
public class VowelFinder {
	
	public void findVowels(String a)
	{
		int count=0;
		for(int i=0;i<a.length();i++)
		{
			if(a.charAt(i)=='a' || a.charAt(i)=='A' || a.charAt(i)=='e' || a.charAt(i)=='E' || a.charAt(i)=='i' || a.charAt(i)=='I' || a.charAt(i)=='o' || a.charAt(i)=='O' || a.charAt(i)== 'u' || a.charAt(i)=='U')
			{
				count++;
				System.out.println(" The word contains vowels "+a.charAt(i));
			}
			
		}
		System.out.println();
		System.out.println("The string has total "+count+" vowels");
	}
}
