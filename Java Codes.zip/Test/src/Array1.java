
public class Array1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int marks[]={75,85,100,65,77,75};
		int sum=0;
		for (int i=0; i<6; i++)
		{
			if (marks[i]%2==1)
				sum=sum+marks[i];			
		}
		System.out.println(sum);

	}

}
