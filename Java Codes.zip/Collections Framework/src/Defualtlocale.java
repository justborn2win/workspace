import java.util.*;


public class Defualtlocale {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
			Locale myLocale=new Locale("jp","JP");
			Locale.setDefault(myLocale);
	
		Locale def=Locale.getDefault();
		System.out.println(def);
		System.out.println(def.getDisplayCountry());
		System.out.println(def.getDisplayLanguage());

	}

}
