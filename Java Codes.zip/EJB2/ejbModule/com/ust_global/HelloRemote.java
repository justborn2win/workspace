package com.ust_global;

import javax.ejb.*;

@Remote
public interface HelloRemote {
	public String sayHello(String s);
}
