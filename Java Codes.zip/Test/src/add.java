
public class add {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=8,f=9,g=7,j=10,k1=3;
		if (i==8)
			i += 8;
			f -= 9;
			g *= 7;
			j /= 10;
			k1 %= 3;
		System.out.println(i);
		System.out.println(f);
		System.out.println(g);
		System.out.println(j);
		System.out.println(k1);

	}

}
