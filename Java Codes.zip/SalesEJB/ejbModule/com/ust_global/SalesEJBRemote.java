package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface SalesEJBRemote {
	public void totalPrice(int id,double qty);
	

}
