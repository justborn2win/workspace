package com.ust_global;

import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ArrayClient {

	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		int a[]={10,20,30};
		ArrayRemote arr = (ArrayRemote) ctx.lookup("ArrayBeans/remote");
		MyNumber mf=arr.ArraySum(a);
		System.out.println("Average is "+mf.average);
		System.out.println("Sum is "+mf.sum);
		
	}

}
