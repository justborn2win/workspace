
public class Program {
	String programName;
	String programType;
	
	
	public void setProgramDetails(String pName, String pType)
	//method to set program details
	{
		programName=pName;
		programType=pType;
	}
	
	public void printProgramDetails()
	//method to print program details
	{
		System.out.println("Program Name: "+programName);
		System.out.println("Program Type: "+programType);
	} 
}
