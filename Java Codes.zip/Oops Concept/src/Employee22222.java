
public class Employee {
	 String employeeId;
	 String employeeFirstName;
	 String employeeLastName;
	 int age;
	 String projectNameWorkingFor;
	 
	 public void setEmployeeDetails(String eId, String eFn, String eLn, int a, String pN)
	 {
		 employeeId=eId;
		 employeeFirstName=eFn;
		 employeeLastName=eLn;
		 age=a;
		 projectNameWorkingFor=pN;
	 }
	 
	 public void printEmployeeDetails()
	 {
		 System.out.println("Employee Id "+employeeId);
		 System.out.println("Employee First name"+employeeFirstName);
		 System.out.println("Emplopyee Last name"+employeeLastName);
		 System.out.println("Employee age "+age);
		 System.out.println("Project working "+projectNameWorkingFor);
		 System.out.println();
	 }
}
