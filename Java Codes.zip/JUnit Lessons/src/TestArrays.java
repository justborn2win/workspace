import org.junit.*;
public class TestArrays {
@Test
public void testCharArray(){
	char c1[]={'a','b','c'};
	char c2[]={'a','b','c'};
	Assert.assertArrayEquals(c1,c2);
}

public void TestDoubleArray() {
	long longArray1[]={100000L,3000000L};
	long longArray2[]={100000L,2000000L};
	Assert.assertArrayEquals(":::Long arrays are not equal in contents:::", longArray1,longArray2);
}
}
