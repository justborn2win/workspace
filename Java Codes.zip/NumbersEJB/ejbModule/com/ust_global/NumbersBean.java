package com.ust_global;

import javax.ejb.*;

@Stateless
public class NumbersBean implements NumbersRemote {

	public String OddorEven(int a) {
		String msg="";
		if(a%2==0)
		{
			msg=a+" is even number";	
		}
		else
		{
			msg=a+" is odd number";
		}
		return msg;
		
		
	}

}
