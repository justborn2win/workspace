package com.ust_global;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class MyUserBean
 */
@Stateless
public class MyUserBean implements MyUserBeanRemote {

    /**
     * Default constructor. 
     */
    public MyUserBean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="UserUnit")
    private EntityManager entityManager;

	@Override
	public boolean validateUsers(String uName, String password) {
		MyUsers s=entityManager.find(MyUsers.class, uName);
		boolean found=false;
		if(s.userName.equals(uName) && s.password.equals(password))
		{
			found=true;
		}
		return found;
	}
}
