package test;

public class Line implements compare{

	@Override
	public void max(double x, double y) {
		// TODO Auto-generated method stub
		if(x>y)
			System.out.println(x+" is a longer line");
		else
			System.out.println(y+" is a longer line");
	}

}
