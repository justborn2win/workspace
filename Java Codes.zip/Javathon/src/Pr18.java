
public class Pr18 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=12, b=20,c=33;
		if(a%3==0)
		{
			System.out.println(a);
		}
		if(b%3==0)
		{
			System.out.println(b);
		}
		if(c%3==0)
		{
			System.out.println(c);
		}

	}

}
