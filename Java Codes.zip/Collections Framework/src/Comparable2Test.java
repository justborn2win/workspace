import java.util.Collections;
import java.util.Vector;


class Customer1 implements Comparable
{
	int id;
	String name;
	String city;
	double salary;
	@Override
	public String toString() {
		String x=id+":"+name+":"+city;
		return x;
	}
	@Override
	public int compareTo(Object o) {
		Customer1 c1=(Customer1)o;
		double sal=c1.salary;
		
		if(this.salary < sal)
			return 1;
		else 
			if(this.salary > sal)
				return -1;
			else
				return 0;
	}
	
	
}

public class Comparable2Test{
	
	public static void main(String[] args) {
		Vector v=new Vector();
		
		Customer1 c1=new Customer1();
		c1.id=100;
		c1.name="Jesvin";
		c1.city="Bangalore";
		c1.salary=12000;
		
		Customer1 c2=new Customer1();
		c2.id=500;
		c2.name="Joy";
		c2.city="Mumbai";
		c2.salary=1100000;
		
		Customer1 c3=new Customer1();
		c3.id=50;
		c3.name="Koshy";
		c3.city="Tiruvalla";
		c3.salary=10000;
		
		v.add(c1);
		v.add(c2);
		v.add(c3);
		
		System.out.println("Before sorting: ");
		System.out.println(v);
		System.out.println();
		
		Collections.sort(v);
		System.out.println("After sorting: ");
		System.out.println(v);
		
		
}}