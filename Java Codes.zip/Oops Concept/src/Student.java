
public class Student {
	String name;
	float eng, maths, cs;
	double average;
	double total;
	
	public void average()
	{	
		total=eng+maths+cs;
		average=total/3.0;
		System.out.println("Name of the student is "+name);
		System.out.println("Marks in English is "+eng);
		System.out.println("Marks in Maths is "+maths);
		System.out.println("Marks in Comp.Science is "+cs);
		System.out.println();
		System.out.println("Total marks is "+total);
		System.out.println("Average mark is "+average);
	}
}
