package com.ust_global;

public interface Command {
	public void execute();
}
