package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Client {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);

		MyEmployeeEJB2Remote ebr = (MyEmployeeEJB2Remote) ctx.lookup("MyEmployeeEJB2/remote");
		List<MyEmployee> employeeslist1 = new ArrayList<MyEmployee>();
		if (ebr != null)
		{
			employeeslist1 = ebr.searchEmployees("j");
			if (!employeeslist1.isEmpty())
			{
				for (int i = 0; i < employeeslist1.size(); i++)
				{
					System.out.println(employeeslist1.get(i).getEmployeeId()
							+ " " + employeeslist1.get(i).getEmployeeName());
				}
			}
			else
			{
				System.out.println("Invalid entry..Please enter a valid name");
			}
		}
	}

}
