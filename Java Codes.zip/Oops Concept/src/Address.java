class Address
{
	public static void main(String[] args)
	{
		System.out.println("Tirumala P.G, 5th main,");
		System.out.println("Maithri layout, Hope form,");
		System.out.println("Bangalore.");
	}
}