
public class Employ {
	String name;
	String age;
	String language;
	String degree;
	String employed;
	
	
	
	public void setEmpDetails(String n, String ee, String l, String deg, String emp)
	{
		name=n;
		age=ee;
		language=l;
		degree=deg;
		employed=emp;
	}
	
	public void printEmp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(language);
		System.out.println(degree);
		System.out.println(employed);
	}
}
