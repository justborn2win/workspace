
public class testArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int t[]={75,75,100};
		System.out.println(t.length);
	}

}
