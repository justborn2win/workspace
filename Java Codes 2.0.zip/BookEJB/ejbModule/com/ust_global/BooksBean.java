package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class BooksBean
 */
@Stateless
public class BooksBean implements BooksBeanRemote {

    /**
     * Default constructor. 
     */
    public BooksBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="BooksUnit")
    private EntityManager entityManager;
    
	@Override
	public void addBooks(Books b) {
		entityManager.persist(b);
		
	}

	@Override
	public List<Books> showAllBooks() {
		@SuppressWarnings("unchecked")
		List<Books> allBooks=entityManager.createQuery("FROM Books").getResultList();
		return allBooks;
	}

	@Override
	public Books updateBooks(int bookid, String bookName, String authorName) {
		Books b=entityManager.find(Books.class, bookid);
		if(b!=null)
		{
			b.setAuthorName(authorName);
			b.setBookName(bookName);
			entityManager.merge(b);
		}
		else
		{
			b=null;
		}
		return b;
	}

	@Override
	public Books deleteBooks(int bookid) {
		Books b=entityManager.find(Books.class, bookid);
		if(b!=null)
		{
			entityManager.remove(b);
		}
		else
		{
			b=null;
		}
		return b;
	}



	@Override
	public Books findBookById(int bookid) {
		Books b=entityManager.find(Books.class, bookid);
		if(b!=null)
		{
			b.getBookId();
			b.getBookName();
			b.getAuthorName();
		}
		else
		{
			b=null;
		}
		return b;
	}



	@Override
	public List<Books> findBookByName(String bookName) {
		List<Books> allbooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchBookByName=new ArrayList<Books>();
		
		if(allbooks!=null)
		{
			for(int i=0;i<allbooks.size();i++)
			{
				if(allbooks.get(i).getBookName().equalsIgnoreCase(bookName))
				{
					searchBookByName.add(allbooks.get(i));
				}
			}
		}
		return searchBookByName;
	}



	@Override
	public List<Books> findBookByAuthor(String authorName) {
		List<Books> allbooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchBookByAuthor=new ArrayList<Books>();
		
		if(allbooks!=null)
		{
			for(int i=0;i<allbooks.size();i++)
			{
				if(allbooks.get(i).getAuthorName().equalsIgnoreCase(authorName))
				{
					searchBookByAuthor.add(allbooks.get(i));
				}
			}
		}
		return searchBookByAuthor;
	}

}
