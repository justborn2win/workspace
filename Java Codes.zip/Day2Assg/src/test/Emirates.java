package test;

public class Emirates implements Flight{

	@Override
	public void Airways() {
		// TODO Auto-generated method stub
		System.out.println("You are travelling with Emirates from Dubai to Bangalore via Mumbai ");
	}

}
