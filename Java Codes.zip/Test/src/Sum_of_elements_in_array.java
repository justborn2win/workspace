
public class Sum_of_elements_in_array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,20,30,40,50,60,70,80,90,100};
		int sum=0;
		for(int i=0;i<no.length;i++)
		{
			sum=sum+no[i];
		}
		System.out.println(sum);


	}

}
