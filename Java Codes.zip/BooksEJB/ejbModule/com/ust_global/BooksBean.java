package com.ust_global;

import java.util.ArrayList;

import javax.ejb.Stateful;

/**
 * Session Bean implementation class BooksBean
 */
@Stateful
public class BooksBean implements BookRemote {
	ArrayList addBooks;
    /**
     * Default constructor. 
     */
    public BooksBean() {
        addBooks=new ArrayList();
    }
	@Override
	public void addBooks(String books) {
		addBooks.add(books);
		
	}
	@Override
	public ArrayList displayAllBooks() {
		return addBooks;
	}
	

}
