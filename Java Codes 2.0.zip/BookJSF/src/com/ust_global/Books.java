package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Books {
	int bookId;
	String bookName;
	String authorName;
	
	String choice="";
	String input="";
	String msg="";
	Properties p;
	Context ctx;
	
	public Books(){
		p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
	}
		
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	
	public String addBooks(Books b) throws NamingException
	{
		ctx=new InitialContext(p);
		BooksBeanRemote bbr=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		Books bk1=new Books();
		bk1.setBookId(bookId);
		bk1.setBookName(bookName);
		bk1.setAuthorName(authorName);
		
		if(bbr!=null)
		{
			bbr.addBooks(bk1);
			msg="added";
		}
		else
		{
			msg="can't add";
		}
		
		return msg;
	}
	
	public String findBooks() throws NamingException
	{
		ctx=new InitialContext(p);
		BooksBeanRemote bbr=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		if(choice.equalsIgnoreCase("Book Name"))
		{
			bbr.findBookByName(this.bookName);
		}
		return msg;
	}
	public List<Books> findBookByName(String bookName);
	public List<Books> findBookByAuthor(String authorName);
	public List<Books> showAllBooks();
	public Books updateBooks(int bookid, String bookName, String authorName);
	public Books deleteBooks(int bookid);
}
