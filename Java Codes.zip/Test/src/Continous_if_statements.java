
public class Continous_if_statements {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int average = 80;
		if (average > 80)
		{
			System.out.println("grade A");
		}
		else if(average > 80 && average < 90)
		{
			System.out.println("grade B");
		}
		else if (average > 60 && average < 80)
		{
			System.out.println("grade C");
		}
		else 
		{
			System.out.println("Fail");
		}
	}
	

}
