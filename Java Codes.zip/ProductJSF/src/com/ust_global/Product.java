package com.ust_global;

public class Product {
	String productName;
	double productPrice;
	double quantity;
	double totalPrice;
	
	Product() {
		super();
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	public String calculateTotal()
	{
		String msg="success";

		this.totalPrice=this.productPrice*this.quantity;
		return msg;
	}
}
