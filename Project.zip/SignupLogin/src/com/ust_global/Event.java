/**
 * 
 * This is the POJO class for JSF 1.x
 * For the front end of Auditorium project
 * Group 3
 * ALPHA 1133
 * 
 * 
 * */
 package com.ust_global;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import com.ust_global.admin.EventsBeanRemote;
import com.ust_global.user.Ticket;
import com.ust_global.user.TicketBeanRemote;

public class Event 
{
	//table properties
	private String eventId;
	private String eventName;
	private String eventDate;
	private String eventCategory;
	private double ticketPrice;
	private String seatStatus;//0 or 1 separated by commas
	private String allSeats;//seat name separated by commas
	
	//for payment page
	private double totPrice;
	private int numberOfSeats;
	private String userSelectedSeats;
	private String creditCardNumber;
	
	
	//for cancellation
	private long ticketNumber;
	
	//for the radio in the search result page
	private String userSelectedEventID;
	
	private com.ust_global.admin.Event userSelectedEvent=new com.ust_global.admin.Event();
	
	//for sessioTracking
	private String userName;
	
	//for selecting the seat
	private int selectedSeat;
	
	public String[] selectedSeats;//for the checkbox
	
	//for the searchByAnything method 
	private String searchOption;//for storing the values of the dropdown selection
	private String searchInput;//for reading the search field values
	
	//for searching by event id
	private com.ust_global.admin.Event event=new com.ust_global.admin.Event();
	
	private List<String> allSeatsList=new ArrayList<String>();
	private List<String> allAvailableSeats=new ArrayList<String>();
	private List<Integer> allSeatStatus=new ArrayList<Integer>();
	private List<com.ust_global.admin.Event> result=new ArrayList<com.ust_global.admin.Event>();
	
	private boolean[] allSeatForClientSide=new boolean[60];
	
	private long lastTicketNumber;
	private String msg = " ";
	private String displayMsg = "";
	
	
	public String getDisplayMsg() {
		return displayMsg;
	}
	public void setDisplayMsg(String displayMsg) {
		this.displayMsg = displayMsg;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

	private String adminOperation; // admin operation
	public String getAdminOperation() {
		return adminOperation;
	}
	public void setAdminOperation(String adminOperation) {
		this.adminOperation = adminOperation;
	}

	List <com.ust_global.admin.Event> allEvents=new ArrayList <com.ust_global.admin.Event>();
	public List<com.ust_global.admin.Event> getAllEvents() {
		return allEvents;
	}
	public void setAllEvents(List<com.ust_global.admin.Event> allEvents) {
		this.allEvents = allEvents;
	}
	
com.ust_global.admin.Event adminEvent=new com.ust_global.admin.Event();
	
	public com.ust_global.admin.Event getAdminEvent() {
	return adminEvent;
}
public void setAdminEvent(com.ust_global.admin.Event adminEvent) {
	this.adminEvent = adminEvent;
}

	
	
	
public String navigationMethod() throws NamingException
{
	Properties p = new Properties();
	p.put(Context.PROVIDER_URL, "localhost:1099");
	p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
	p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
	Context ctx;
	ctx = new InitialContext(p);
	EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
	TicketBeanRemote ticketRemote=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
	
	System.out.println(userSelectedEventID);
	msg="dontBook";//fail
	userSelectedEvent=remote.searchEvent(userSelectedEventID);
	//0,0,0,0,0,0,0
	
	com.ust_global.admin.Event oneEvent=remote.searchEvent(userSelectedEventID);
	String allstatus=oneEvent.getSeatStatus();
	String[] statusArray=allstatus.split(",");
	
	Arrays.fill(allSeatForClientSide, false);
	
	for (int i = 0; i < statusArray.length; i++) 
	{
		
		if(statusArray[i].equalsIgnoreCase("0"))
		{
			allSeatForClientSide[i]=false;
		}
		else
		{
			allSeatForClientSide[i]=true;
		}
		System.out.print(allSeatForClientSide[i]+" is the statusarray[i] when the i is "+i);
	}
	if(userSelectedEvent!=null)
	{
		msg="book";//succcess
	}
	return msg;
}
	
	public String createEvent() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		com.ust_global.admin.Event event=new com.ust_global.admin.Event();
		
		//updated with gregorian cal instead of util date
		String[] date=eventDate.split("-");
		int year=Integer.parseInt(date[2]);
		int month=Integer.parseInt(date[1]);
		int dayOfMonth=Integer.parseInt(date[0]);
		GregorianCalendar utilDate=new GregorianCalendar(year, month-1, dayOfMonth);
		long ms=utilDate.getTimeInMillis();
		java.sql.Date sqlDate=new Date(ms);
		//-----------------
		setAllSeats("A01,A02,A03,A04,A05,A06,A07,A08,A09,A10,"+
					"B01,B02,B03,B04,B05,B06,B07,B08,B09,B10,"+
					"C01,C02,C03,C04,C05,C06,C07,C08,C09,C10,"+
					"D01,D02,D03,D04,D05,D06,D07,D08,D09,D10,"+
					"E01,E02,E03,E04,E05,E06,E07,E08,E09,E10,"+
					"F01,F02,F03,F04,F05,F06,F07,F08,F09,F10,"
					);
		
		setSeatStatus(	"0,0,0,0,0,0,0,0,0,0," +
						"0,0,0,0,0,0,0,0,0,0," +
						"0,0,0,0,0,0,0,0,0,0," +
						"0,0,0,0,0,0,0,0,0,0," +
						"0,0,0,0,0,0,0,0,0,0," +
						"0,0,0,0,0,0,0,0,0,0,"
					);
		
		event.setEventId(getEventId());
		event.setEventName(getEventName());
		event.setEventCategory(getEventCategory());
		event.setEventDate(sqlDate);
		event.setAllSeats(getAllSeats());
		event.setTicketPrice(getTicketPrice());
		event.setSeatStatus(getSeatStatus());
		
		msg="";//fail	
		if(event!=null && this.ticketPrice > 500)
		{
			try
			{
				remote.createEvent(event);
				msg="Event Creation Success";//success
			}
			catch (Exception e) 
			{
				//eventID already exists
				msg="eventID already exists";//fail
			}
		}
		else
		{
			displayMsg="Please enter ticket price greater than 500";
			return "cannot create event";
		}
		System.out.println(msg);
		return displayMsg;
	}
	
	public String updateEvent() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		//updated with gregorian cal instead of util date
		String[] date=eventDate.split("-");
		int year=Integer.parseInt(date[2]);
		int month=Integer.parseInt(date[1]);
		int dayOfMonth=Integer.parseInt(date[0]);
		GregorianCalendar utilDate=new GregorianCalendar(year, month-1, dayOfMonth);
		long ms=utilDate.getTimeInMillis();
		java.sql.Date sqlDate=new Date(ms);
		//-----------------
		
		if(remote!=null)
		{
			try
			{
			remote.updateEvent(getEventId(), getEventName(),sqlDate , getEventCategory(),getSeatStatus(), getTicketPrice(),getAllSeats());
			}
			catch (Exception e) 
			{
				msg="";//fail
			}
		}
		else
			msg="";//fail
		return msg;
	}

	@SuppressWarnings("unused")
	public String viewAllEvents() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			List<com.ust_global.admin.Event> allEvents=remote.allEvents();
			msg="";//success
		}
		else
			msg="";//fail
		return msg;
	}
	
	public String cancelEvent() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			try
			{
				remote.cancelEvent(getEventId());
				msg="";//success
			}
			catch (Exception e)
			{
				msg="";//fail
			}
		}
		
		return msg;
	}
	
	public String searchEventById() throws NamingException
	{
		msg="";//fail
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		if(remote!=null)
		{
			com.ust_global.admin.Event event=remote.searchEvent(getEventId());
			if(event!=null)
			{
				msg="";//success
			}
		}
		return msg;	
	}
	
	public String searchByAnthing() throws NamingException
	{
		/**
		 * 
		 * In this method if you don't give a a keyword it will search by the dropdown selection
		 * if you provide a keyword it will not consider the value of the dropdown selection  
		 * 
		 * */
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if(remote!=null)
		{
			if(searchInput=="")//search by category
			{
				result=remote.serchEventByCategory(getSearchOption());
				if(!result.isEmpty())
				{
					System.out.println("input is "+searchOption);
					msg="success";//success
				}
				else
				{
					System.out.println("input is "+searchOption);
					System.out.println("250-list is empty");
					msg="fail";//fail
				}
			}
			else
			{
				result=remote.serchEventByName(getSearchInput());
				if(!result.isEmpty())
				{
					System.out.println("input is "+searchInput);
					msg="success";//success
				}
				else
				{
					System.out.println("input is "+searchInput);
					System.out.println("265");
					msg="fail";//fail
				}
				
			}
		}
		
		return msg;
	}
	
	public String makePayment() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		com.ust_global.admin.Event oneEvent=remote.searchEvent(userSelectedEventID);
		
		msg="payment";
		
		allSeats=oneEvent.getAllSeats();//now seat has all seats for an event
		userSelectedSeats="init";
		numberOfSeats=selectedSeats.length;
		setTicketPrice(oneEvent.getTicketPrice());
		System.out.println("price of the event is "+ticketPrice);
		totPrice=ticketPrice*numberOfSeats;
		System.out.println("number of ticket is "+numberOfSeats+" and totPrice is " +ticketPrice);
		
		String[] seat=allSeats.split(",");

		for (int i = 0; i < selectedSeats.length; i++)
		{
			selectedSeat=Integer.parseInt(selectedSeats[i]);
			if(userSelectedSeats.equalsIgnoreCase("init"))
			{
				userSelectedSeats=seat[selectedSeat];
			}
			else
			{
				userSelectedSeats=userSelectedSeats+","+seat[selectedSeat];
			}
		}
		
		return msg;
	}
	
	public String bookATicket() throws NamingException
	{
		System.out.println("test");

		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		com.ust_global.admin.Event oneEvent=remote.searchEvent(userSelectedEventID);
		setTicketPrice(oneEvent.getTicketPrice());
		msg="fail";//fail
		
		TicketBeanRemote ticketRemote=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
		
		String seats ="init";
		StringBuffer temp=new StringBuffer();
		
		if(creditCardNumber.length()==13)
		{
			if(oneEvent!=null)
			{
			if(ticketRemote!=null)
			{
				List<Ticket> allTicket=ticketRemote.viewAll();
				long tNumber = 0;
				for(Ticket t:allTicket)
				{
					if(tNumber<t.getTicketNumber())
					{
						tNumber=t.getTicketNumber();
					}
				}
				lastTicketNumber=(tNumber+1)*2;
				System.out.println(lastTicketNumber+"current ticket number");
				System.out.println((lastTicketNumber+1)*2+" next ticket number");
				
				String allSeats = null;
				String allstatus = null;
				try
				{
					allSeats=oneEvent.getAllSeats();//now seat has all seats for an event
					allstatus=oneEvent.getSeatStatus();
					System.out.println(allSeats+" allSeats-from 260");
					System.out.println(allstatus+" allstatus-from 261");				
				}
				catch (Exception e) 
				{
					msg="";//no such event exists
				}
				System.out.println(allstatus+"from line 270");
				String[] seat=allSeats.split(",");
				String[] statusArray=allstatus.split(",");

				System.out.println("*********statusArray********");
				for (int i = 0; i < statusArray.length; i++) {
					System.out.print(statusArray[i]+",");
				}
				/**
				 * 
				 * if the user selects the 4th seat the element at 4th index in the allSeatStatus arraylist should be 1 instead of 0; 
				 * int selectedSeat is the index number of the seat in the arraylist of the availableSeats list
				 * 
				 **/
				
				temp.insert(0, allstatus);
				for (int i = 0; i < selectedSeats.length; i++)
				{
					System.out.println(selectedSeat+"selectedSeat");
					System.out.println("statusArray[i] is "+statusArray[i]+" and i is "+i);
					System.out.println(seat[selectedSeat]+" -287");
					
					System.out.println(selectedSeat+"selectedSeat");
										
					int count=0;
						if(statusArray[selectedSeat].equals("0")&&count==0)//if the seat is available
						{
							System.out.println(seat[selectedSeat]+"seat[selectedSeat] from line 293");

							statusArray[selectedSeat]="1";//it will be booked				
							System.out.println(statusArray[selectedSeat]+" statusArray[selecetdSeat] from line 442 after updating");
							System.out.println(seats+" from 370");
							System.out.println(selectedSeat+" from 373");
							if(selectedSeat==0)
							{
								temp.replace((selectedSeat), (selectedSeat)+1, "1");
								seats=temp.toString();
								System.out.println(seats);
								System.out.println("from  =412");
							}
							else if(selectedSeat==statusArray.length)
							{
								temp.replace((selectedSeat*2)-1,(selectedSeat*2), ",1");
								seats=temp.toString();
								System.out.println(seats);
								System.out.println("from = 419");
							}
							else
							{
								temp.replace((selectedSeat*2), (selectedSeat*2)+1, "1");
								seats=temp.toString();
								System.out.println(seats);
								System.out.println("from =426");
							}
							
							//modify this
							TicketBeanRemote ticket=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
							Ticket tckt=new Ticket();
							
							Date dbDate = userSelectedEvent.getEventDate();
							String strDate=dbDate.toString();
							System.out.println(strDate);
							//2016-07-10
							//updated with gregorian cal instead of util date
							String[] date=strDate.split("-");
							int year=Integer.parseInt(date[0]);
							int month=Integer.parseInt(date[1]);				
							int dayOfMonth=Integer.parseInt(date[2]);			//greogorian cal add one to the given month, so we have to give -1
							GregorianCalendar utilDate=new GregorianCalendar(year, month-1, dayOfMonth);
							long ms=utilDate.getTimeInMillis();
							java.sql.Date sqlDate=new Date(ms);
							//-----------------
							
							tckt.setEventId(userSelectedEvent.getEventId());
							tckt.setEventName(userSelectedEvent.getEventName());
							tckt.setSelectedDate(sqlDate);//updated date
							tckt.setUserName(userName);//check for managed property in faces-config.xml
							tckt.setTicketPrice(totPrice);//get the ticketPrice from the oneEvent object
							tckt.setTicketNumber(lastTicketNumber);
							tckt.setSeatNumber(userSelectedSeats);
							tckt.setNoOfSeats(numberOfSeats);//based on the array len
							
							Ticket newTicket = null;
							try
							{
								if(seats.equalsIgnoreCase("init"))
								{
									System.out.println("changing the value of \"seats\" to the value of \"temp\"");
									seats=temp.toString();
								}
								newTicket=ticket.createTicket(tckt);
								if(newTicket!=null)
								{
									remote.updateEvent(oneEvent.getEventId(), oneEvent.getEventName(), oneEvent.getEventDate(), oneEvent.getEventCategory(), seats, oneEvent.getTicketPrice(),oneEvent.getAllSeats());
									System.out.println("seats status upadeted in the db");
								}
							}
							catch (Exception e) 
							{
								System.out.println("**********stacktrace**********");
								e.printStackTrace();
								System.out.println("exception");
							}
							System.out.println(tckt.getTicketPrice()+"price");
							System.out.println(tckt.getEventId()+" "+tckt.getEventName()+" "+tckt.getSeatNumber()+" "+tckt.getTicketNumber()+" "+tckt.getUserName()+" "+tckt.getSelectedDate());
							if(newTicket!=null)
							{
								msg="";//success
								System.out.println("added");
							}
							else
							{
								msg="";//fail
								System.out.println("failure");
							}
						}
						else
						{
							count=1;
						}
						if(seats.equalsIgnoreCase("init"))
						{
							System.out.println("failure from line 345"); 
							seats=temp.toString();
						}
						/**
						 *
						 * After updating the available seats list the new status is pushed to the db 
						 *
						 **/
//					}
					else
					{
						System.out.println("from else -481");
						System.out.println(seats);
						System.out.println(temp);
					}
				
				}
				}
				

			}
		}
		return msg;
	}
	
	public String cancelTicket() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		TicketBeanRemote ticket=(TicketBeanRemote) ctx.lookup("SelectedEventsbean/remote");
		
		msg="";//fail
		
		if(ticket!=null)
		{	
			Ticket tckt=ticket.searchTicket(getTicketNumber());
			if(tckt!=null)
			{
				ticket.cancelTicket(getTicketNumber());
				com.ust_global.admin.Event oneEvent=remote.searchEvent(tckt.getEventId());
				String str=oneEvent.getAllSeats();
				StringBuffer temp=new StringBuffer();
				temp.insert(0, str);
				String seats;
				String allstatus=oneEvent.getSeatStatus();
				String[] statusArray=allstatus.split(",");
				
				if(selectedSeat==1)
				{
					temp.replace((selectedSeat), (selectedSeat)+1, "0");
					seats=temp.toString();
					System.out.println(seats);
					System.out.println("from  =598");
				}
				else if(selectedSeat==statusArray.length)
				{
					temp.replace((selectedSeat*2)-1,(selectedSeat*2), ",0");
					seats=temp.toString();
					System.out.println(seats);
					System.out.println("from = 605");
				}
				else
				{
					temp.replace((selectedSeat*2), (selectedSeat*2)+1, "0");
					seats=temp.toString();
					System.out.println(seats);
					System.out.println("from =612");
				}
				com.ust_global.admin.Event eve=remote.updateEvent(oneEvent.getEventId(), oneEvent.getEventName(), oneEvent.getEventDate(), oneEvent.getEventCategory(), seats, oneEvent.getTicketPrice(),oneEvent.getAllSeats());
				if(eve!=null)
				{
					msg="";//success
				}
			}
			
		}
		return msg;
	}
								
public String selectAdminOperation() throws NamingException {
		
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		EventsBeanRemote remote = (EventsBeanRemote) ctx.lookup("EventsBean/remote");
		
		if (adminOperation.equalsIgnoreCase("CREATE AN EVENT"))
		{
			createEvent();
			
		}else if (adminOperation.equalsIgnoreCase("UPDATE AN EVENT"))
		{
			//updated with gregorian cal instead of util date
			String[] date=eventDate.split("-");
			int year=Integer.parseInt(date[2]);
			int month=Integer.parseInt(date[1]);
			int dayOfMonth=Integer.parseInt(date[0]);
			GregorianCalendar utilDate=new GregorianCalendar(year, month-1, dayOfMonth);
			long ms=utilDate.getTimeInMillis();
			java.sql.Date sqlDate=new Date(ms);
			//-----------------
			
			if(remote!=null)
			{
				
				com.ust_global.admin.Event event=remote.updateEvent(getEventId(), getEventName(),sqlDate , getEventCategory(),getSeatStatus(), getTicketPrice(),getAllSeats());
				
				if(event!=null)
				{
					msg="UpdateEventSuccess";
				}
				else
				{
					msg="EventNotExist";//fail
				}
			} //remote.cancelEvent(getEventId());
			else
				msg="UpdateEventFailure";//fail
		}else if (adminOperation.equalsIgnoreCase("REMOVE AN EVENT"))
		{
			if(remote!=null)
			{
				com.ust_global.admin.Event event=remote.searchEvent(getEventId());
				
				if(event!=null)
				{
					remote.cancelEvent(getEventId());
					System.out.println("Not null");
					msg="CancelEventSuccess";
				}
				else
				{
					System.out.println("Its null");
					msg="CancelEventFailure";//fail
				}
			} //remote.cancelEvent(getEventId());
			else
				msg="CancelEventFailure";//fail
		
			return msg;
		}else if (adminOperation.equalsIgnoreCase("VIEW ALL EVENTS"))
		{
			allEvents=remote.allEvents();
			if (!allEvents.isEmpty())
			{
				msg="AllEvents";//success	
			}
			else
			{
				msg="ListEmpty"; //Failure
			}
			
			
		}
		
		else if (adminOperation.equalsIgnoreCase("SEARCH AN EVENT"))
		{
			adminEvent=remote.searchEvent(getEventId());
			
			if (adminEvent!=null)
			{			
			msg="SearchResult";//success
			}
			else 
			{
				msg="SearchFailed";
			}
		}
		
//		else if (adminOperation.equalsIgnoreCase("SEARCH AN EVENT"))
//		{
//			event=remote.searchEvent(getEventId());
//			msg="";//success
//		}
		
		return msg;
		
	}								                  /*Getters and Setters*/
	public String getSearchInput() {
		return searchInput;
	}
	public void setSearchInput(String searchInput) {
		this.searchInput = searchInput;
	}
	public String getSearchOption() {
		return searchOption;
	}
	public void setSearchOption(String searchOption) {
		this.searchOption = searchOption;
	}
	public String[] getSelectedSeats() {
		return selectedSeats;
	}
	public void setSelectedSeats(String[] selectedSeats) {
		this.selectedSeats = selectedSeats;
	}
	public int getSelectedSeat() {
		return selectedSeat;
	}
	public void setSelectedSeat(int selectedSeat) {
		this.selectedSeat = selectedSeat;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventCategory() {
		return eventCategory;
	}
	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getSeatStatus() {
		return seatStatus;
	}
	public void setSeatStatus(String seatStatus) {
		this.seatStatus = seatStatus;
	}
	public String getAllSeats() {
		return allSeats;
	}
	public void setAllSeats(String allSeats) {
		this.allSeats = allSeats;
	}
	public List<String> getAllSeatsList() {
		return allSeatsList;
	}
	public void setAllSeatsList(List<String> allSeatsList) {
		this.allSeatsList = allSeatsList;
	}
	public List<Integer> getAllSeatStatus() {
		return allSeatStatus;
	}
	public void setAllSeatStatus(List<Integer> allSeatStatus) {
		this.allSeatStatus = allSeatStatus;
	}
	public List<String> getAllAvailableSeats() {
		return allAvailableSeats;
	}
	public void setAllAvailableSeats(List<String> allAvailableSeats) {
		this.allAvailableSeats = allAvailableSeats;
	}
	public com.ust_global.admin.Event getEvent() {
		return event;
	}
	public void setEvent(com.ust_global.admin.Event event) {
		this.event = event;
	}
	public List<com.ust_global.admin.Event> getResult() {
		return result;
	}
	public void setResult(List<com.ust_global.admin.Event> result) {
		this.result = result;
	}
	public String getUserSelectedEventID() {
		return userSelectedEventID;
	}
	public void setUserSelectedEventID(String userSelectedEventID) {
		this.userSelectedEventID = userSelectedEventID;
	}
	public long getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(long ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public com.ust_global.admin.Event getUserSelectedEvent() {
		return userSelectedEvent;
	}
	public void setUserSelectedEvent(com.ust_global.admin.Event userSelectedEvent) {
		this.userSelectedEvent = userSelectedEvent;
	}
	public boolean[] getAllSeatForClientSide() {
		return allSeatForClientSide;
	}
	public void setAllSeatForClientSide(boolean[] allSeatForClientSide) {
		this.allSeatForClientSide = allSeatForClientSide;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public double getTotPrice() {
		return totPrice;
	}

	public void setTotPrice(double totPrice) {
		this.totPrice = totPrice;
	}

	public String getUserSelectedSeats() {
		return userSelectedSeats;
	}

	public void setUserSelectedSeats(String userSelectedSeats) {
		this.userSelectedSeats = userSelectedSeats;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
