package com.ust_global;
import java.io.*;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BooksEJBClient {

	public static void main(String[] args) throws NamingException, IOException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		
		BookRemote book1 = (BookRemote) ctx.lookup("BooksBean/remote");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("---------1st Request---------------");
		System.out.println("Press 0 to stop adding books");
		System.out.println("Enter books name");
		String bookNames="";
		do
		{
			bookNames=br.readLine();
			if(bookNames.equalsIgnoreCase("0"))
			{
				break;
			}
			else
			{
				book1.addBooks(bookNames);
			}
			
		}
		while(!bookNames.equalsIgnoreCase("0"));
		
		ArrayList books=book1.displayAllBooks();
		System.out.println(book1.displayAllBooks());
		System.out.println("Thank you for entering books into our library");
		System.out.println();
		
		
		System.out.println("---------2nd Request---------------");
		
		
		String searchBook=br.readLine();
		
		do
		{
			System.out.println("Press 0 to exit our library");
			System.out.println("Which book do you want");
			if(books.contains(searchBook))
			{
				System.out.println("Book is available");
				
			}
			else
			{
				System.out.println("Book is not available");
				System.out.println("Thank you");
				System.exit(0);
				break;
			}
		}while(!searchBook.equalsIgnoreCase("0"));
			
		
		
		
}
}