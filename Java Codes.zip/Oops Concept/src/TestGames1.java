import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestGames1 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Games s=new Games();
		
		
		Games s1=new Games();
		
		
		Games s2=new Games();
		
		
		Games s3=new Games();
		
		
		Games s4=new Games();
		
		
		Games s5=new Games();
		
		Games sport[]=new Games[6];
		sport[0]=s;
		sport[1]=s1;
		sport[2]=s2;
		sport[3]=s3;
		sport[4]=s4;
		sport[5]=s5;
		
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		for(int i=0;i<sport.length;i++)
		{
			System.out.println("Enter the player name:");
			String name=br.readLine();
			sport[i].player=name;
			
			System.out.println("Enter the game name:");
			String game=br.readLine();
			sport[i].sports=game;
		}
		
		System.out.println("******************");
		for(int i=0;i<sport.length;i++)
		{
			sport[i].printDetails();
		}
	}

}
