package com.ust_global;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.List;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ExecutionInfo;
import com.datastax.driver.core.QueryTrace;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class ConnectCassandra {
	
	static Cluster cluster;
	static Session session;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		//Create the cluster object
		cluster=Cluster.builder().addContactPoint("localhost").withPort(9042).build();
		System.out.println("Successfully connected to cassandra");
		System.out.println("Name of the cluster is "+cluster.getClusterName());
		
		session=cluster.connect();
		if(session!=null)
		{
			System.out.println("Successfully connected to cassandra and got the session object");
		}
		else
		{
			System.out.println("Some error");
		}
		
		//inserting row into books table in keyspace ust1
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("Enter book_id");
		int book_id=Integer.parseInt(br.readLine());
		System.out.println("Enter book_price");
		int book_price=Integer.parseInt(br.readLine());
		System.out.println("Enter book_publisher");
		String book_publisher=br.readLine();
		System.out.println("Enter book_title");
		String book_title=br.readLine();
//		
//		
		String cql="insert into ust1.books(book_id,book_price,book_publisher,book_title) values(?,?,?,?)";
		session.execute(cql,book_id,book_price,book_publisher,book_title);
		System.out.println("Successfully inserted");
		
		//read one row
//		String cql="Select * from ust1.books where book_id=1";
//		ResultSet results=session.execute(cql);
//		Row row=results.one();
//		if(row!=null)
//		{
//			int bid=row.getInt("book_id");
//			BigInteger bprice=row.getVarint("book_price");
//			String bpub=row.getString("book_publisher");
//			String btit=row.getString("book_title");
//			
//			System.out.println("Successfully found the book");
//			System.out.println(bid+","+bprice+","+bpub+","+btit);
//		}
//		else
//		{
//			System.out.println("No such books");
//		}
		
		
		//read all row
//		ResultSet results=session.execute("Select * from ust1.books");
//		List list=results.all();
//		for(int i=0;i<list.size();i++)
//		{
//			Row r=(Row)list.get(i);
//			System.out.println("Book_id is "+r.getInt("book_id"));
//			System.out.println("Book_price is "+r.getVarint("book_price"));
//			System.out.println("Book_publisher is "+r.getString("book_publisher"));
//			System.out.println("Book_title is "+r.getString("book_title"));
//			System.out.println("------------------------------------------");
//		}
		
//		InputStreamReader isr=new InputStreamReader(System.in);
//		BufferedReader br=new BufferedReader(isr);
//		System.out.println("Enter book_id");
//		int book_id=Integer.parseInt(br.readLine());
//		
//		ResultSet rs=session.execute("delete from ust1.books where book_id=?",book_id);
//		Row r=rs.one();
//		if(r!=null)
//		{
//			System.out.println("Deleted");
//		}
//		else
//		{
//			System.out.println("No such record");
//		}
		
		System.out.println("End of the program");
		System.exit(0);
		
	}

}
