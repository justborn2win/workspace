
public class Pr37 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=5;
		while(i<=25)
		{
			System.out.print(i+" ");
			i=i+5;
		}

	}

}
