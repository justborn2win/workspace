	var app=angular.module("myApp",[]);
	app.controller("myController",function($scope)
	{
		$scope.employees=[
		                  {name:'Rahul',salary:12056,place:'Adoor'},
		                  {name:'Eliza',salary:12500,place:'Mangalore'},
		                  {name:'Vaisakh',salary:12400,place:'Kollam'},
		                  {name:'Riya',salary:13000,place:'Kannur'},
		                  {name:'Anju',salary:13000,place:'Koothatukulam'},
		                  ];
		
	}
);









