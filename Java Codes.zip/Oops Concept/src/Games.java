
public class Games {
		String sports;
		String player;
		
		Games sport[];
		Games sportsman[];
		
		
	
		public void printDetails()
		{
			System.out.println(player+" plays "+sports);
			System.out.println();
		}
		
}