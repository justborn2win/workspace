
public class Pr7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20,c=30;
		
		System.out.println("using the formula we get " +(a%b%c));

	}

}
