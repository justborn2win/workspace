
public class Movies {
	String name;
	String language;
	String certification;
	
	
	
	public Movies(String name, String language, String certification) {
		this.name = name;
		this.language = language;
		this.certification = certification;
	}
	
	
}
