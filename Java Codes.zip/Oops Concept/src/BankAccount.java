import java.io.*;
public class BankAccount extends Exception{
	String nameOfTheCustomer;
	int accountNumberl;
	double balanceAmount=1000;
	

}
