
public class Biggest_no_divisible_by_3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,21,32,43,57,66,76,88,97,100};
		int big=0;
		   for (int i=0;i<no.length;i++)
		   {
		    if(no[i]%3==0)
			   {
		    	if(no[i]>big);
				{
					big=no[i];
				}
			   }
		   } 
		   System.out.println("The biggest number divisible by 3 is " +big);

	}

}
