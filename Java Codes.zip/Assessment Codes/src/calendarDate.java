import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

public class calendarDate {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		Calendar cal=new GregorianCalendar();    
		 //creating an object cal of Gregorian calendar
		
		SimpleDateFormat dayFormat=new SimpleDateFormat("EEEE");
		//creating an object dayFormat to store the day i.e: Monday, Tuesday etc.
		
		SimpleDateFormat dateFormat=new SimpleDateFormat("MMMM dd,yyyy");
		//creating an object dateFormat to store the date in MMMM dd,yyyy format
		
		BufferedReader inReader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number of days:");
		int days=Integer.parseInt(inReader.readLine());
		//taking input from the user
		
		cal.add(Calendar.DATE, days);
		//adding the number of days to the current date
		
		
		System.out.print("After "+days+" days, it will be a "+dayFormat.format(cal.getTime()));
		System.out.print(" and the date will be "+dateFormat.format(cal.getTime()));
}
}
