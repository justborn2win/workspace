class TestColor
{
	public static void main(String args[])
	{
		Red r=new Red();
		System.out.println(r.areYouRed());
	}
}
