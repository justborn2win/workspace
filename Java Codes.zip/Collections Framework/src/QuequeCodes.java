import java.util.*;
public class QuequeCodes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		PriorityQueue<Integer> prq=new PriorityQueue<Integer>();
		
		
		prq.add(10);
		prq.add(2);
		prq.add(20);
		
		System.out.println("Initial priority queue values are:"+prq);
		
		Integer head=prq.poll();
		
		System.out.println("Head of the queue is: "+head);
		System.out.println("Priority queue values after poll: "+prq);
		
	}

}
