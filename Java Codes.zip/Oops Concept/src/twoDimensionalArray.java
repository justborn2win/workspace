
public class twoDimensionalArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[][]={{1,2,3,4,5},{15,14,3,12,9}};
		int big=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i][i]>big)
			{
				big=a[i][i];
			}
		}
		System.out.println(big);
	}

}
