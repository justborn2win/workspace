package com.ust_global;


import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.*;

/**
 * Session Bean implementation class StudentBean
 */
@Stateless
public class StudentBean implements StudentBeanRemote {
	
    public StudentBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="StudentUnit")
	EntityManager entityManager;

	@Override
	public void addStudent(Student s) {
		entityManager.persist(s);
		
	}

	@Override
	public Student readStudent(int id) {
		
		Student st=entityManager.find(Student.class, id);
		return st;
	}

	@Override
	public List<Student> readAllStudents() {
		List<Student> allStudents=entityManager.createQuery("FROM Student").getResultList();
		return allStudents;
	}

	@Override
	public Student updateStudent(int id, String name) {
		Student st=entityManager.find(Student.class, id);
		if(st!=null)
		{
			
			st.setStudentName(name);
			entityManager.merge(st);
		}
		else
		{
			st=null;
		}
		return st;
	}

	@Override
	public Student deleteStudent(int id) {
		Student st=entityManager.find(Student.class, id);
		if(st!=null)
		{
			entityManager.remove(st);
		}
		else
		{
			st=null;
		}
		return st;
	}

	
    

	
	

}
