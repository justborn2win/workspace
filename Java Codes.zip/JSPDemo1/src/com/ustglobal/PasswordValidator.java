package com.ustglobal;

public class PasswordValidator {

	public boolean validateUser(String uName, String uPass)

	{

		boolean validUser = false;

		if (uName.equalsIgnoreCase("clinton") && uPass.equalsIgnoreCase("ust"))

		{

			validUser = true;

		}

		return validUser;

	}

}