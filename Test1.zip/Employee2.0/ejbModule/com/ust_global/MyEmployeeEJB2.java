package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class MyEmployeeEJB2
 */
@Stateless
public class MyEmployeeEJB2 implements MyEmployeeEJB2Remote {

    /**
     * Default constructor. 
     */
    public MyEmployeeEJB2() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="EmployeeUnit")
    private EntityManager entityManager;
    
	@Override
	public List<MyEmployee> searchEmployees(String employeeManager) {
		List<MyEmployee> allEmployees=entityManager.createQuery("FROM MYEMPLOYEE").getResultList();
		List<MyEmployee> empList=new ArrayList<MyEmployee>();
		
		if(!allEmployees.isEmpty())
		{
			for(MyEmployee emp:allEmployees)
			{
				if(emp.getEmployeeManager().equalsIgnoreCase(employeeManager))
					{
						empList.add(emp);
					}
			}
		}
		
		return empList;
	}

}
