package Abstraction;

public abstract class Parent {
	
	void m1()
	{
		System.out.println("I am from m1");
	}
	
	abstract void m2();
}
