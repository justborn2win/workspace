import java.util.*;
public class Stacko {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Stack st=new Stack();
		st.push(22);
		st.push(23);
		st.push(100);
		
		System.out.println(st);
		
		st.pop(); //removes last element
		System.out.println(st);
	}

}
