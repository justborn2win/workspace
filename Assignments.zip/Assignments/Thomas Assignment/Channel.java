
public class Channel {
	String channelName;
	int channelNumber;
	
	Program programs[];
	Viewers viewers[];
	
	public void setChannelDetails(String cName,int cNumber )
	//method to set channel details
	{
		channelName=cName;
		channelNumber=cNumber;
		
	}
	
	public void printChannelDetails()
	//method to print channel details
	{
		System.out.println("Channel name: "+channelName);
		System.out.println("Channel Number: "+channelNumber);
		
	}
	
	public void feedbackIsRegarding()
	{
		
		for(int i=0;i<viewers.length;i++)
		{
			viewers[i].viewerFeedbackType();
			//calling viewerFeedbackType method
		}
	}
	
	
			
		
	
	
	
}
