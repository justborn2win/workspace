import java.util.*;
public class RandHeadTails {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand=new Random();
		
		//System.out.println(x);
		boolean G=true;
		int a=0,b=0;
		for(int i=1;i<=10;i++)
		{
			if(G==rand.nextBoolean())
			{
				a++;
			}
			else
			{
				b++;
			}
		}
		
		System.out.println("No of times head is "+a);
		System.out.println("No of times tail is "+b);

	}

}
