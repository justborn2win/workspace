import java.util.*;
public class ArrayListo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList a=new ArrayList(3); //default capacity is 3
		a.add(1);
		a.add(2);
		a.add(3);
		a.add(4); //4th element
		
		
		a.add(5);
		System.out.println(a);
		
		System.out.println("=======");
		
		a.add(1, 7);
		System.out.println(a);
		System.out.println("======");
		
		a.contains(4);
		System.out.println(a);
		System.out.println("=======");
		
		a.isEmpty();
		System.out.println(a.isEmpty());
		System.out.println("=======");
		
		a.size();
		System.out.println(a.size());
		System.out.println("=======");
		
		a.remove(4);
		System.out.println(a);
		System.out.println("======");
		
		a.addAll(a);
		System.out.println(a);
		System.out.println("=======");
		
		
		Object arr[]= a.toArray();
		System.out.println(a);
		

	}

}
