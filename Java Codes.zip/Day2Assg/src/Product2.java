
public class Product2 {
	int prodId;
	String prodName;
	double prodPrice;
	
	public void setProductDetails(int pId, String pName, double pPrice)
	{
		prodId=pId;
		prodName=pName;
		prodPrice=pPrice;
	}
	public void printProductDetails()
	{
		System.out.println("Id: "+prodId);
		System.out.println("Name: "+prodName);
		System.out.println("Price: "+prodPrice);
	}
}
