
public class ReverseNumberAssg {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int rem=0;
		int rev=0;
		int no=125;
		while(no>0)
		{
			rem=no%10;
			rev=rem;
			no=no/10;
			System.out.print(rev);
		}
		

	}

}
