
public class Divisibleby5_inanArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={0,10,7,25,99,45};
		int c=0;
		for(int i=0;i<no.length;i++)
		{
			if(no[i]==0) continue;
			if(no[i]%5==0)
			{
				
				c++; 
			}	
			
			
		}
		
		if(c>0)
		{
			System.out.println("There are " +c+ " numbers divisible by 5 ");
		}
		else
		{
			System.out.println("There are no numbers divisible by 5");
		}


	}

}
