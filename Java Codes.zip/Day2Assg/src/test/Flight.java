package test;

public interface Flight {
		public void Airways();
}
