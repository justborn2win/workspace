
public class meanofINtArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[]={10,6,9,2,3,1,5};
		int total=0;
		int mean=0;
		int count=a.length;
		for(int i=0; i<a.length;i++)
		{
			total=total+a[i];

		}
		
		System.out.println(mean=total/count);
	}

}
