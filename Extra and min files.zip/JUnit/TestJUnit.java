import org.junit.Test;
import org.junit.Assert;

public class TestJUnit{
@Test
public void testAverage(){
Calculation c=new Calculation();

int x[]={10,20,3,40,55,70};
double act=c.findAverage(x);
Assert.assertEquals(33.0,act,0.1);
}

}