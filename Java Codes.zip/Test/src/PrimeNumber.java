
public class PrimeNumber {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i,m=0,n=17,t=0;     
		m=n/2;    
		for(i=2;i<=m;i++)
		{    
			if(n%i==0)
			{    
				System.out.println("Number is not prime");    
				t=1;    
				break;    
			}    
		 }    
		 if(t==0)
		 { 
		 System.out.println("Number is prime");    
		 }  

		
	}
}

