class EvenNumber{

public double EvenOrOdd(int x){
	if(x%2==0)
	{
		System.out.println("It is an Even number");
	}
	else
	{
		System.out.println("It is an odd number");
	}
	return x;

}
}