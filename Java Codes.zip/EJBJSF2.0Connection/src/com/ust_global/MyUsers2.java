package com.ust_global;

import java.util.Properties;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@ManagedBean(name="MyUserBean")
@SessionScoped
public class MyUsers2 {
	String userName;
	String password;
	
	
	MyUsers2() throws NamingException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		MyUserBeanRemote mbr=(MyUserBeanRemote) ctx.lookup("MyUserBean/remote");
		
		boolean found=mbr.validateUsers(userName, password);
		String msg="";
		if(found=true)
		{
			msg="success";
		}
		else
		{
			msg="failure";
		}
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
