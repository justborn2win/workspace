import java.util.*;
public class ReverseOrderArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Integer a[]={5,4,8};
		
		Arrays.sort(a,Collections.reverseOrder());

		
		for( int i=0; i<a.length; i++)
		System.out.println(a[i]);

	}

}
