
public class MainFrameTechnology extends GIPROProject {
	static String database="MySQL";
	
	
	public MainFrameTechnology(String projectID, String clientName) {
		super(projectID, clientName);
		// TODO Auto-generated constructor stub
	}

	public void printProjectDetails()
	{
		printDetails();
		System.out.println("Database:"+database);
		System.out.println();
	}
}
