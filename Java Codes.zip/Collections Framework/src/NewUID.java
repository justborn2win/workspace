import java.util.*;
import java.io.*;
import java.io.ObjectInputStream.GetField;


public class NewUID {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		EmployeeCollection em=new EmployeeCollection();
		em.setEmployeeDetails("Jesvin", "Joy","Male", 12000);
		
		EmployeeCollection em1=new EmployeeCollection();
		em1.setEmployeeDetails("Sreenath", "Raju","Male", 13000);
		
		EmployeeCollection em2=new EmployeeCollection();
		em2.setEmployeeDetails("Vaisakh", "V","Male", 14000);
		
		EmployeeCollection em3=new EmployeeCollection();
		em3.setEmployeeDetails("Clinton", "Yuvamela","Male", 15000);
		
		EmployeeCollection em4=new EmployeeCollection();
		em4.setEmployeeDetails("Rahul", "Lal","Male", 16000);
		
		EmployeeCollection em5=new EmployeeCollection();
		em5.setEmployeeDetails("Anjumol", "Thomas","Female", 17000);
		
		EmployeeCollection em6=new EmployeeCollection();
		em6.setEmployeeDetails("Fihadh", "Akbar","Male", 18000);
		
		EmployeeCollection em7=new EmployeeCollection();
		em7.setEmployeeDetails("Abhirami", "Theerthamkara","Female", 19000);
		
		HashMap hm=new HashMap();
		hm.put(1, em);
		hm.put(2, em1);
		hm.put(3, em2);
		hm.put(4, em3);
		hm.put(5, em4);
		hm.put(6, em5);
		hm.put(7, em6);
		hm.put(8, em7);
		
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("Enter an ID");
		int k=Integer.parseInt(br.readLine());
		
		EmployeeCollection ee=(EmployeeCollection) hm.get(k);	
		
		
			if(ee.gender.equalsIgnoreCase("Male"))
			{
				System.out.println("Mr."+ee.firstName);
				
			}
			else if(ee.gender.equalsIgnoreCase("Female"))
			{
				System.out.println("Ms."+ee.firstName);
			}
		
		
		
		

	}

}
