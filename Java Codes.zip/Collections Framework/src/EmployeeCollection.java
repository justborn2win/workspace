
public class EmployeeCollection {
	String firstName;
	String lastName;
	String gender;
	double salary;
	
	public void setEmployeeDetails(String fname, String lname, String gen, double sal)
	{
		firstName=fname;
		lastName=lname;
		gender=gen;
		salary=sal;
	}
	
	public void printEmployeeDetails()
	{
		System.out.println("Employee name: "+firstName);
		System.out.println("Employee lastname: "+lastName);
		System.out.println("Employee Gender: "+gender);
		System.out.println("Employee salary: "+salary);
	}
}
