
interface Flipkartoon {
	double amountPayable=1000;
	
}
