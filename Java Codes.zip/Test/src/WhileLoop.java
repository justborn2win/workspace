
public class WhileLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no=0,diff=1;
		while(no<=15)
		{
			System.out.println(no);
			no=no+diff;
			diff=diff+1;
		}

	}

}
