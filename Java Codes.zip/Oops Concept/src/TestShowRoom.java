import java.io.*;
public class TestShowRoom {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		int count=0;
		Car cars[]=new Car[2];

		SalesPerson sp1[]=new SalesPerson[2];
		
		for(int i=0;i<cars.length;i++)
		{
			System.out.println("Enter the car name: ");
			String a=br.readLine();
			System.out.println("Model: ");
			String b=br.readLine();
			System.out.println("Price: ");
			String c11=br.readLine();
			double c=Double.parseDouble(c11);
			System.out.println("Capacity: ");
			String d11=br.readLine();
			int d= Integer.parseInt(d11);
			Car c1=new Car();
			c1.setCarDetails(a, b, c, d);
			cars[i]=c1;
			
		}
		
//		System.out.println();
//		for(int i=0;i<sp1.length;i++)
//		{
//			System.out.println("Enter the Sales Persons name: ");
//			String a=br.readLine();
//			System.out.println("Age: ");
//			String b1=br.readLine();
//			int b=Integer.parseInt(b1);
//			System.out.println("Salary: ");
//			String c1=br.readLine();
//			double c=Double.parseDouble(c1);
//			System.out.println("Specialized: ");
//			String d=br.readLine();
//			
//			
//			SalesPerson s1=new SalesPerson();
//			s1.setSalesDetails(a, b, c, d);
//		
//			sp1[i]=s1;
//			
//		}
//		
//		for(int i=0;i<cars.length;i++)
//		{
//			cars[i].printCarNamesOnly();
//		}
//		
//		
//		for(int i=0;i<sp1.length;i++)
//		{
//			sp1[i].printSalesPersonNamesOnly();
//		}
//		
//		for(int i=0;i<sp1.length;i++)
//		{
//			if(sp1[i].specialized.equalsIgnoreCase("Maruthi"))
//			{
//				
//				System.out.println("Sales person specialized in Maruthi cars is:"+sp1[i].name);
//			}
//		}
//		
		for(int i=0;i<cars.length;i++)
		{
			if(cars[i].carPrice>700000)
			{
				count++;
				if (count>0)
				{
				 System.out.println(cars[i].carName);
				}
			}
		}
		if (count==0)
			
		{	
			System.out.println("There is no cars of price above 7 lacs");
		}
		}

}
