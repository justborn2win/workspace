
public class CTechnology  extends GIPROProject {
	static String database="MySQL";
	
	public CTechnology(String string, String clientName) {
		super(string, clientName);
		// TODO Auto-generated constructor stub
	}
	
	public void printProjectDetails()
	{
		printDetails();
		System.out.println("Database:"+database);
		System.out.println();
	}
}
