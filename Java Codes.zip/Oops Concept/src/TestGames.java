import java.io.*;
public class TestGames {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Games s=new Games();
		s.sports="Cricket";
		s.player="Sachin";
		
		Games s1=new Games();
		s1.sports="Badminton";
		s1.player="Saina";
		
		Games s2=new Games();
		s2.sports="Tennis";
		s2.player="Sania";
		
		Games s3=new Games();
		s3.sports="Football";
		s3.player="Maradona";
		
		Games s4=new Games();
		s4.sports="Volleyball";
		s4.player="James";
		
		Games s5=new Games();
		s5.sports="Cricket";
		s5.player="James";
		
//		s.printDetails();
//		s1.printDetails();
//		s2.printDetails();
//		s3.printDetails();
//		s4.printDetails();
//		s5.printDetails();
		
		
		Games sport[]=new Games[6];
		sport[0]=s;
		sport[1]=s1;
		sport[2]=s2;
		sport[3]=s3;
		sport[4]=s4;
		sport[5]=s5;
		
//		for(int i=0;i<sport.length;i++)
//		{
//			sport[i].printDetails();
//			
//		}
		System.out.println("**************************");
		
		System.out.println("Enter the player name you want to search:");
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		String name=br.readLine();
		
		int c=0;
		
		for(int i=0;i<sport.length;i++)
		{
			
			
			if(sport[i].sports.equalsIgnoreCase(name))
			{
				c=1;
			}
			else
			{
				c=0;
			}
		}
		
		if(c==1)
		{
			System.out.println("Player is present");
		}
		else
		{
			System.out.println("No such Player");
		}
//		System.out.println("**************************");
//		for(int i=0;i<sport.length;i++)
//		{
//			if(sport[i].player.equals("James"))
//			{
//				sport[i].printDetails();
//			}
//			
//		}
//		System.out.println("**************************");
	}}
