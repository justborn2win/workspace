
public class Col {
	String color;
	String shape;
}
