package test;

public class TestFlight {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emirates e=new Emirates();
		e.Airways();
		
		AirIndia a=new AirIndia();
		a.Airways();
	}

}
