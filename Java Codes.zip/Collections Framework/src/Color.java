import java.util.*;
import java.io.*;
public class Color {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		HashMap co=new HashMap();
		
		co.put(1, "Orange");
		co.put(2, "Red");
		co.put(3, "White");
		co.put(4, "Green");
		co.put(5, "Pink");
		co.put(6, "Gray");
		co.put(7, "Yellow");
		co.put(8, "Magenta");
		co.put(9, "Black");
		co.put(10, "Rainbow");
		
		InputStreamReader a=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(a);
		System.out.println("Enter a key");
		
		int key=Integer.parseInt(br.readLine());
		String Color=(String) co.get(key);
		if(co.containsKey(key))
			System.out.println("The Color is "+Color);
		else
			System.out.println("No such color ");
		}
		
	}


