package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface BooksBeanRemote {
	public void addBooks(Books b);
	public Books findBookById(int bookid);
	public List<Books> findBookByName(String bookName);
	public List<Books> findBookByAuthor(String authorName);
	public List<Books> showAllBooks();
	public Books updateBooks(int bookid, String bookName, String authorName);
	public Books deleteBooks(int bookid);
}
