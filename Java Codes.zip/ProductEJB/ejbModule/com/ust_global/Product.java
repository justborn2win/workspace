package com.ust_global;

import java.io.Serializable;

public class Product implements Serializable {
	String proName;
	double proPrice;
	double proQuantity;
	double netPrice;
	double discount;
	
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public double getProPrice() {
		return proPrice;
	}
	public void setProPrice(double proPrice) {
		this.proPrice = proPrice;
	}
	public double getProQuantity() {
		return proQuantity;
	}
	public void setProQuantity(double proQuantity) {
		this.proQuantity = proQuantity;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	
	

}
