package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface MyUserBeanRemote {
	public boolean validateUsers(String uName, String password);
}
