package com.ust_global;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class AnotherTest {
	
	static Cluster cluster;
	static Session session;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		//Create the cluster object
		cluster=Cluster.builder().addContactPoint("localhost").withPort(9042).build();
		System.out.println("Successfully connected to cassandra");
		System.out.println("Name of the cluster is "+cluster.getClusterName());
		
		session=cluster.connect();
		if(session!=null)
		{
			System.out.println("Successfully connected to cassandra and got the session object");
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			System.out.println("Enter book_id");
			int book_id=Integer.parseInt(br.readLine());
			
			ResultSet rs=session.execute("select * from ust1.books where book_id=?",book_id);
			Row r=rs.one();
			if(r!=null)
			{
			 rs=session.execute("delete from ust1.books where book_id=?",book_id);
			 System.out.println("Deleted");
			}
			else
			{
				System.out.println("No such record");
			}
			
			System.out.println("End of the program");
			System.exit(0);
		}
		else
		{
			System.out.println("Some error");
			System.exit(0);
		}
		
				
		
		
		
	}

}
