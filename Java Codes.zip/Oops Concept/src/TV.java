class TV 
{
	String brand,type;
	int size;
	float price;
	int currentChannel;
	int currentVolume;
	
	public void switchOff()
	{
		System.out.println("TV is switched off....");
	}
	public void switchOn()
	{
		System.out.println(brand);
	}
	public void increaseChannel()
	{
		currentChannel--;
		System.out.println("Now, the channel has been changed to "+currentChannel);
		
	}
	public void decreaseChannel()
	{
		System.out.println("Now, the channel has been changed to "+currentChannel);
	}
	public void increaseVolume()
	{
		System.out.println("Now, the volume has been increased to "+currentVolume);
	}
	public void decreasevolume()
	{
		System.out.println("Now, the volume has been decreased to"+currentVolume);
	}
	
}
