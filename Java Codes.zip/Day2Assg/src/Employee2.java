
public class Employee2 {
	int empId;
	String empName;
	double empSalary;
	
	
	public void setEmpDetails(int eId, String eName, double eSalary)
	{
		empId=eId;
		empName=eName;
		empSalary=eSalary;
	}
	public void printEmpDetails()
	{
		System.out.println("Employee id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Salary: "+empSalary);
	}
}
