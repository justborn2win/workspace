package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import com.ust_global.user.LoginCredentialsBeanRemote;
import com.ust_global.user.User;

public class Login {

	String userName;
	String passWord;
	String confirmPassword;
	
	List<User> readAllLogindetails = new ArrayList<User>();
	
	
	public Login() {

	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	public List<User> getReadAllLogindetails() {
		return readAllLogindetails;
	}

	public void setReadAllLogindetails(List<User> readAllLogindetails) {
		this.readAllLogindetails = readAllLogindetails;
	}

	public String login() throws NamingException {
		String msg = " ";
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		LoginCredentialsBeanRemote log = (LoginCredentialsBeanRemote) ctx.lookup("LoginCredentialsBean/remote");
		User user=log.Login(this.userName, this.passWord);
		if ( user!= null)
		{
			if (this.passWord.equals(user.getPassWord())
					&& this.userName.equals(user.getUserName())) {
				FacesContext fc = FacesContext.getCurrentInstance();
				ExternalContext ec = fc.getExternalContext();
				HttpSession session = (HttpSession) ec.getSession(false);
				session.setAttribute("userName", this.userName);
				
				if(user.getUserName().equalsIgnoreCase("admin"))
				{
					msg="admin";
				}
				else
				{
					msg = "SuccessLogin";
				}

			} else {
				msg = "failurePassword";
			}
			// invalid password
		} else {
			msg = "failureUsername";// invalid username
		}
		return msg;
	}

	public String forgotPassword() throws NamingException {
		String msg = " ";
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		LoginCredentialsBeanRemote log = (LoginCredentialsBeanRemote) ctx
				.lookup("LoginCredentialsBean/remote");
		if (this.passWord.equals(this.confirmPassword)) {
			User forgetPass = log.forgotPassword(this.userName, this.passWord);
			if (forgetPass != null) {
				forgetPass.setPassWord(passWord);
				msg = "passUpdated";
			} else {
				msg = "forgetusernamefailed";// username invalid
			}
		} else {
			msg = "forgetpasswordfailed";// passwords dont match
		}
		return msg;

	}
	public String deleteAccount() throws NamingException
	{
		String msg = " ";
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		LoginCredentialsBeanRemote log = (LoginCredentialsBeanRemote) ctx
				.lookup("LoginCredentialsBean/remote");
		if(log!=null)
		{
			if(this.passWord.equals(confirmPassword))
			{
			log.deleteAccount(userName, passWord);
			msg="delete"; //delete account
			}
			else
			{
			msg="notdeleted"; //account is not deleted
			}
		}
			return msg;
	}
	public String ReadAllNames() throws NamingException
	{
		String msg = " ";
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		LoginCredentialsBeanRemote log = (LoginCredentialsBeanRemote) ctx
				.lookup("LoginCredentialsBean/remote");
		List<User> readAllLogindetails = log.readAllUserNames();
		if(!readAllLogindetails.isEmpty())
		{
			for(User read:readAllLogindetails)
			{
				read.setPassWord(null);
			}
			msg="read"; // read all the details
		}
		return msg;	
	}
	public String updatePassword() throws NamingException
	{

		String msg = " ";
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx;
		ctx = new InitialContext(p);
		LoginCredentialsBeanRemote log = (LoginCredentialsBeanRemote) ctx
				.lookup("LoginCredentialsBean/remote");
		User user = log.updatePassword(this.userName, this.passWord);
		if(user!=null)
		{
			if(user.getPassWord().equals(this.passWord))
			{
				msg="update"; // updating  the password
			}
		}
		else
		{
			msg="notupdate"; // not updated
		}
		return msg;
	}
	
	public String logout() {
		String msg = "";
		FacesContext fc = FacesContext.getCurrentInstance();
		ExternalContext ec = fc.getExternalContext();
		HttpSession session = (HttpSession) ec.getSession(false);
		String x = (String) session.getAttribute("userName");
		if (x != null) {
		session.removeAttribute("userName");
		session.invalidate();
		msg = "SuccessLogout";
		}
		return msg;
		}
}