
public class TestCustomer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Address c=new Address();
		c.setAdd(1, "Maithri", "Bangalore");
		
		Customer c1=new Customer();
		c1.setCust("Jesvin", "Joy", c);
		
		c1.printCust();

	}

}
