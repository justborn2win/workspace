package com.ust_global;

import java.util.ArrayList;

import javax.ejb.Remote;

@Remote
public interface EmployeeRemote {
	public void addNames(String name);
	
	public ArrayList displayAllNames();
}
