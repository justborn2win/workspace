import java.util.*;
import java.io.*;
import java.text.*;
public class LeapYear {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader inReader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a number");
		int year=Integer.parseInt(inReader.readLine());
		
		GregorianCalendar cal=(GregorianCalendar) GregorianCalendar.getInstance();
		cal.add(Calendar.YEAR, year);
		boolean LeapYear=cal.isLeapYear(cal.get(Calendar.YEAR));
		if(LeapYear==true)
		{
			System.out.println(cal.get(Calendar.YEAR)+" is a Leap year");
		}
		else
		{
			System.out.println(cal.get(Calendar.YEAR)+" is not a Leap year");
		}
		
		
		System.out.println(new SimpleDateFormat("dd/MM/yyyy").format(cal.get(Calendar.DAY_OF_WEEK)));
		System.out.println();
	}

}
