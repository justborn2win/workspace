package com.ust_global;

public class LapTop{
	public void switchOn()
	{
		System.out.println("Laptop is switched on");
	}
	
	public void switchOff()
	{
		System.out.println("Laptop is switched off");
	}

	
}	
