public class Reverse
{
	/** 
		Here, no is the original number
		The variable "rev" holds the reversed number
		The variable "rem" holds the remainder after division

		What is my logic here?
		
		I am creating a while loop that will run as long as the number is greater than 0
		
		First, Iam calculating the remainder of the number 

	*/
	public static void main(Strings args[])
{
	int no=235;
	int rem=0;
	int rev=0;
	while(no>0)
	{
		rem=no%10;
	}
	System.out.println();
}	