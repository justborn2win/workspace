
public class bigInInt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int x=32932;
		int big=0;
		int rem=0;
		int rev=0;
		while(x>0)
		{
			rem=x%10;
			rev=rem;
			x=x/10;
			
			if(rev>big)
			{
				big=rev;
			}
		}
		System.out.println(big);
	}

}
