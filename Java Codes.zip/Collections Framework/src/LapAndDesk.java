import java.io.*;
public class LapAndDesk {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("What do you want?");
		String J=br.readLine();
		try{
			ExceptionHandling.shop(J);
		}
		catch(ExceptionHandling n){
			System.out.println("Sorry we dont have that product "+J);
			
		}
		finally
		{
			System.out.println();
			System.out.println("Thank you for shopping.");
		}
		
	}

}
