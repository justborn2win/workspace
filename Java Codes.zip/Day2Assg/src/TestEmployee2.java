
public class TestEmployee2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee2 e1=new Employee2();
		
		e1.setEmpDetails(51856, "Sreenath", 12000);
		e1.printEmpDetails();

	}

}
