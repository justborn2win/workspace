
public class Distance {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double seconds = 180;
		double distance = 200;
		double meter = seconds/distance*1575;
		System.out.println(meter);
		
	}

}
