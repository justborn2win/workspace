
public class C_to_F {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double fahrenheit = 100;
		double celsius = (5.0f/9)*(fahrenheit-32);
		System.out.println(celsius);

	}

}
