
public class Pr19 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=12, b=20,c=33;
		if(a%4==0)
		{
			System.out.println(a);
		}
		if(b%4==0)
		{
			System.out.println(b);
		}
		if(c%4==0)
		{
			System.out.println(c);
		}


	}

}
