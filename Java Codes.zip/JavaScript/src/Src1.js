function f1()
{
	alert("Hello I am from javascript library");
}