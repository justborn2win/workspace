
public class Multiply {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i,c=4;
		for(i=1;i<=10;i++)
		{
			System.out.println(c+"*"+i+" = "+(c*i));
		}

	}

}
