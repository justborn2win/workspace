
public class TestProject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JavaTechnology jProject=new JavaTechnology("J01", "UST");
		jProject.printProjectDetails();
		
		MainFrameTechnology mProject=new MainFrameTechnology("M01", "IBM");
		mProject.printProjectDetails();
		
		CTechnology cProject=new CTechnology("C01", "Infosys");
		cProject.printProjectDetails();

	}

}
