package com.ust_global;

import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ProductClient {

	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		
		ProductRemote proRem = (ProductRemote) ctx.lookup("ProductBeans/remote");
	
		Product p3=proRem.proDiscount("Axe", 1500, 1);
		
		System.out.println("Discount is "+p3.discount);
		System.out.println("Netprice is "+p3.netPrice);
		
		
	}

}
