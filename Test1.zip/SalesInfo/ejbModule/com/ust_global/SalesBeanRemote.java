package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface SalesBeanRemote {
	public void addSales(Sales s);
	public Sales searchSales(int salesId);
	public List<Sales> showAllSales();
	public Sales updateSales(int salesId,String salesDate, double amount, String city);
	public Sales deleteSales(int salesId);
}