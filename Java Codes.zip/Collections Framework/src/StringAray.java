import java.util.*;
public class StringAray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String alpha[][]=new String[5][5];
		Scanner scn=new Scanner(System.in);
		System.out.println("Enter a name: ");
		String name=scn.next();
		for(int i=0;i<alpha.length;i++)
		{	
			for(int j=0;j<alpha.length;j++)
			{
				if(alpha[i][j]=="Jesvin")
					System.out.println("Row ");
			}
			
		}

	}

}
