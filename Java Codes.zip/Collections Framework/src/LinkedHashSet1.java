import java.util.*;
public class LinkedHashSet1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LinkedHashSet hs=new LinkedHashSet();
		
		String s1=new String("one");
		String s2=new String("two");
		String s3=new String("three");
		String s4=new String("Three");
		
		hs.add(s1); 
		hs.add(s2); 
		hs.add(s3); 
		hs.add(s4);  
		
		
		
		System.out.println(hs);

	}

}
