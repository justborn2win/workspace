/*
 * This bean is responsible for event booking 
 * seat booking, ticket cancellation etc
 * 
 * */

package com.ust_global.user;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class EventBean
 */
@Stateless
public class TicketBean implements TicketBeanRemote
{

    /**
     * Default constructor. 
     */
    public TicketBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="SelectedEventsUnit")
    EntityManager entityManager;

	@Override
	public Ticket createTicket(Ticket ticket) 
	{
		entityManager.persist(ticket);
		return ticket;
	}

	@Override
	public void cancelTicket(long ticketId)
	{
		Ticket ticket=entityManager.find(Ticket.class, ticketId);
		if(ticket!=null)
		{
		entityManager.remove(ticket);
		}
	}

	@Override
	public Ticket searchTicket(long ticketId) 
	{
		Ticket ticket=entityManager.find(Ticket.class, ticketId);
		return ticket;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Ticket> viewAll()
	{
		List<Ticket> allTickets=entityManager.createQuery("From SelectedEvents").getResultList();
		return allTickets;
	}

	@Override
	public Ticket updateTicket(long ticketId, String userName, String eventId,
			String eventName, java.sql.Date selectedDate,int noOfSeats, String seatNumber, double ticketPrice) 
	{
		Ticket ticket=entityManager.find(Ticket.class, ticketId);
		if(ticket!=null)
		{
			ticket.setEventName(eventName);
			ticket.setEventId(eventId);
			ticket.setSeatNumber(seatNumber);
			ticket.setSelectedDate(selectedDate);
			ticket.setTicketNumber(ticketId);
			ticket.setNoOfSeats(noOfSeats);
			ticket.setTicketPrice(ticketPrice);
			entityManager.merge(ticket);
		}
		return ticket;
	}

	@Override
	public List<Ticket> searchTicketByEventID(String EventId) 
	{
		@SuppressWarnings("unchecked")
		List<Ticket> allTicket=entityManager.createQuery("From SelectedEvents").getResultList();
		List<Ticket> result=new ArrayList<Ticket>();
		for(Ticket ticket:allTicket)
		{
			if(ticket.getEventId().equalsIgnoreCase(EventId))
			{
				result.add(ticket);
			}
		}
		return result;
	}
}