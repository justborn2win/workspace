package com.ust_global;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

public class LoginBean {
	String name;
	String password;
	
	public LoginBean() {
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String login()
	{	
		String msg="";
		if(this.name.equals(this.password))
		{
			msg="Home";
			FacesContext fc=FacesContext.getCurrentInstance();
			ExternalContext ec=fc.getExternalContext();
			HttpSession session=(HttpSession) ec.getSession(false);
			session.setAttribute("name", this.name);
		}
		else
		{
			msg="Failure";
		}
		System.out.println("Returning "+msg);
		return msg;
	}
	
	public String logout()
	{	
		String msg="";
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession session=(HttpSession) ec.getSession(false);
		if(session!=null)
		{
			String x=(String) session.getAttribute("name");
			if(x!=null)
			{
				System.out.println("You are logging out");
				session.removeAttribute("name");
				session.invalidate();
				msg="loggedout";
			}
		}
		return msg;
	}
}
