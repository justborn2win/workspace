
public class Even_numbered_position {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,20,30,40,50,60,70,80,90,100};
		   for (int i=1;i<no.length;i++)
		   {
		    
		    System.out.println(no[i]);
		    i=i+1;
		   } 
		   }
	}




