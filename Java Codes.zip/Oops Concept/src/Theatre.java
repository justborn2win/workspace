
public class Theatre {
	String nameOfTheTheatre;
	int audienceCapacity;
	boolean hasDtsSound;
	boolean hasGenerator;
	
	
	
	public void setTheatreDetails(String tN, int aC, boolean hD, boolean hG)
	{
		nameOfTheTheatre=tN;
		audienceCapacity=aC;
		hasDtsSound=hD;
		hasGenerator=hG;
		
	}
	
	public void printTheatreDetails()
	{
		System.out.println("Theatre name: "+nameOfTheTheatre);
		System.out.println("Audience capacity: "+audienceCapacity);
		
		if(hasDtsSound==true)
		{
			System.out.println("Has DTS sound");
		}
		else
		{
			System.out.println("Does not have DTS sound");
		}
		
		
		if(hasGenerator==true)
		{
			System.out.println("Theatre has Generator");
		}
		else
		{
			System.out.println("Theatre does not generator");
		}
		
		
		System.out.println("======================================");
	}
	
}
