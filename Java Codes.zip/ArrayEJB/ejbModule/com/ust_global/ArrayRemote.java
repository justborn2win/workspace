package com.ust_global;



import javax.ejb.*;

@Remote
public interface ArrayRemote {
	public MyNumber ArraySum(int a[]);
}
