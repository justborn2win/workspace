package com.ust_global;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class Student1Bean
 */
@Stateless
public class Student1Bean implements Student1BeanRemote {

    /**
     * Default constructor. 
     */
    public Student1Bean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="StudentUnit")
    EntityManager enitityManager;
    
	@Override
	public void addStudent(Student s) {
		enitityManager.persist(s);
	}

	@Override
	public Student updateStudent(int id, String name) {
		Student st=enitityManager.find(Student.class, id);
		if(st!=null)
		{
			st.setStudentName(name);
			enitityManager.merge(st);
		}
		else
		{
			st=null;
		}
		return st;
	}

	@Override
	public Student deleteStudent(int id) {
		Student st=enitityManager.find(Student.class, id);
		if(st!=null)
		{
			enitityManager.remove(st);
		}
		else
		{
			st=null;
		}
		return st;
	}

	@Override
	public List<Student> showAllStudent() {
		List<Student> allStudents=enitityManager.createQuery("FROM Student").getResultList();
		return allStudents;
	}

	@Override
	public Student searchStudent(int id) {
		Student st=enitityManager.find(Student.class, id);
		if(st!=null)
		{
			st.getStudentId();
			st.getStudentName();
		}
		else
		{
			st=null;
		}
		return st;
	}

}
