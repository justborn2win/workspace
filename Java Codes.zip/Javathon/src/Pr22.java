
public class Pr22 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name="Jesvin";
		int n=0;
		do
		{
			System.out.println(name);
			n++;
		}
		while(n<10);

	}

}
