import java.io.*;
public class Pattern {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		int a=Integer.parseInt(br.readLine());
		String b="*";
		
		 for(int i=1;i<=a;i++)
		   {
			  for(int j=1;j<=i;j++)
			  {
				  System.out.print(b);
			  }
			  System.out.println();
		   }

	}

}
