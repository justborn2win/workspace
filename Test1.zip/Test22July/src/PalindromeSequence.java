
public class PalindromeSequence {

	public double checkPalindrome(String array) {
		String reverse="";
		
		for (int i = array.length() - 1; i >= 0; i--) {
			reverse += array.charAt(i);
		}
		System.out.println("Entered String is:" + array);
		System.out.println("Palindrome for the String is:" + reverse);
		if (array.equalsIgnoreCase(reverse)) 
		{
			System.out.println("Is a palindrome");
			return 0;
		} 
		else 
		{
			System.out.println("Is not a palindrome");
		}
		return 1;

	}
}
