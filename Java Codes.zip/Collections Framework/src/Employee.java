import java.io.*;
import java.nio.file.Files;
import java.util.*;
public class Employee {

	/**
	 * @param args
	 * @throws IOException 
	 */
	
	public static void main(String[] args) throws IOException {
		BufferedReader inReader=new BufferedReader(new InputStreamReader(System.in));
		
		String degree="";
		String profession="";
		System.out.println("Enter Employee Details:");
		int moreDetails=2;
		int i=0;
		
		
		HashMap empDetailsMap=new HashMap();
		
		do
		{
			System.out.println("Enter first name:");
			String firstName=inReader.readLine();
			System.out.println(firstName);
			
			
			System.out.println("Enter Employee Age:");
			int age=0;
			age=Integer.parseInt(inReader.readLine());
			System.out.println(age);
			
			System.out.println("Enter the language spoken by employee:");
			String language=inReader.readLine();
			System.out.println(language);
					
			
			System.out.println("Enter previous degree of the employee:");
			String education=inReader.readLine();
				if(education.equalsIgnoreCase("UG"))
					{
						degree="UG";
					}
				else if(education.equalsIgnoreCase("PG"))
					{
						degree="PG";
					}
				else
				{
					System.out.println("Please enter as UG or PG");
				}
			
			System.out.println(degree);
			
			System.out.println("Is the person employed?");
				String ans=inReader.readLine();
				if(ans.equalsIgnoreCase("yes"))
					{
						profession="Employed";
					}
				else if(ans.equalsIgnoreCase("no"))
					{
					
						profession="Not Employed";
					}	
			
			System.out.println(profession);
			

			FileWriter inWriter=new FileWriter("Employees.txt",true);
			BufferedWriter bWriter=new BufferedWriter(inWriter);
			inWriter.write(firstName+",");
			inWriter.write(age+",");
			inWriter.write(language+",");
			inWriter.write(education+",");
			inWriter.write(profession);
			bWriter.newLine();
			bWriter.close();
			inWriter.close();
			
			System.out.println("Are there more details you want to enter?"+" Enter 0 to stop and 1 to continue");
			moreDetails=Integer.parseInt(inReader.readLine());
			
		}
		while(moreDetails!=0);
		
		System.out.println("==========================================");
		System.out.println("Choose any one option");
	while(true)
	{
		FileReader fileReader=new FileReader("Employees.txt");
		BufferedReader bReader=new BufferedReader(fileReader);
		
		System.out.println("1.Display all Employee details");
		System.out.println("2.Display details of an employee who speaks a particular language");
		System.out.println("3.Display all Post-Graduate employee details ");
		System.out.println("4.Display all Under-Graduate employee details");
		System.out.println("5.Display all working employee details");
		System.out.println("6.Display all non-working employee details");
		
		int choice=Integer.parseInt(inReader.readLine());
		
		
		switch(choice)
		{
			case 1:
			{
				FileReader fr=new FileReader("Employees.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				String[] ee=line.split(",");
				
				Employ ee1=new Employ();
				ee1.setEmpDetails(ee[0], ee[1], ee[2], ee[3], ee[4]);
				empDetailsMap.put(i, ee1);
				
				while(line!=null)
				{
					ee1.printEmp();
					
				}
				
				fr.close();
				br1.close();
				break;
			}
			
			case 2:
			{
				FileReader fr=new FileReader("Employees.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				
				System.out.println("Enter a language ");
				String lang=inReader.readLine();
				while(line!=null)
				{
					empDetailsMap.put(i, line);
					i++;
					line=br1.readLine();
				}
			
				fr.close();
				br1.close();
				break;
			}
		}

	}
	
	

}
}

	
