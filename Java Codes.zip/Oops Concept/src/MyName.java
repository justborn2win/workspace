
public class MyName {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a="J";
		String b="E";
		String c="S";
		String d="V";
		String e="I";
		String f="N";
		for(int i=1;i<=20;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(" ");
				
				{
					
				}
			}
			
			 System.out.print(a);
			 System.out.print(b);
			 System.out.print(c);
			 System.out.print(d);
			 System.out.print(e);
			 System.out.print(f);
			 System.out.println();
			
			
		}
		
		
	}

}
