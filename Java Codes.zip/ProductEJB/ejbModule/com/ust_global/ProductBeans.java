package com.ust_global;

import javax.ejb.*;

@Stateless
public class ProductBeans implements ProductRemote {

	public Product proDiscount(String pname, double pprice, double qty) {
		double discount=0;
		
		double totalPrice=pprice*qty;
		
		if(totalPrice>1000)
		{
			discount=totalPrice*0.05;
			
		}
		double netPrice=totalPrice-discount;
		
		Product p1=new Product();
		p1.proName=pname;
		p1.proPrice=pprice;
		p1.discount=discount;
		p1.netPrice=netPrice;
		
		return p1;
		
		
		
		
		
		
	}


}
