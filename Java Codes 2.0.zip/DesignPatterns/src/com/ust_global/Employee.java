package com.ust_global;

public class Employee {
	String name;
	static Employee emp=null;
	
	private Employee()
	{
		
		
	}
	
	public static Employee getInstance()
	{
		if(emp == null)
			emp=new Employee();
		return emp;
	}
}	
