import java.io.*;
public class TestJv {
  
    /**
      * @param args
      */
     public static void main(String[] args) throws IOException{
      InputStreamReader isr=new InputStreamReader(System.in);
      BufferedReader br=new BufferedReader(isr);
      System.out.println("1. Deposit money\n 2. Withdraw money\n 3. View account balance\n 4. Quit"); 
      try{ 
        Double ba = null;
        BankException.withDraw(ba);
      }
      catch(BankException ba)
      {
    	  BankException.whyIamGettingThisMessage();
      }
     }
	}

 