class Add
{
	public static void main(String args[])
	{
		int no1=Integer.parseInt(args[0]);
		int no2=Integer.parseInt(args[1]);
		System.out.println(no1+no2);
	}
}