
public class FileReader2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String line="Java,Guru,Tata";
		String s[]=line.split(",");
		System.out.println(s[1]);
		
	}

}
