class Double1
{
	public static void main(String args[])
	{
		double no1=Double.parseDouble(args[0]);
		double no2=Double.parseDouble(args[1]);
		System.out.println(no1+no2);
	}
}