
public class TestStudent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student t1=new Student();
		t1.name="Jesvin";
		t1.eng=80f;
		t1.maths=100f;
		t1.cs=100f;
		
		System.out.println();
		t1.average();
		
		System.out.println();
		
		Student t2=new Student();
		t2.name="Sreenath";
		t2.eng=94f;
		t2.maths=99f;
		t2.cs=78f;
		System.out.println();
		t2.average();
		
		System.out.println();
		if(t1.average>t2.average)
		{
			System.out.println("======"+t1.name+" got higher marks ======");
		}
		else
		{
			System.out.println("======"+t2.name+" got higher marks=====");
		}
		
		
		

	}

}
