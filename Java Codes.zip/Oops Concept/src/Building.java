
public class Building {
	 String buildingName;
	 int numberOfRooms;
	 int numberOfEmployees;
	 
	 Room rooms[];
	 Employee employees[];
	 
	 
	 public void setBuildingDetails(String bn, int nr, int ne)
	 {
		 buildingName=bn;
		 numberOfRooms=nr;
		 numberOfEmployees=ne;
	 }
	
	 public void printBuildingDetails()
	 {
		 System.out.println("Building name "+buildingName);
		 System.out.println("Number of Rooms "+numberOfRooms);
		 System.out.println("Number of employees "+numberOfEmployees);
		 
		 for (int i=0;i<rooms.length;i++)
		 {
			 rooms[i].printRoomDetails();
		 }
		 
		 for(int i=0;i<employees.length;i++)
		 {
			 employees[i].printEmployeeDetails();
		 }
		 
		 
		 
		 
	 }
}
