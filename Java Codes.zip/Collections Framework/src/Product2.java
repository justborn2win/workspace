
public class Product2 {
	int productId;
	String productName;
	double productPrice;
	String productDiscount;
	
	public void setProductDetails(int id, String pname, double price, String discount)
	{
		productId=id;
		productName=pname;
		productPrice=price;
		productDiscount=discount;
	}
	
	public void printProductDetails()
	{
		System.out.println("Id: "+productId);
		System.out.println("Name: "+productName);
		System.out.println("Price: "+productPrice);
		System.out.println("Discount: "+productDiscount);
	}
}

