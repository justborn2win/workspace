
public class Pattern2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int m=Integer.parseInt(args[0]);
		for(int i=1;i<=m;i++)
		   {
			  for(int j=1;j<=i;j++)
			  {
				  System.out.print(i);
			  }
			  System.out.println();
		   }

	}

}
