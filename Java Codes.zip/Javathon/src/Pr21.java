
public class Pr21 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name="Jesvin";
		int n=0;
		while(n<10)
		{
			System.out.println(name);
			n++;
		}

	}

}
