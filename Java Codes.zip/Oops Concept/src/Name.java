
public class Name {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num=10;
		String a="J";
		for(int i=1;i<=num;i++)
		{
            for(int j=1;j<=num-(i-1);j++)
            {
                System.out.print(a);
                if(j==num-(i-1))
                {
                    for(int k=1;k<=i;k+=1)
                    {
                        System.out.print(" ");
                    }
                    for(int s=1;s<i;s++)
                    {
                        System.out.print(" ");
                    }
                    for(int l=1;l<=num-(i-1);l++)
                    {
                        System.out.print("E");
                      
                    }
                   
                }
            }
            
            System.out.println();
        }


	}

}
