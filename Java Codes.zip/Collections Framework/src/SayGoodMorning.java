import java.util.Locale;
import java.util.ResourceBundle;


public class SayGoodMorning {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Locale mex=new Locale("en","IN");
		Locale.setDefault(mex);
		
		Locale defLang = Locale.getDefault();
		ResourceBundle bundle=ResourceBundle.getBundle("greetings", defLang);
		
		String s = bundle.getString("wish");
		System.out.println(s);

	}

}
