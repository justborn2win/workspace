package com.ust_global;

public class Add {
	int a;
	int b;
	int total;
	
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	
	public String addNumbers()
	{
		String msg="success";
		
		this.total=this.a+this.b;
		
		return msg;
	}

}
