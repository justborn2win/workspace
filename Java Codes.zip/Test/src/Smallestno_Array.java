
public class Smallestno_Array {
	public static void main(String[] args) {
		int no[]={10,7,29,17,99};
		int small=no[3];
		for (int i=0;i<no.length;i++)
		{
			
			if(no[i]<small)
				small=no[i];
		}
		System.out.println("The smallest number is " +small);
	}

}
