
public class Product {
	int prodId;
	String prodName;
	double prodPrice;
	
	public void setProductDetails()
	{
		System.out.println("Product id: "+prodId);
		System.out.println("Name: "+prodName);
		System.out.println("Price: "+prodPrice);
	}
	
	

}
