
public class TestMobilePhone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MobilePhone t1=new MobilePhone();
		t1.name="Nokia";
		t1.qty=2;
		t1.price=70000;
		
		t1.calculateDiscount();

	}

}
