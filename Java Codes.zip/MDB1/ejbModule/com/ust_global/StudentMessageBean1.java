package com.ust_global;

import javax.ejb.ActivationConfigProperty;
 import javax.ejb.MessageDriven;
 import javax.jms.JMSException;
 import javax.jms.Message;
 import javax.jms.MessageListener;
 import javax.jms.ObjectMessage;

import com.sun.mail.handlers.message_rfc822;

/**
  * Message-Driven Bean implementation class for: StudentMessageBean1
  *
  */
 @MessageDriven( name="StudentHandler1",
   activationConfig = { @ActivationConfigProperty(
     propertyName = "destinationType", propertyValue = "javax.jms.Topic"
   ),@ActivationConfigProperty( propertyName="destination",propertyValue="/topic/GuruTopic") })
 public class StudentMessageBean1 implements MessageListener {

    /**
      * Default constructor. 
      */
     public StudentMessageBean1() 
     {
     }
  
  /**
      * @see MessageListener#onMessage(Message)
      */
     public void onMessage(Message message) 
     {

        System.out.println("Topic Mesasage Published");
         ObjectMessage objectMessage=(ObjectMessage)message;
         String msg="";
         
         try {
    msg=(String)objectMessage.getObject();
   } catch (JMSException e) 
   {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
   System.out.println("Published "+msg);
     }

}