
public class Tsetclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a=new String("Java C++");
		
			String c=a.replace("C++", "Java");
			System.out.println(c);
			String d=a.replaceAll(a, "Javasis ffff");
			System.out.println(d);

	}

}
