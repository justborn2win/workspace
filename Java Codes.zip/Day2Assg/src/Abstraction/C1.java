package Abstraction;

public class C1 extends Parent{

	@Override
	void m2() {
		// TODO Auto-generated method stub
		System.out.println("I am m2 from C1 class");
	}
	
	void m3(){
		System.out.println("I am m3");
	}
}
