
public class TestProduct {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Product p=new Product();
		p.setProductDetails("Bata",700,"3.5% discount");
		p.displayProductDetails();

	}

}
