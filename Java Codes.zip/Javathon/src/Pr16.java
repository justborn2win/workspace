
public class Pr16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=11, b=20,c=33, sum=0;
		if(a%2!=0 && b%2!=0)
		{
			sum=a+b;
			System.out.println("The sum of odd numbers is "+sum);
		}
		if(b%2!=0 && c%2!=0)
		{
			sum=b+c;
			System.out.println("The sum of odd numbers is "+sum);
		}
		if(a%2!=0 && c%2!=0)
		{
			sum=a+c;
			System.out.println("The sum of odd numbers is "+sum);
		}
	}

}
