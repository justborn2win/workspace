package com.ust_global;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="CustomerBean",eager=true)
@RequestScoped
public class Customer implements Serializable{

	private static final long serialVersionUID = 1L;
	String userName;
	String password;
	String msg="";
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String loginUser()
	{	
		
		if(this.userName.equalsIgnoreCase(password) && this.password.equalsIgnoreCase(userName))
		{
			msg="success";
		}
		else
		{
			msg="failure";
		}
		
		return msg;
	}

}
