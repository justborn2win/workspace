
public class Ajith {
	String firstName;
	String lastName;
	String standard;
	String section;
	
	public void setStudentdDetails(String f, String l, String std, String sec)
	{
		firstName=f;
		lastName=l;
		standard=std;
		section=sec;
		
	}
	
	public void printStudentsDetails()
	{
		System.out.println("Student name: "+firstName+" "+lastName);
		System.out.println("Class: "+standard+". Section: "+section);
		
		
	}
	
	
}
