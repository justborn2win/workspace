
public class chardemo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch1;
		ch1 = 'X';
		System.out.println("ch1 contains " + ch1);
		ch1++;
		System.out.println("ch1 is now " + ch1);
	}

}
