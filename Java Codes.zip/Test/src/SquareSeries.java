
public class SquareSeries {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int square=1,n=10;
		for (int i=1;i<=n;i++)
		{
			square=i*i;
			System.out.println(square);
		}

	}

}
