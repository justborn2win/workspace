import java.util.*;
public class LinkList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LinkedList ll=new LinkedList();
		
		ll.add("Jesvin");
		ll.add("Joy");
		ll.add("Koshy");
		
		System.out.println(ll);
		System.out.println(ll.poll()); //remove top element
		System.out.println(ll);
		System.out.println(ll.peek());
		System.out.println(ll);
		
		ll.addFirst("Jesvin");
		System.out.println(ll);
		
		ll.addLast("007");
		System.out.println(ll);
		
		ll.add(2, "jesvin");
		System.out.println(ll);
	}

}
