
public class MobilePhone {
	String name;
	double price;
	int qty;
	double discount;
	double total, netPrice;
	
	public void calculateDiscount()
	{
		total=qty*price;
		if(total>50000)
		{
			discount=total*(5.0/100);
		}
		netPrice=total-discount;
		System.out.println("Mobile name is "+name);
		System.out.println("Price is "+price);
		System.out.println("Number of mobiles purchased "+qty);
		System.out.println("Total price is "+total);
		System.out.println("Discount is "+discount);
		System.out.println("net price is "+netPrice);
	
	}
}
