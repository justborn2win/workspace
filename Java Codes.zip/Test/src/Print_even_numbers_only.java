
public class Print_even_numbers_only {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,21,32,43,57,66,76,88,97,100};
		   for (int i=0;i<no.length;i++)
		   {
		    if(no[i]%2==0)
			   {
				   System.out.println(no[i]);
			   }
		   } 
		   
	}
}


