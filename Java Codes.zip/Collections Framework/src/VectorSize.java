import java.util.Vector;


public class VectorSize {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector a=new Vector(3); //default capacity is 3
		a.add(1);
		a.add(9);
		a.add(18);
		a.add(27); //4th element
		a.add(36);
		a.add(45);
		a.add(54);
		
		a.removeElement(18);
		System.out.println(a);

	}

}
