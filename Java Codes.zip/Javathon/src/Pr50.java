
public class Pr50 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=2,b=5;
		String n=" Jesvin ";
		int sum=a+b;
		for(int i=1;i<=sum;i++)
		   {
				  System.out.print(n);
		   }
		
		

	}

}
