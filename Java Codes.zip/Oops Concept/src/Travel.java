import java.io.*;

public class Travel extends Exception{
	String sourcePlace;
	String destinationPlace;
	String routingVia;
	double distance;
	
	Travel travel[];
	
	public void journey(String sPlace, String dPlace, String rVia, double d) throws Travel , IOException
	{
		sourcePlace=sPlace;
		destinationPlace=dPlace;
		routingVia=rVia;
		distance=d;
		
		while(true)
		{
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			int choice=0;
			System.out.println("Enter your choice: ");
			try
			{
				choice=Integer.parseInt(br.readLine());
			}
			catch(NumberFormatException e)
			{
				System.out.println("Please enter a valid number");
			}
			
			switch(choice)
			{
			
			case 1:
			{
				Travel t1=new Travel();
				System.out.println("Enter your Source place:");
				String source=br.readLine();
				t1.sourcePlace=source;
				
				System.out.println("Enter your Destination:");
				String destiny=br.readLine();
				t1.destinationPlace=destiny;
				break;
			}
			case 2:
			{
				Travel t1=new Travel();
				System.out.println("Enter your Source place:");
				String source=br.readLine();
				t1.sourcePlace=source;
				
				System.out.println("Enter your Destination:");
				String destiny=br.readLine();
				t1.destinationPlace=destiny;
				
				for(int i=0;i<travel.length;i++)
				{
					if(t1.distance>travel[i].distance)
					{
						System.out.println("Shortest route is: "+t1.routingVia);
					}
					else if(t1.distance>travel[i].distance)
					{
						System.out.println("Shortest route is: "+t1.routingVia);
					}
				}
				break;
			}
			case 3:
			{
				System.out.println("Sources: "+sourcePlace);
				System.out.println("Destination: "+destinationPlace);
				System.out.println("Routes: "+routingVia);
				System.out.println("Distance: "+distance);
				
				break;
			}
			case 4:
			{
				System.out.println("Thank you");
				System.exit(0);
			}
			}
		}
		
	}
	
	
}
