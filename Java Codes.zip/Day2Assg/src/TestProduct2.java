
public class TestProduct2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
Product2 p1=new Product2();
		
		p1.setProductDetails(9,"Samsung Mobile", 27100);
		p1.printProductDetails();

	}

}
