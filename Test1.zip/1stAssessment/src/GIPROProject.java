
public class GIPROProject {
	String projectID;
	String clientName;
	
	public GIPROProject(String projectID, String clientName) {
		
		this.projectID = projectID;
		this.clientName = clientName;
	}

	public void printDetails()
	{
		System.out.println("Project id:"+projectID);
		System.out.println("Client:"+clientName);
	}
}
