class Red
{
	public boolean areYouRed()
	{
		return true;
		
	}
}