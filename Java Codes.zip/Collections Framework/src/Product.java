
public class Product {
	
}
