import java.io.*;
public class StringArray {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("Enter a word:");
		String line=br.readLine();
		
		
		
		for(int i=0;i<line.length();i++)
		{
			char c[]=line.toCharArray();
			c[i]++;
			
			System.out.print(c[i]);
		}
		
	}

}