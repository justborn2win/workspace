
public class WordForInteger {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int x=534594;
		int rem=0;
		int rev=0;
		int c=x;
		while(x>0)
		{
			rem=x%10;
			rev=rem;
			x=x/10;
//			System.out.println(rev);
		
		
		
			switch(rev)
			{
				case 3: 
						System.out.print("three ");
						break;
				case 4: 
						System.out.print("four ");
						break;
				case 9:
					System.out.print("nine ");
					break;
				case 5:
					System.out.print("five ");
					break;
				case 0:
					default: System.out.println("Invalid number");
					break;
			}
		}
		
		
	}

}
