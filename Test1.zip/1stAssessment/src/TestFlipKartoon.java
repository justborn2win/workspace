
public class TestFlipKartoon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PaymentMode pay1=new PaymentMode("NetBanking");
		pay1.discount();
		
		PaymentMode pay2=new PaymentMode("DebitCard");
		pay2.discount();
		
		PaymentMode pay3=new PaymentMode("CreditCard");
		pay3.discount();

	}

}
