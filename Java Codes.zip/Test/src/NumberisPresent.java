
public class NumberisPresent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,7,29,99};
		int c=0;
		for(int i=0;i<no.length;i++)
		{
			if(no[i]==17)
			{
				c=c+1;
			}	
		}
		if(c==1)
		{
			System.out.println("The number 17 is present");
		}
		else
		{
			System.out.println("The number 17 is absent");
		}

	}

}
