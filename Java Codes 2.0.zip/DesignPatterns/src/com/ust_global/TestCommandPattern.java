package com.ust_global;

public class TestCommandPattern {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LapTop lt=new LapTop();
		RemoteControl rc=new RemoteControl();
		LaptopSwitchOff ltso=new LaptopSwitchOff();
		LaptopSwitchOn lton=new LaptopSwitchOn(lt);
		
		rc.setCommand(ltso);
		rc.pressButton();
		
		rc.setCommand(lton);
		rc.pressButton();

	}

}
