
public class Break {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=0; i<=9; i++)
		{
			System.out.print(i);
			if(i%2==0) continue;
			System.out.println();
		}

	}

}
