
public class Series1_2_4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no=1,diff=1;
		for(int i=1;i<=11;i++)
		{
			System.out.println(no);
			no=no+diff;
			diff=diff+1;
		}
	}

}
