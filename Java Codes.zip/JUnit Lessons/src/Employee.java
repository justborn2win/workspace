
class Employee {
	int salary;

}
