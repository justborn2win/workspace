package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Employee {
	int empId;
	String empName;
	String empManager;
	List<MyEmployee> allEmployees=new ArrayList<MyEmployee>();
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpManager() {
		return empManager;
	}
	public void setEmpManager(String empManager) {
		this.empManager = empManager;
	}
	public List<MyEmployee> getAllEmployees() {
		return allEmployees;
	}
	public void setAllEmployees(List<MyEmployee> allEmployees) {
		this.allEmployees = allEmployees;
	}
	
	public String findEmployee() throws NamingException
	{
		String msg="";
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		
		Context ctx=new InitialContext();
		EmployeeBeanRemote ebr=(EmployeeBeanRemote) ctx.lookup("EmployeeBean/remote");
		
		if(ebr!=null)
		{
			allEmployees=ebr.searchEmployees(this.empManager);
			if(!allEmployees.isEmpty())
			{
				msg="success";
			}
			else
			{
				msg="failure";
			}
		}
		return msg;
		
	}
	
}
