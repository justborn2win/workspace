import java.util.*;
import java.io.*;
public class TestMobile {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		HashMap hm=new HashMap();
		
		
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter first name:");
			String f=br.readLine();
			System.out.println("Enter last name: ");
			String l=br.readLine();
			System.out.println("Enter city");
			String c=br.readLine();
			
			Customer c1=new Customer();
			c1.setCustomerDetails(f, l, c);
			
			System.out.println("Enter mobile brand: ");
			String brand=br.readLine();
			System.out.println("Enter model: ");
			String model=br.readLine();
			System.out.println("Enter mobile price: ");
			double pri=Double.parseDouble(br.readLine());
			
			Mobile m=new Mobile();
			m.setMobileDetails(brand, model, pri);
			
			hm.put(c1, m);
		}
		
		
		
		Set keys=hm.keySet();
		Iterator it=keys.iterator();
		System.out.println("Enter a brand you want to search:");
		String search=br.readLine();
		
		while(it.hasNext())
		{
			Customer cc=(Customer)it.next();
			Mobile m=(Mobile) hm.get(cc);
			if(m.brandName.equalsIgnoreCase(search))
			{
				cc.printCustomerDetails();
			}
		}
	}

}
