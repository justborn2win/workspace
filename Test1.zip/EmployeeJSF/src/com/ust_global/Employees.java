package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Employees {
	int employeeId;
	String employeeName;
	String employeeManager;
	List<MyEmployee> allEmployees=new ArrayList<MyEmployee>();
	
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeManager() {
		return employeeManager;
	}
	public void setEmployeeManager(String employeeManager) {
		this.employeeManager = employeeManager;
	}
	
	
	
	public List<MyEmployee> getAllEmployees() {
		return allEmployees;
	}
	public void setAllEmployees(List<MyEmployee> allEmployees) {
		this.allEmployees = allEmployees;
	}
	
	public String findEmployee() throws NamingException
	{
		String msg="";
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		
		Context ctx=new InitialContext();
		EmployeeBeanRemote ebr=(EmployeeBeanRemote) ctx.lookup("EmployeeBean/remote");
		
		if(ebr!=null)
		{
			allEmployees=ebr.searchEmployees(this.employeeManager);
			
			if(!allEmployees.isEmpty())
			{
				msg="success";
			}
			else
			{
				msg="failure";
			}
		}
		return msg;
	}
	
}
