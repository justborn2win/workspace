
public class Hello {

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// This is the main method
		System.out.println("Hello Eclipse");

	}

}
