
public class Sumof5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no=2,diff=1,sum=0;
		for(int i=1;i<=10;i++)
		{
			no=no*diff;
			sum=sum+no;
			diff=diff+1;
		}
			
			System.out.println(sum);

	}

}
