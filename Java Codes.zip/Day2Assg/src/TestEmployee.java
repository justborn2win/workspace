
public class TestEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee e1=new Employee();
		
		e1.setEmpDetails(51857, "Jesvin", 12000);
		e1.printEmpDetails();

	}

}
