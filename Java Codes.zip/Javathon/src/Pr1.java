
public class Pr1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name="Jesvin";
		System.out.println("My name is "+name);

	}

}
