import org.junit.Test;
import org.junit.Assert;

public class TestJUnit1{
@Test
public void testEvenOrOdd(){
EvenNumber e=new EvenNumber();

int x=6;
double y=e.EvenOrOdd(x);
Assert.assertEquals(6.0,y,0.1);
}
}