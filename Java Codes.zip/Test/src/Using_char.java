
public class Using_char {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch1,ch2;
		ch1 = 88;
		ch2 = 'Y';
		System.out.println("ch1 and ch2");
		System.out.println(ch1+""+ch2);
		}
}
