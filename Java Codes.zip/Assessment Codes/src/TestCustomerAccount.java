import java.io.*;
import java.util.*;

public class TestCustomerAccount {

	/**
	 * @param args
	 * @throws IOException
	 * @throws NumberFormatException
	 * @throws ClassNotFoundException
	 */
	
	
	public static void main(String[] args) throws NumberFormatException,IOException, ClassNotFoundException {
		
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		String ch = "";
		int i = 0;
		int a=0;
		while (!ch.equalsIgnoreCase("0")) {

			FileOutputStream fileOut = new FileOutputStream("AccountDetails.txt",true);
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			
			System.out.println("**********Welcome to UST Bank************");
			System.out.println("Enter 1 to enter account details or 0 to read data");
			ch = br.readLine();
			if (ch.equalsIgnoreCase("1")) {
				System.out.print("\nEnter Customer_Name: ");
				String custName = br.readLine();
				System.out.print("\nEnter Account_No: ");
				int accNo = Integer.parseInt(br.readLine());
				System.out.print("\nEnter Balance: ");
				double balance = Double.parseDouble(br.readLine());
				System.out.print("\nEnter Account_Type: ");
				String typeOfAccount = br.readLine();

				CustomerAccount customer1=new CustomerAccount(custName, accNo, balance, typeOfAccount);
				
			
				objOut.writeObject(customer1);
				objOut.write('\n');
				objOut.close();
				fileOut.close();
			
				System.out.println("saved");

			} else if (ch.equalsIgnoreCase("0")) {
				
				while(true)
				{
					FileInputStream fileIn=new FileInputStream("AccountDetails.txt");
					ObjectInputStream objIn = new ObjectInputStream(fileIn);
					ArrayList<CustomerAccount> customer=new ArrayList<CustomerAccount>();
					CustomerAccount c1=null;
					for(int j=0;j<2;j++)
					{
						System.out.println("hi");
						c1 = (CustomerAccount) objIn.readObject();
						customer.add(c1);
						
						customer.get(j).diplayAllDetails();
						
						
					}
					
					
					break;
				}	
			}
			else if(ch.equalsIgnoreCase("2"))
			{
				break;
			}

	}
}}
