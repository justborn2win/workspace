
public class Mobile {
	String brandName;
	String brandModel;
	double price;

	public void setMobileDetails(String bName, String bModel, double p) {
	
		brandName = bName;
		brandModel = bModel;
		price = p;
	}



	public void printMobileDetails()
	{
		System.out.println("Brand name: "+brandName);
		System.out.println("Brand model: "+brandModel);
		System.out.println("Price: "+price+" Rs");
	}
}
