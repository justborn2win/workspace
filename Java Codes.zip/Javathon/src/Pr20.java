
public class Pr20 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=12, b=20,c=33;
		if(a%4!=0)
		{
			System.out.println(a+" is not divisible by 4");
		}
		if(b%4!=0)
		{
			System.out.println(b+" is not divisible by 4");
		}
		if(c%4!=0)
		{
			System.out.println(c+" is not divisible by 4");
		}


	}

}
