
public class Palindrome {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 int no=555;
		   int rev=0;
		   int rem=0;
		   int c=no;
		   while (no>0)
		   {
		    rem=no%10;
		    rev=rev*10+rem;
		    no=no/10;
		   }
		   if (c==rev)
		   {
		    System.out.println(c +" is a palindrome" );
		   }
		   else
		   {
		    System.out.println(c +" is not a palindrome" );
		   }
		   
		  }

}
