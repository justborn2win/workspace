package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class StudentsEJBClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		
		StudentBeanRemote sbr=(StudentBeanRemote)ctx.lookup("StudentBean/remote");
		
		//Create an object of student class
//		
//		Student s=new Student();
//		s.setStudentId(100);
//		s.setStudentName("Jesvin");
//		
//		sbr.addStudent(s);
//		System.out.println("Succesfully add");
		
//		Student st=sbr.readStudent(2);
//		if(st!=null)
//		{
//			System.out.println("Yes student is found");
//			System.out.println(st.getStudentName());
//		}
//		else
//		{
//			System.out.println("Student not found");
//		}
		
//		List<Student> allStudents=sbr.readAllStudents();
//		for(int i=0;i<allStudents.size();i++)
//		{
//			Student st=allStudents.get(i);
//			System.out.print(st.getStudentId()+" ");
//			System.out.println(st.getStudentName());
//		}
		
//		Student st=sbr.updateStudent(10, "Jesvin");
//		if(st!=null)
//		{
//			System.out.println("Done...Successfully updated");
//		}
//		else
//		{
//			System.out.println("Not updated");
//		}
		
		Student st=sbr.deleteStudent(100);
		if(st!=null)
		{
			System.out.println("Done");
		}
		else
		{
			System.out.println("Not removed");
		}
		
	}

}
