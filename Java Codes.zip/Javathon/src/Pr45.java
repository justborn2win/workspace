
public class Pr45 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a="*";
		for(int i=1;i<=10;i=i+2)
		   {
			  for(int j=1;j<=i;j++)
			  {
				  System.out.print(a);
			  }
			  System.out.println();
		   }
	}

}
