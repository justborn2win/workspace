
public class USDollar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double USD = 66.23;
		double INR = 15 * USD;
		System.out.println(INR);

	}

}
