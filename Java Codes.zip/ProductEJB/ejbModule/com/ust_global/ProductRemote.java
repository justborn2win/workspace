package com.ust_global;

import javax.ejb.*;

@Remote
public interface ProductRemote {
	public Product proDiscount(String pname, double pprice, double qty);
}
