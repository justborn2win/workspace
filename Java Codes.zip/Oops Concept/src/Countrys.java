
public class Countrys {
	String country;
	String capital;
	
	public void setDetails(String coun, String cap){
		
		country=coun;
		capital=cap;
	}
	
	public void printDetails()
	{
		System.out.println("The country is "+country);
		System.out.println("The capital is "+capital);
	}
}
