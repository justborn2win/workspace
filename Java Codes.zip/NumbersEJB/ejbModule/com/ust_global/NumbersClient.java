package com.ust_global;

import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class NumbersClient {

	public static void main(String[] args) throws NamingException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		NumbersRemote n = (NumbersRemote) ctx.lookup("NumbersBean/remote");
		System.out.println(n.OddorEven(6));
		
		NumbersRemote n1 = (NumbersRemote) ctx.lookup("NumbersBean/remote");
		System.out.println(n1.OddorEven(5));
	}

}
