
public class if_statement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k = 5;
		if (k==5)
		{
			k = k +5;
		}
		System.out.println(k);
		int s= 5;
		if (s == 6)
			System.out.println("happy");
		else
			System.out.println("sad");
		
		
		int x = 5,y;
		if (x > 0)
			y = 1;
		else 
			y = -1;
		System.out.println(y);
		
	
		}
}
