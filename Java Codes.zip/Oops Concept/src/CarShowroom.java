
public class CarShowroom extends Car{
	String showName;
	String address;
	String city;
	
	Car car[];
	SalesPerson sp[];
	
	public void setShowRoomDetails(String name, String add, String c)
	{
		showName=name;
		address=add;
		city=c;
	}
	public void printShowRoomDetails()
	{
		System.out.println("Show Room Name: "+showName);
		System.out.println("Address: "+address);
		System.out.println("City: "+city);
		
		for(int i=0; i<car.length;i++)
		{
			car[i].printCarNamesOnly();
		}
		
		for(int i=0; i<sp.length;i++)
		{
			sp[i].printSalesPersonNamesOnly();
		}
	}
}
