
public class SalesPerson {
	String name;
	int age;
	double salary;
	String specialized;
	
	
	public void setSalesDetails(String sname, int a, double sal, String sp)
	{
		name=sname;
		age=a;
		salary=sal;
		specialized=sp;
	}
	
	public void printSalesPersonNamesOnly()
	{
		System.out.println("Name of sales person: "+name);
		
	}
}
