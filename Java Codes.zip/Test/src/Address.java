
public class Address {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Tirumala P.G, 5th main,");
		System.out.println("Maithri Layout, Hope form,");
		System.out.println("Bangalore");
	}

}
