package com.ust_global;

public class TV {
	public void switchOn()
	{
		System.out.println("TV is switched on");
	}
	
	public void switchOff()
	{
		System.out.println("TV is switched off");
	}
}
