package com.ust_global;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SalesHTMLServlet
 */
public class SalesHTMLServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalesHTMLServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		PrintWriter pw=response.getWriter();
		String val=request.getParameter("Option");
		try {
			Context ctx = new InitialContext(p);
			SalesEJBRemote sbr=(SalesEJBRemote)ctx.lookup("StudentBean/remote");
			Sales s= new Sales();
			
			if(val.equals("add"))
			{
				int id=Integer.parseInt(request.getParameter("productId"));
				double qty=Double.parseDouble(request.getParameter("productQty"));
				s.setProductId(id);
				s.setQuantity(qty);
				
			sbr.totalPrice(id, qty);
			pw.write("<p>Total price is:</p>");
			}	
		} catch (NamingException e) {
			e.printStackTrace();
		}
		System.out.println("Data added Succsessfully");
	}

}
