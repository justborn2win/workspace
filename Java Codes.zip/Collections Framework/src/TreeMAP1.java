import java.util.*;


public class TreeMAP1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TreeMap hs=new TreeMap();
		
		
		
		hs.put(1, "Jesvin");
		hs.put(2, "Joy");
		hs.put(3, "Koshy");
		
		
		
		System.out.println(hs);

	}

}
