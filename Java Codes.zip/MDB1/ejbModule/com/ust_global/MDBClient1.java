package com.ust_global;

import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class MDBClient1 {
	/**
	 * @param args
	 * @throws NamingException
	 * @throws JMSException
	 */
	public static void main(String[] args) throws NamingException, JMSException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		Topic topic = (Topic) ctx.lookup("/topic/GuruTopic");
		TopicConnectionFactory factory = (TopicConnectionFactory) ctx
				.lookup("ConnectionFactory");
		TopicConnection connection = factory.createTopicConnection();
		TopicSession session = connection.createTopicSession(false,TopicSession.AUTO_ACKNOWLEDGE);
		TextMessage textMessage = session.createTextMessage("Hello GoodBye");
		TopicPublisher topicSender = session.createPublisher(topic);
		topicSender.publish(textMessage);
		System.out.println("Message successfully sent");
	}
}