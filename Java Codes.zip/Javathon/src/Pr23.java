
public class Pr23 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name="Jesvin";
		for(int i=1;i<=10;i++)
		{
			System.out.println(name);
		}

	}

}
