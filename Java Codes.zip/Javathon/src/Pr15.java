 
public class Pr15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20,c=20;
		int d=0;
		if(a==20)
		{
			d++;
		}
		if(b==20)
		{
			d++;
		}
		if(c==20)
		{
			d++;
		}
		System.out.println("20 is repeated "+d+" times");
		
		
		

	}

}
