
public class Pr36 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=5;i<=25;i=i+5)
		{
			System.out.print(i+" ");
		}

	}

}
