package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface BooksBeanRemote {

}
