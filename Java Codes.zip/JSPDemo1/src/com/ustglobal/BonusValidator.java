package com.ustglobal;

public class BonusValidator {
	
	public double calculateBonus(String employeeName, double employeeSalary, String employeeGrade)

	{

		double bonus=0.0;

		if (employeeSalary < 10000 && employeeGrade.equalsIgnoreCase("A"))

		{
			bonus=1000;
		}
		else if(employeeSalary >= 10000 && employeeSalary < 20000 && employeeGrade.equalsIgnoreCase("A"))
		{
			bonus=500;
		}
		else if(employeeSalary >= 20000 && employeeSalary < 30000 && employeeGrade.equalsIgnoreCase("B"))
		{
			bonus=750;
		}
		double netSalary=employeeSalary+bonus;
		return netSalary;

	}

}
