import org.junit.Test;
import org.junit.Assert;

public class TestJUnit{
@Test
public void testMinAndMax(){
MinAndMax m=new MinAndMax();

double a[]={10,20,3,40,55,70};
double act=m.findMinValue(a);
Assert.assertEquals(3.0, act,0.1);
}

public void testMinAndMax1(){
MinAndMax m1=new MinAndMax();
double a[]={10,20,3,40,55,70};
double act1=m1.findMaxValue(a);
Assert.assertEquals(70.0, act1,0.1);
}

}