import java.io.*;
import java.util.*;
public class TestMembers 
{
	static BufferedReader bufReader=new BufferedReader(new InputStreamReader(System.in));
	static String name, age, language, graduate, employed;
	static int stop=0, choice=0, flag=0, flag1=0, flag2=0;
	static int i=1;
	String fileRead="";
	String employeeContract;

	static HashMap memberMap=new HashMap();
	Set keys=memberMap.keySet();
	Iterator iter=keys.iterator();

	
	public static void main(String[] args) throws IOException 
	{
		BufferedWriter BuffWriter=new BufferedWriter(new FileWriter("Members.txt",true));	
		RandomAccessFile raf=new RandomAccessFile("Members.txt", "rw");
		do
		{

			System.out.println("Do you want to enter Employee Details?(Press 0 for no, Press 1 for yes");
			stop=Integer.parseInt(bufReader.readLine());
			if(stop==0)
			{

				System.out.println("Thank you for entering the details");
				BuffWriter.close();
				raf.seek(0);
				String file1Read=raf.readLine();

				while (file1Read!=null) 
				{
					String arr[]=file1Read.split(",");
					String mName=arr[0];
					String mAge=arr[1];
					String mLanguage=arr[2];
					String mGraduate=arr[3];
					String mEmployed=arr[4];
					

					Members mem=new Members(mName, mAge, mLanguage, mGraduate, mEmployed);
					memberMap.put(i, mem);
					i++;
					file1Read=raf.readLine();
				}
				break;
			}else if(stop==1)
			{
				System.out.println("Enter Employee Name: ");
				name=bufReader.readLine();
				System.out.println("Enter Age");
				age=bufReader.readLine();
				System.out.println("Enter Native Language");
				language=bufReader.readLine();
				System.out.println("Enter Graduation (UG/PG):");
				graduate=bufReader.readLine();
				System.out.println("Enter if Employed (Y/N):");
				employed=bufReader.readLine();
				
				BuffWriter.write(name+","+age+","+language+","+graduate+","+employed);
				BuffWriter.newLine(); 
			}

		}while(stop!=0);

		TestMembers testmember=new TestMembers();

		while(choice!=7)
		{
			System.out.println("1. Display all Details");
			System.out.println("2. Display list of employees who speak a particular language");
			System.out.println("3. List all employees who are Undergraduate");
			System.out.println("4. List all employees who are Postgraduate");
			System.out.println("5. List all employees who are Employed");
			System.out.println("6. List all employees who are Not Employed");
			System.out.println("7. Quit");
			
			System.out.println("Enter your Choice");
			choice=Integer.parseInt(bufReader.readLine());

			switch (choice) 
			{
				case 1:
				testmember.printAllDetails();
				break;

				case 2:		
					testmember.printLanguage();
				break;

				case 3:
					testmember.printUG();
				break;

				case 4:
					testmember.printUG();
				break;

				case 5:
					testmember.yesEmployed();
				break;
 
				case 6:
					testmember.notEmployed();
				break;

				case 7:
				System.exit(0);

		raf.close();
				default:
				break;
		}

	}

}
	

	public void printAllDetails() throws IOException
	{
		RandomAccessFile raf=new RandomAccessFile("Members.txt", "rw");
		raf.seek(0);
		fileRead=raf.readLine();
		while (fileRead!=null) 
		{
			System.out.println(fileRead);
			fileRead=raf.readLine();
		}
	}
	
	public void printLanguage() throws IOException
	{
		System.out.println("Enter the Language");
		String lang=bufReader.readLine();
		
		iter=keys.iterator();
		while(iter.hasNext())
		{
			int key= (Integer) iter.next();
			Members member=(Members) memberMap.get(key);

			if(lang.equalsIgnoreCase(member.language))
			{
				System.out.println(member.name);
				break;
			}
			else
			{
				flag=1;
			}
			
			if (flag==1)
			{
				System.out.println("no such person");
			}
		}
	}
	
	
	public void printUG()
	{
		iter=keys.iterator();
		while(iter.hasNext())
		{
			int key= (Integer) iter.next();
			Members member=(Members) memberMap.get(key);
			if(member.graduate.equalsIgnoreCase("UG"))
			{
				System.out.println(member.name+" is an under graduate");
				break;
			}
			else
			{
				flag2=1;
			}
			
			
			if (flag2==1)
			{
				System.out.println("no graduates");
			}
		}
	}
	
	public void printPG()
	{
		iter=keys.iterator();
		while(iter.hasNext())
		{
			int key= (Integer) iter.next();
			Members member=(Members) memberMap.get(key);

			if(member.graduate.equalsIgnoreCase("PG"))
			{
				System.out.println(member.name+" is a post graduate");
				break;
			}
			else
			{
				flag1=1;
			}
			
			
			if (flag1==1)
			{
				System.out.println("no post graduates");
			}
		}
	}
	
	
	public void yesEmployed()
	{
		iter=keys.iterator();
		while(iter.hasNext())
		{
			int key= (Integer) iter.next();
			Members member=(Members) memberMap.get(key);
			
			if(member.employed.equalsIgnoreCase("Y"))
			{
				System.out.println(member.name+" is employed");
			}
		}
	}
	
	
	public void notEmployed()
	{
		iter=keys.iterator();
		while(iter.hasNext())
		{
			int key= (Integer) iter.next();
			Members member=(Members) memberMap.get(key);

			if(member.employed.equalsIgnoreCase("N"))
			{
				System.out.println(member.name+" is not employed");
			}
		}
	}
} 