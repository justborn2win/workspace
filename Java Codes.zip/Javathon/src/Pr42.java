
public class Pr42 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=0;
		int a=0;
		while(i<=5)
		{
			a=a+i;
			System.out.println(a);
			i=i+1;
			
		}

	}

}
