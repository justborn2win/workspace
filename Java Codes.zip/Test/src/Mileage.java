
public class Mileage {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double mileage = 25;
		double totalMileage = 60 * mileage;
		System.out.println(totalMileage);
	
		double cost = 15000;
		double phone = 100000/cost;
		double money_left = 100000%15000;
		System.out.println(money_left);
		System.out.println(phone);

	}

}
