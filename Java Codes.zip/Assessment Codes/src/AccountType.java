import java.io.*;

class AccountType extends CustomerAccount implements Serializable{
	/**
	 * 
	 */
	

	public AccountType(String custName, int accNo, double balance,
			String typeOfAccount) {
		super(custName, accNo, balance, typeOfAccount);
		
	}
	
	public void diplayAllDetails()
	{
		System.out.println("Account holder name: "+custName);
		System.out.println("Account number: "+accNo);
		System.out.println("Balance: "+balance);
		System.out.println("Account type: "+typeOfAccount);
		
	}
	public void displayBalance()
	{
		System.out.println("Balance is "+balance);
	}
	
	public void withDraw()
	{
		double withdraw=0.0;
		if(withdraw>balance)
		{
			System.out.println("Sorry insufficient balance");
		}
		else
		{
			balance=balance-withdraw;
			System.out.println("You have withdrawn "+withdraw);
			System.out.println("your current balance is "+balance);
		}
	}
	
	public void deposit()
	{
		double deposit=0.0;
		balance=balance+deposit;
		System.out.println("You desposited "+deposit);
		System.out.println("Your current balance is "+balance);
	}
	
	public void issueCheque()
	{
		int choice=0;
		if(typeOfAccount.equalsIgnoreCase("Current"))
		{
			System.out.println("Do you want to issue cheque book?");
			System.out.println("Choose: 1.Yes or 2.No");
			if(choice==1)
			{
				System.out.println("Your cheque will be issued within 2 days");
			}
			else
			{
				System.out.println("Thank you");
			}
		}
	}
	
	public double imposePenality(){
		double ret=1;
		if(balance<=500) 
		{ 
			double penality=50;
			balance=balance-penality;
			ret=0;
		} 
		else 
		{
			System.out.println("No penality imposed!");
		}
		return ret;
	}
	
	public void computeInterest()
	{
		
		double interest=0.0;
		interest=balance*0.05;
		balance=balance+interest;
		System.out.println("Your interest is "+interest);
		System.out.println("Your balance after adding interest is "+balance);
		
	}



}


