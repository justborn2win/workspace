package com.ust_global;

import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class Users {
	String userName;
	String password;
	
	Properties p;
	Context ctx;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Users() throws NamingException {
		p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		ctx=new InitialContext(p);
	}
	
	public String loginUser() throws NamingException
	{	
		String msg="";
		MyUserEJBRemote mue=(MyUserEJBRemote) ctx.lookup("MyUserEJB/remote");
		
		if((mue.loginUser(this.userName, this.password))==true)
		{
			 msg="success";
		     FacesContext fc=FacesContext.getCurrentInstance();
		     ExternalContext ec=fc.getExternalContext();
		     HttpSession session=(HttpSession) ec.getSession(false);
		     session.setAttribute("userName", this.userName);
		}
		else
		{
		     msg="failure";
		}
		System.out.println("returning "+msg);
		return msg;
	}
	
	 public String logout() 
	   {
		 FacesContext fc = FacesContext.getCurrentInstance();
         ExternalContext ec = fc.getExternalContext();
         HttpSession session = (HttpSession) ec.getSession(false);
         String msg = "";
         if (session != null) 
         {
               String x = (String) session.getAttribute("name");
               if (x != null) 
               {
                     System.out.println("We are going to logout/kick off the user");
                     session.removeAttribute("username");
                     session.invalidate();
                     msg = "loggedOut";
               }
         }
         return msg;
	   }
	 
	public String signUp()
	{
		String msg="";
		
		try {
			MyUserEJBRemote mue=(MyUserEJBRemote) ctx.lookup("MyUserEJB/remote");
			MyUsers newUser=new MyUsers();
			newUser.setUserName(this.userName);
			newUser.setPassword(this.password);
			mue.signUpUser(newUser);
			
			FacesContext fc=FacesContext.getCurrentInstance();
		    ExternalContext ec=fc.getExternalContext();
		    HttpSession session=(HttpSession) ec.getSession(false);
		    session.setAttribute("userName", this.userName);
			msg="added";
			System.out.println("signup"+msg);
			
		} 
		catch (NamingException e1) 
		{
			System.out.println("Some error");
		}
		
		System.out.println("added "+msg);
		return msg;
	}
	
	
	

	
}
