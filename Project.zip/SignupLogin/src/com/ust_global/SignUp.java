package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

import com.ust_global.user.LoginCredentialsBeanRemote;
import com.ust_global.user.User;
import com.ust_global.user.UserDetails;
import com.ust_global.user.UserDetailsBeanRemote;

public class SignUp {


	String name;
	String userName;
	String email;
	long mobile;
	String passWord;
	String confirmPassword;
	long conformMobileNumber;
	String msg="";
	List<UserDetails> allSignInDetails = new ArrayList<UserDetails>();
	String out="";
	
	
	public String signUp() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UserDetailsBeanRemote users=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		LoginCredentialsBeanRemote login=(LoginCredentialsBeanRemote) ctx.lookup("LoginCredentialsBean/remote");
		
		User usr=new User();
		UserDetails user = new UserDetails();
		
		
		List<User> allUsers=login.readAllUserNames();
		
		
		msg= "failureAdd";
		if(users!=null && usr!=null)
		{
			if(!allUsers.contains(userName))
			{
				FacesContext fc = FacesContext.getCurrentInstance();
				ExternalContext ec = fc.getExternalContext();
				HttpSession session = (HttpSession) ec.getSession(false);
				session.setAttribute("userName", this.userName);
					
				if(getPassWord().equals(getConfirmPassword()))
				{
					if(getEmail().contains("@")&&(getEmail().contains(".")))
					{
						usr.setUserName(getUserName());
						usr.setPassWord(getPassWord());
						
						user.setName(name);
						user.setUserName(userName);
						user.setEmail(email);
						user.setMobileNumber(mobile);
						
						try
						{
							users.addUser(user);
							login.addUser(usr);
							msg= "successAdd";
			
						}
						catch (Exception e) 
						{
							msg="failureAdd";
						}
					}
					else
						msg="inavlidemail";
				}
				else
					msg="failureConfirmPassword";
			}
		}
		System.out.println(msg);
		return msg;
	}
	public String readAllUserDetails() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UserDetailsBeanRemote users=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		List<UserDetails> usr = users.viewAllDetails();
		if(!usr.isEmpty())
		{
			msg="read"; // read all the details
		}	
		else
		{
			msg="failure";
		}
		return msg;
	}	
	public String removeAccountDetails() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UserDetailsBeanRemote users=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		User usr = new User();
		if(users!=null)
		{
			if(this.passWord.equals(usr.getPassWord()))
			{
			if(this.mobile==conformMobileNumber)
			{
			users.removeUserDetails(userName);
			msg="remove";
			}
			}
		}
		else
		{
			msg="notRemove";
		}
		return msg;
	}
	public String updateDetails() throws NamingException
	{
		msg="updatefailed";
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UserDetailsBeanRemote users=(UserDetailsBeanRemote) ctx.lookup("UserDetailsBean/remote");
		User usrs = new User();
		if(users!=null)
		{
			if(this.passWord.equals(usrs.getPassWord()))
			{
				if(this.mobile==conformMobileNumber)
				{
					UserDetails usr = users.updateUserDetails(name, userName, email, mobile);
					if(usr!=null)
					{
						msg="upadetedSuccesfully";
					}
				}
			}
		}
		return msg;
	}
	
/*getters and setters*/	
	public String getOut() {
		return out;
	}

	public void setOut(String out) {
		this.out = out;
	}

	public SignUp()
	{
		
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	public String getPassWord() {
		return passWord;
	}


	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public long getConformMobileNumber() {
		return conformMobileNumber;
	}

	public void setConformMobileNumber(long conformMobileNumber) {
		this.conformMobileNumber = conformMobileNumber;
	}

	public List<UserDetails> getAllSignInDetails() {
		return allSignInDetails;
	}

	public void setAllSignInDetails(List<UserDetails> allSignInDetails) {
		this.allSignInDetails = allSignInDetails;
	}
}
