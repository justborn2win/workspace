package com.ust_global;

import java.util.ArrayList;

import javax.ejb.Stateful;

/**
 * Session Bean implementation class EmployeeBean
 */
@Stateful
public class EmployeeBean implements EmployeeRemote {
	ArrayList allNames;
    /**
     * Default constructor. 
     */
    public EmployeeBean() {
        allNames=new ArrayList();
    }

	@Override
	public void addNames(String name) {
		allNames.add(name);
		
	}

	@Override
	public ArrayList displayAllNames() {
		
		return allNames;
	}

}
