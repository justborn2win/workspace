import java.util.*;


public class LinKedHASHAMAp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LinkedHashMap hs=new LinkedHashMap();
		
		
		
		hs.put("one", "Jesvin");
		hs.put("two", "Joy");
		hs.put("three", "Koshy");
		
		System.out.println(hs);
		
		System.out.println();
		System.out.println();
		
		String Name=(String)hs.get("one");
		System.out.println(Name);
		
		System.out.println(hs.get("two"));
		

	}

}
