package com.ust_global;

public class ShapeFactory  {
	public Shape getShape(String x)
	{	
		Shape s=null;
		
		if(x.equalsIgnoreCase("Circle"))
		{
			s=new Circle();
		}
		else if(x.equalsIgnoreCase("Rectangle"))
		{
			s=new Rectangle();
		}
		else if(x.equalsIgnoreCase("Square"))
		{
			s=new Square();
		}
		
		return s;
	}
}
