
public class Pr39 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=7;i<=70;i=i+7)
		{
			System.out.print(i+" ");
		}

	}

}
