
public class MultNonZero {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]=new int[10];
		no[0]=1;
		no[1]=3;
		no[2]=5;
		
		int mult=1;
		for(int i=0; i<no.length; i++)
		{
			if(no[i]!=0)
			mult = mult*no[i];
		}
		System.out.println(mult);
		
		

	}

}
