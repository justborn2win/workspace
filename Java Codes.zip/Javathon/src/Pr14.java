
public class Pr14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20,c=30;
		int sum=a+b+c;
		if(sum>100)
			System.out.println("I'm on cloud 9");
		else 
			System.out.println("I'm trying to reach the cloud");

	}

}
