
public class Pr40 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=7;
		while(i<=70)
		{
			System.out.print(i+" ");
			i=i+7;
		}

	}

}
