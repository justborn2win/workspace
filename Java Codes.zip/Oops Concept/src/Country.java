import java.io.*;
public class Country {
	

	/**
	 * @param args
	 * @throws IOException 
	 */

	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		String b[]=new String[10];
		int count=0;
		
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println("Enter country name:");
			String cot=br.readLine();
			
			System.out.println("Enter capital name");
			String cap=br.readLine();
			
			
			Countrys a[]=new Countrys[10];
			a[i].setDetails(cot, cap);
//			b[i]=a[i];
			
			
			
		}
		
		for(int i=0;i<b.length;i++)
		{
			String c=br.readLine();
			if(c.equalsIgnoreCase(b[i]))
			{
				count++;
			}
			else
			{
				count=0;
			}
		}
		

	}

}
