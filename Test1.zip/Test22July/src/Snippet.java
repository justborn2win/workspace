

public class Snippet {
	D:\Jesvin\Java Codes\jQueryDemo\WebContent\jquery-3.0.0.min.js
}