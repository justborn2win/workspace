import java.sql.*;
public class FirstJDBCProgram {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		//Load the JDBC driver class
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Please check your path");
			System.exit(0);
		}
		
		//Connect to the database
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		
		if(con!=null)
		{
			System.out.println("Successfully connected to database");
		}
		else
		{
			System.out.println("Please check your password");
		}
		
		
	}

}
