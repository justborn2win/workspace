
public class Find_the_number {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no=2,diff=1;
		for(int i=1;i<=10;i++)
		{
			no=no*diff;
			System.out.println(no);
			diff=diff+1;
			if(i==10)
			{
			System.out.println("The 10th Number in the series is " +no);
			}
		}
	}

}
