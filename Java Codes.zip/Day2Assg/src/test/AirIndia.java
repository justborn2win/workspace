package test;

public class AirIndia implements Flight{

	@Override
	public void Airways() {
		// TODO Auto-generated method stub
		System.out.println("You are travelling with Air India from Dubai to Bangalore ");

	}

}
