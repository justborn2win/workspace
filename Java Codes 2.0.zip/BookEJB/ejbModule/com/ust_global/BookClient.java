package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BookClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		try {
			Context ctx=new InitialContext(p);
			BooksBeanRemote bbr=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
			
//			Books b=new Books();
//			b.bookId=2;
//			b.bookName="C++";
//			b.authorName="Jesvin";
//			bbr.addBooks(b);
			
//			List<Books> allBooks=bbr.showAllBooks();
//			
//			for(int i=0;i<allBooks.size();i++)
//			{
//				System.out.println(allBooks.get(i).getBookId()+" "+allBooks.get(i).getBookName()+" "+allBooks.get(i).getAuthorName());
//			}
			
			List<Books> allBooks=bbr.findBookByAuthor("Jesvin");
			for(int i=0;i<allBooks.size();i++)
			{
				System.out.println(allBooks.get(i).getBookId()+" "+allBooks.get(i).getAuthorName()+" "+allBooks.get(i).getBookName());
			}
			
			
			
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
