import java.util.*;
public class Locales {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Locale[] allLocale=Locale.getAvailableLocales();
		
		for(int i=0; i<allLocale.length;i++)
		{
			Locale specificLocale=allLocale[i];
			System.out.println(specificLocale.getDisplayCountry());
			System.out.println(specificLocale.getDisplayLanguage());
		}
		
		
	}

}

