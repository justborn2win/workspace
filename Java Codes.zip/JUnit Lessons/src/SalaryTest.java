import org.junit.*;
public class SalaryTest {
	@Test
	public void testSalary()
	{
		Employee e=new Employee();
		e.salary=10000;
		Assert.assertTrue(e.salary>0);
	}
	
}
