class GreaterThan10Exception extends Exception
{

	static int sum=0;

	public static void add(int x) throws GreaterThan10Exception
	{
		if (x>10)
		{
			GreaterThan10Exception gt=new GreaterThan10Exception();
			throw gt;
		}
		else
		{
			sum=sum+x;
		}
	}
	public static void printSum()
	{
		System.out.println("The sum is "+sum);
	}
}


