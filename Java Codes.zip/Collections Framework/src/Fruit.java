import java.io.*;
import java.util.*;
public class Fruit {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		HashSet s=new HashSet();
		
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		while(true)
		{	
			System.out.println("Enter a fruit");
			String a=br.readLine();
			if(a.equalsIgnoreCase("stop"))
			{
				break;
			}
			else if(s.contains(a))
			{
				System.out.println(a+" has already been added");
			}
			else
			{
				s.add(a);
			}
		}
		
		System.out.println(s);
	}
	
}
