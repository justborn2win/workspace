package Abstraction;

public class C3 extends C2{

	@Override
	void m() {
		// TODO Auto-generated method stub
		System.out.println("I am m from class C3");
	}

	
}
