package com.ust_global;



import javax.ejb.*;

@Remote
public interface NumbersRemote {
	public String OddorEven(int a);
}
