import java.util.Random;
import java.util.Scanner;


public class RandomIntegers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand=new Random();
		int x=rand.nextInt(10);
		System.out.println(x);
		
		int userGuess=0;
		int attempt=0;
		
		Scanner scn=new Scanner(System.in);
		while(true)
			{
			System.out.println("Guess a number between 1 and 10");
			userGuess=scn.nextInt();
			attempt++;
			
			if(x==userGuess)
			{
				System.out.println("you got it in attempt no "+attempt);
				break;
			}
			else
			{
				System.out.println("Wrong");
				if(x>userGuess)
					System.out.println("Enter a bigger number");
				else
					System.out.println("Enter a smaller number");
				
				
				if (attempt==10)
					break;
				System.out.println("Keep guessing...your attempt no "+attempt);
			}
				
			}
		
		
		

	}

}
