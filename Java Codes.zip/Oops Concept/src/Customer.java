
public class Customer {
	
	 int custId;
	 String custFirstName;
	 String custLastName;

}
