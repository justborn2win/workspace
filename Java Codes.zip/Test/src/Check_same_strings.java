
public class Check_same_strings {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("First name is " +args[0]+ " and second name is " +args[1]);
		if(args[0].equalsIgnoreCase(args[1]))
			System.out.println("The strings are equal");
		else
			System.out.println("Names are unequal");


	}

}
