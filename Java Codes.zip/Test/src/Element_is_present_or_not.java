
public class Element_is_present_or_not {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,20,30,40,50,60,70,80,90,100};
		int c=0;
		for(int i=0;i<no.length;i++)
		{
			if (no[i]==30)
			{
				c++;
			}
			
		}
		if (c==1)
		{
				System.out.println("Given number is present");
		}
		else
		{
				System.out.println("Given number is absent");
		}		
		


	}

}
