package com.ust_global;

import javax.ejb.*;

@Stateless
public class ArrayBeans implements ArrayRemote {

	public MyNumber ArraySum(int a[]) {
		String msg="Sum of all numbers in the array is ";
		String msg2=" and average is ";
		int sum=0;
		int avg=0;
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];	
		}
		avg=sum/a.length;
		
		MyNumber m=new MyNumber();
		m.sum=sum;
		m.average=avg;
		return m;
		
		
		
		
	}

}
