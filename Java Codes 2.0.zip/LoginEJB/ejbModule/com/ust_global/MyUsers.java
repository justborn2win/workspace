package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity(name="MyUsers")
public class MyUsers implements Serializable {

	private static final long serialVersionUID = 1L;
	String userName;
	String password;
	
	
	MyUsers() {
		
	}
	
	@Id
	@Column(name="username")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String login(){
		String msg="";
		if(this.userName.equals(this.password))
		{
			msg="success";
		}
		else
		{
			msg="failure";
		}
		return msg;
	}

}
