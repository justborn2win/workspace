
public class Pr11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20,c=0;
		if(a<b)
			c=b-a;
		System.out.println(c);

	}

}
