
public class Customer {
	String firstName;
	String lastName;
	String city;
	
	
	public void setCustomerDetails(String fName, String lName, String c) {
	
		firstName = fName;
		lastName = lName;
		city=c;
	}


	public void printCustomerDetails()
	{
		System.out.println("Customer name: "+firstName+" "+lastName);
		
	}
}
