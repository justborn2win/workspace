
public class Smallest_no_in_array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,20,30,40,50,60,70,80,90,100};
		int small=no[3];
		for (int i=0;i<no.length;i++)
		{
			
			if(no[i]<small)
				small=no[i];
		}
		System.out.println("The smallest number is " +small);
	}

}


