
public class TestProduct {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Products product1=new Products("Laptop", "Dell", 1000, 1);
		product1.calculateDiscount();
		product1.printPurchaseDetails();
		
		Products product2=new Products("Desktop", "HP", 1000, 1);
		product2.calculateDiscount("Desktop");
		product2.printPurchaseDetails();
		
	}

}
