
public class Room {
	 String nameOfTheRoom;
	 int seatingCapacity;
	 boolean hasDisplay;
	 boolean hasSpeaker;
	 double costPerDay;
	 
	 
	 public void setRoomDetails(String nr, int sc, boolean hd, boolean hs, double cp)
	 {
		 nameOfTheRoom=nr;
		 seatingCapacity=sc;
		 hasDisplay=hd;
		 hasSpeaker=hs;
		 costPerDay=cp;
	 }
	 
	 public void printRoomDetails()
	 {
		 System.out.println("Name of the room "+nameOfTheRoom);
		 System.out.println("Seating Capacity of the room "+seatingCapacity);
		 System.out.println("Cost per day of this room "+costPerDay);
		 
		 
		 if(hasDisplay==true)
			 System.out.println("Room has display ");
		 else
			 System.out.println("This room does not have display ");
		 
		 
		 System.out.println();
		 
		 
		 
	 }
	 public void printRoomWithDisplayDetails()
	 {
		 if(hasDisplay==true)
		 {
			 System.out.println("Room has display ");
			 System.out.println("Name of the room "+nameOfTheRoom);
			 System.out.println("Seating Capacity of the room "+seatingCapacity);
			 System.out.println("Cost per day of this room "+costPerDay);
		 }
		 else
			 System.out.println("This room does not have display ");
		 
		 
		 System.out.println();
		 
		 
		 
	 }
} 
