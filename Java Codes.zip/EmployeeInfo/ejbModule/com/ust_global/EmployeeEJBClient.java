package com.ust_global;
import java.io.*;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EmployeeEJBClient {

	public static void main(String[] args) throws NamingException, IOException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		
		EmployeeRemote emp1 = (EmployeeRemote) ctx.lookup("EmployeeBean/remote");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("------------First Client----------------");
		System.out.println("Press 0 to stop entering");
		String name="";
		do
		{
			System.out.println("Please enter names");
			name=br.readLine();
			emp1.addNames(name);
		
		}
		while(!name.equalsIgnoreCase("0"));
		
		System.out.println(emp1.displayAllNames());
		System.out.println("---------------------------------------");
		System.out.println();
		
		EmployeeRemote emp2 = (EmployeeRemote) ctx.lookup("EmployeeBean/remote");
		System.out.println("-------------Second CLient---------------");
		System.out.println("Press 0 to stop entering");
		String name1="";
		do
		{
			System.out.println("Please enter names");
			name1=br.readLine();
			emp2.addNames(name1);
		}
		while(!name1.equalsIgnoreCase("0"));
		System.out.println(emp2.displayAllNames());
		
	}

}