package com.ust_global;

public class LaptopSwitchOff implements Command {
	LapTop lt;
	
	
	public void LaptopSwitchoff(LapTop lt)
	{
		this.lt=lt;
	}
	
	@Override
	public void execute() {
		lt.switchOff();
		
	}
}
