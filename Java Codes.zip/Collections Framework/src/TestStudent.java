import java.io.*;
import java.util.*;
public class TestStudent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Books b1=new Books();
		b1.setBookDetails(1, "C++", "Jesvin", 500, "Oracle");
		
		Books b2=new Books();
		b2.setBookDetails(2, "Java", "Jesvin Joy", 1500, "UST");
		
		Books b3=new Books();
		b3.setBookDetails(3, "JavaScript", "Guru", 500, "Oracle");
		
		Ajith a=new Ajith();
		a.setStudentdDetails("Ajith", "Kumar", "5th", "C");
		
		HashMap hm=new HashMap();
		hm.put(a, b1);
		
		HashMap hm1=new HashMap();
		hm.put(a, b2);
		
		HashMap hm2=new HashMap();
		hm.put(a, b3);
		
		HashMap hm3=new HashMap();
		
		Set k=hm.keySet();
		Iterator it=k.iterator();
		
		Set k1=hm.keySet();
		Iterator it1=k1.iterator();
		
		while(it.hasNext())
		{
			Ajith aa=(Ajith)it.next();
			Books bb=(Books)hm.get(k);
			
			while(it1.hasNext())
			{
				Ajith aa1=(Ajith)it1.next();
				Books bb1=(Books)hm1.get(k1);
				
				if(hm.get(k).equals(hm1.get(k1)))
				{
					hm3.put(k, hm.get(k));
				}
			}
			
		}
		
		
	}

}
