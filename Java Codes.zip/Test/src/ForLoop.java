
public class ForLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=1;i<=10;i++)
		{
			System.out.println("My Name is Jesvin");
		}
		for (int i=10; i>=1;i--)
		{
			System.out.println(i);
		}
		for (int i=0; i<=100;i=i+2)
		{
			System.out.println(i);
		}
	}

}
