package com.ust_global;

public class LaptopSwitchOn implements Command {
	LapTop lt;
	
	LaptopSwitchOn(LapTop lt)
	{
		this.lt=lt;
	}
	
	@Override
	public void execute() {
		lt.switchOn();
		
	}
	
}
