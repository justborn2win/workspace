public class TestRectangle {

	/**
	 * @param args
	 */
	public static void main(String[] args){
		Rectangle rect1=new Rectangle();    //using default constructor
		System.out.println("Area of Rectangle 1: "+rect1.getArea());
		
		Rectangle rect2=new Rectangle(7,10);  //using parameterized constructor
		System.out.println("Area of Rectangle 2: "+rect2.getArea());
		
		Rectangle rect3=new Rectangle();
		rect3.setX(10);            //setting x-coordinate
		rect3.setY(12);			   //setting y-coordinate
		System.out.println("x-coordinate: "+rect3.getX());  
		System.out.println("x-coordinate: "+rect3.getY());
		System.out.println("Area of Rectangle 3: "+rect3.getArea());
		
		Rectangle rect4=new Rectangle();
		rect4.xCoordinate=7;			//setting the properties of rectangle x-coordinate 
		rect4.yCoordinate=9;	        //setting the properties of rectangle x-coordinate
		System.out.println("Area of Rectangle 4: "+rect4.getArea());
		
		//To get Area of rectangle we use getArea() method
	}

}
