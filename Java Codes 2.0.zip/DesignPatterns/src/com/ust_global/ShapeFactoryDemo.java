package com.ust_global;

import java.io.*;
public class ShapeFactoryDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		System.out.println("Which shape you want?");
		String s=br.readLine();
		
		ShapeFactory sf=new ShapeFactory();
		Shape shape=sf.getShape(s);
		shape.draw();
	}

}
