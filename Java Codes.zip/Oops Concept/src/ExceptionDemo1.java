public class ExceptionDemo1 {
	
	public static void main(String[] args) {
		int noArray[]={1,2,3,8,12,2,3,5};
		for (int i=0;i<noArray.length;i++)
		{
			System.out.println("Sending the number "+noArray[i]);
			try {
					GreaterThan10Exception.add(noArray[i]);
			} catch (GreaterThan10Exception e) {
				System.out.println("I am encountering a number greater than 10...so can't proceed");
			}
		}
			GreaterThan10Exception.printSum();
		}
	}


