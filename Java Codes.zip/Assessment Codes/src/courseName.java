import java.io.*;
import java.util.*;
public class courseName {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		HashMap courseMap=new HashMap();
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		
		
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter the course id:");
			String courseId=br.readLine();
			
			if(courseId.equalsIgnoreCase("0"))
			{
				System.out.print("Thanks for the input.");
				System.out.println("Please wait, the system is building the required data structure.");
				System.out.println("Done");
				break;
			}
			else
			{
				System.out.println("Enter the course name:");
				String courseName=br.readLine();
				courseMap.put(courseId, courseName);
			}
		}
		
		System.out.println("=======================");
		
		Set<String> keys=courseMap.keySet();
		
		System.out.println("Now, you start querying me.");
		
		for(String k: keys)
		{
			
			String k1=(String) courseMap.get(k);
			
			System.out.println("Enter the course id:");
			String searchId=br.readLine();
			
				if(courseMap.get(k)==searchId)
				{
					courseMap.get(searchId);
						
				}
				else if(k.equalsIgnoreCase("0"))
				{
					System.out.println("Thanks for using my software.Have a great day!!!");
					break;
				}
				else
				{
					System.out.println("Sorry, I don�t have any course with this id.");
				}
			}
		}
			
	}

