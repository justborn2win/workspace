
public class TestProduct {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Product p1=new Product();
		p1.prodId=7;
		p1.prodName="Nokia Mobile";
		p1.prodPrice=17100;
		
		p1.setProductDetails();
		

	}

}
