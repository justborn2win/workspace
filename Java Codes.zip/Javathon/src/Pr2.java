
public class Pr2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20;
		int sum=a+b;
		System.out.println(sum);

	}

}
