import java.io.*;
public class TestTravel {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws Travel 
	 */
	public static void main(String[] args) throws Travel, IOException {
		Travel t1=new Travel();
		t1.journey("Bangalore", "Mumbai", "Hyderabad", 700);
		
		Travel t2=new Travel();
		t2.journey("Bangalore", "Mumbai", "Solapur", 500);
		
		Travel tr[]=new Travel[2];
		tr[0]=t1;
		tr[1]=t2;
		
		InputStreamReader isr=new InputStreamReader(System.in);
	    BufferedReader br=new BufferedReader(isr);
	    System.out.println("1.Make a travel");
	    System.out.println("2.Find Shortest route");
	    System.out.println("3.Find all routes");
	    System.out.println("4.Exit"); 
	    System.out.println("===========================");
	    
	    
	   }		
	}

