import java.util.*;
public class VectorReverse {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector v=new Vector(); //default capacity is 10

		v.add("Jesvin");
		v.add("Sreenath");
		v.add("Vaisakh");
		v.add("Riya");
		v.add("Anju");
		v.add("Jackson");
		v.add("Clinton");
		v.add("Rahul");
		v.add("Hari");
		v.add("Fihad");
		v.add("Nikhil");
		v.add("Eliza");
		v.add("Abhirami");
		v.add("Keith");
		
		for(int i=0;i<v.size();i++)
			System.out.println(v.get(i)); //how many elements are there
		
		System.out.println("========================");
		
		for(int i=v.size()-1;i>=0;i--)
			System.out.println(v.get(i));

	}

}
