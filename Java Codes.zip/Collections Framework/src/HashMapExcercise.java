import java.util.*;
import java.io.*;
public class HashMapExcercise {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {

		HashMap hm=new HashMap();
		
		hm.put(1, "Sachin");
		hm.put(2, "Dhoni");
		hm.put(3, "Kohli");
		hm.put(4, "Prasad");
		hm.put(5, "Ashwin");
		hm.put(6, "Raina");
		hm.put(7, "Azhar");
		hm.put(8, "Sreesanth");
		
		
		InputStreamReader a=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(a);
		
		System.out.println("Enter a key");
		int key=Integer.parseInt(br.readLine());
		String Player=(String) hm.get(key);
		if(hm.containsKey(key))
			System.out.println("The Player is "+Player);
		else
			System.out.println("No such player ");

	}

}
