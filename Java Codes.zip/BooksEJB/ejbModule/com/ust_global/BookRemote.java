package com.ust_global;

import java.util.ArrayList;

import javax.ejb.Remote;

@Remote
public interface BookRemote {
	public void addBooks(String books);
	
	public ArrayList displayAllBooks();
}
