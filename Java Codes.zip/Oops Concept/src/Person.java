
public class Person {
	String name;
	int age;
	String Profession;
	double salary;
	double bonus=0.0;
	double netSalary=0.0;
	
	public void whatIsYourName()
	{
		System.out.println("I am "+name);
	}
	public void howOldAreYou()
	{
		System.out.println("I am " +age+ " years old");
	}
	public void whatJobAreYouIn()
	{
		System.out.println("I am " +Profession+ " at UST global");
	}
	public void whatIsYourSalary()
	{
		System.out.println("My salary is "+salary);
	}
	public void bonus()
	{
		if(salary<10000)
		{
			bonus=salary*(20.0/100);
			
		}
		else
		{
			bonus=salary*(15.0/100);
		}
		netSalary=salary + bonus;
		System.out.println("My bonus is "+bonus);
		System.out.println("So my net salary is "+netSalary);
	}
}
