package test;

public class TestCompare {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp e= new Emp();
		double a=10000.00;
		double b=12000.00;
		
		e.max(a, b);
		
		Line l=new Line();
		 a=2.5;
		 b=1.4;
		 
		 l.max(a, b);
		
		
		
	}

}
