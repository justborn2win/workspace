class Hello
{
	public static void main(String args[])
	{
		System.out.println(args[0]+" works in "+args[1]+" and lives in "+args[2]);
		
	}
}