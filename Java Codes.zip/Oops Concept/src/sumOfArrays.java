
public class sumOfArrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[]={10,6,9,2,3,1,5};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		System.out.println(sum);
	}

}
