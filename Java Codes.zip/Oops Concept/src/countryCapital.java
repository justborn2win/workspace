import java.io.*;
public class countryCapital {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		String a=new String();
		String b[]=new String[10];
		int count=0;
		
		for(int i=0;i<b.length;i++)
		{
			System.out.println("Enter a country:");
			a=br.readLine();
			b[i]=a;
			i++;
			System.out.println("Enter a capital");
			a=br.readLine();
			b[i]=a;
			
		}
		
		System.out.println("Enter a country whose capital you want to know:");
		
		InputStreamReader isr1=new InputStreamReader(System.in);
		BufferedReader br1=new BufferedReader(isr1);
		String c=br.readLine();
		
		for(int i =0;i<b.length;i++)
		{
			if(c.contentEquals(b[i]))
					{
						count=1;
						System.out.print(b[i+1]);
					}	
			
			
			
		}
		
		if(count==1)
		{
			System.out.print(" is the capital of your country");
		}
		else
		{
			System.out.println("No country found");
		}
		
		

	}

}
