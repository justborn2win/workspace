public class Members {
	
	String name;
	String age;
	String language;
	String graduate;
	String employed;
	
	
	public Members(String n, String a, String l, String g, String e) {
		this.name=n;
		this.age=a;
		this.language=l;
		this.graduate=g;
		this.employed=e;
		
	}
	
	public void printDetails()
	{
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Language: "+language);
		System.out.println("Graduation: "+graduate);
		
		if(employed.equalsIgnoreCase("y"))
			System.out.println("This person is Employed.");
		else
			System.out.println("This person is not Employed.");
	
	}
}
