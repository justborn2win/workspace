
public class TestTV {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TV sony=new TV();
		
		sony.brand="SONY";
		sony.type="LED";
		sony.size=52;
		sony.currentChannel=6;
		sony.currentVolume=30;
		
		sony.switchOn();
		sony.increaseVolume();
		sony.increaseChannel();
		sony.switchOff();
		
		System.out.println();
		System.out.println();
		
		
		TV lg=new TV();
		
		lg.brand="LG";
		lg.type="Flatron";
		lg.size=62;
		lg.currentChannel=10;
		lg.currentVolume=25;
		
		lg.switchOn();
		lg.increaseVolume();
		lg.increaseChannel();
		lg.switchOff();
		
		
		

	}

}
