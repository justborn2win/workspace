
public class Program extends Channel {
	String programName;
	String programType;
	Viewers viewers[];
	
	public void setProgramDetails(String pName, String pType)
	//method to set program details
	{
		programName=pName;
		programType=pType;
	}
	
	public void printProgramDetails()
	//method to print program details
	{
		System.out.println("Program Name: "+programName);
		System.out.println("Program Type: "+programType);
	} 
}
