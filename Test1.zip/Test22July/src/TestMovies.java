import java.io.*;
import java.util.*;
public class TestMovies {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bWriter=new BufferedWriter(new FileWriter("movies.txt",true));
		RandomAccessFile raf =new RandomAccessFile("movies.txt", "rw");
		System.out.println("*********Welcome*************");
		int choice=0;
		int i=0;
		HashMap hm=new HashMap();
		do
		{
			System.out.println("Enter 1 to enter movie details or 0 to exit");
			choice=Integer.parseInt(br.readLine());
			if(choice==1)
			{
				System.out.println("Enter Movie name");
				String movieName=br.readLine();
				System.out.println("Enter Movie Langauge");
				String movieLang=br.readLine();
				System.out.println("Enter Movie certification (A/U)");
				String movieCert=br.readLine();
				bWriter.write(movieName+","+movieLang+","+movieCert);
				bWriter.newLine();
			}
			else if (choice==0)
			{

				System.out.println("Thank you for entering the details");
				bWriter.close();
				raf.seek(0);
				String line=raf.readLine();

				while (line!=null) 
				{
					String arr[]=line.split(",");
					String mName=arr[0];
					String mLang=arr[1];
					String mCert=arr[2];
					Movies mov1=new Movies(mName,mLang,mCert);
					hm.put(i, mov1);
					i++;
					line=raf.readLine();
				}
				break;
			
		}	
	}while(choice!=0);

}
}
