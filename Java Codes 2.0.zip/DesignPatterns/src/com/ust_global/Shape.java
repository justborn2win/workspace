package com.ust_global;

public interface Shape {
	public void draw();
}
