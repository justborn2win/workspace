
public class JavaTechnology extends GIPROProject {
	
	public JavaTechnology(String projectID, String clientName) {
		super(projectID, clientName);
		// TODO Auto-generated constructor stub
	}


	static String database="Oracle";

	
	public void printProjectDetails()
	{
		printDetails();
		System.out.println("Database:"+database);
		System.out.println();
	}
}
