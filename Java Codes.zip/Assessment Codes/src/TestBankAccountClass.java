
import java.io.*;
 
public class TestBankAccountClass {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		
//		ObjectInputStream ois= new ObjectInputStream(new FileInputStream("bank.txt"));
		 CurrentBankAccount cba = new  CurrentBankAccount();
//		      System.out.println(obj.getAddress());
//		      System.out.println(obj.getName());
		   
		 cba.setbalance(1000);
		 cba.setdeposit(1000);
		 
		   System.out.println(cba.getbalance());
		   System.out.println(cba.getdeposit());
		   System.out.println(cba.getdebit());
		   
		   
		   SavingsBankAccount sba=new SavingsBankAccount();
		   
		   System.out.println(sba.getBalance());
		   System.out.println(sba.getDeposit());
		   System.out.println(sba.getDebit());
		   System.out.println(sba.getInterest());
		      
		    }

}
