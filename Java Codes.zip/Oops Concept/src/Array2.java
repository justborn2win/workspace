
public class Array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[]={10,6,9,2,3,1,5};
		int b1=0;
		int b2=0;
		int s1=5;
		int s2=5;
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>b1)
			{	
				b2=b1;
				b1=a[i];	
				
			}
			else if(a[i]>b2)
			{
				b2=a[i];
			
			}	
		}
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<s1)
			{	
				s2=s1;
				s1=a[i];
				
				
			}
			else if(a[i]<s2 && a[i]!=s1)
			{
				s2=a[i];
			
			}	
			
		}
		sum=((b1+b2)-(s1+s2));
		System.out.println(sum);
		
		
		
	}

}
