
public class TestBuilding {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Building b=new Building();
		b.setBuildingDetails("Prestige", 5, 10);
		
		Room r1=new Room();
		r1.setRoomDetails("R001", 250, true, true, 25000.00);
		
		Room r2=new Room();
		r2.setRoomDetails("R002", 300, false, true, 20000.00);
		
		Room r3=new Room();
		r3.setRoomDetails("R003", 350, true, false, 22000.00);
		
		Room r4=new Room();
		r4.setRoomDetails("R004", 400, false, true, 23000.00);
		
		Room r5=new Room();
		r5.setRoomDetails("R005", 450, false, false, 15000.00);
		
		Room rooms[]=new Room[5];
		rooms[0]=r1;
		rooms[1]=r2;
		rooms[2]=r3;
		rooms[3]=r4;
		rooms[4]=r5;
		b.rooms=rooms;
//		
//		for(int i=0;i<rooms.length;i++)
//		{
//			if(rooms[i].hasDisplay==true)
//			{
//				System.out.println("Room: "+rooms[i].nameOfTheRoom+" have displays");
//			}
//
//		}
		
		Employee e1=new Employee();
		e1.setEmployeeDetails("UST01", "Jesvin", "Joy", 23, "For Merck");
		
		Employee e2=new Employee();
		e2.setEmployeeDetails("UST02", "Sreenath", "Raju", 25, "For Merck");
		
		Employee e3=new Employee();
		e3.setEmployeeDetails("UST03", "Vaisakh", "V", 25, "For Merck");
		
		Employee e4=new Employee();
		e4.setEmployeeDetails("UST04", "Chachamma", "Chachappan", 23, "For Merck");
		
		Employee e5=new Employee();
		e5.setEmployeeDetails("UST05", "Chachappan", "Pillai", 23, "For Merck");
		
		Employee employees[]=new Employee[5];
		employees[0]=e1;
		employees[1]=e2;
		employees[2]=e3;
		employees[3]=e4;
		employees[4]=e5;
		b.employees=employees;
		
		b.printBuildingDetails();
//		for(int i=0;i<rooms.length;i++)
//		{
//			rooms[i].printRoomWithDisplayDetails();
//		}
//		

	}

}
