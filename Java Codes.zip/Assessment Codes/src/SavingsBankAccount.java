import java.io.*;

public class SavingsBankAccount implements Serializable {

	double balance;
	double debit;
	double deposit;
	double interest;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getDebit() {
		return debit;
	}

	public void setDebit(double debit) {
		this.debit = debit;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getInterest() {
		return interest;
	}

	public void setInterest(double interest) {
		this.interest = interest;
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {

		SavingsBankAccount sba = new SavingsBankAccount();

		sba.setBalance(500);
		sba.setDeposit(1000);
		sba.setDebit(500);
		sba.setInterest(200);

		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(
				"bank.txt"));

		oos.writeObject(sba);

	}

}
