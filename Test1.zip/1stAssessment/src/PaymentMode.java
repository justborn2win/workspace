
public class PaymentMode implements Flipkartoon {
	
	String modeOfPayment;

	
	public PaymentMode(String modeOfPayment) {
		super();
		this.modeOfPayment = modeOfPayment;
	}
	
	public void discount()
	{
		if(modeOfPayment.equalsIgnoreCase("NetBanking"))
		{
			double pay=amountPayable-(amountPayable*0.05);
			System.out.println("You have 2% discount and you have to pay:"+pay);
			System.out.println();
		}
		else if(modeOfPayment.equalsIgnoreCase("DebitCard"))
		{
			System.out.println("You have no discount");
			System.out.println();
		}
		else if(modeOfPayment.equalsIgnoreCase("CreditCard"))
		{
			double pay=amountPayable-(amountPayable*0.02);
			System.out.println("You have 2% discount and you have to pay:"+pay);
			System.out.println();
		}
	}
	
	

}
