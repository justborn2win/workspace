import java.io.*;
public class TestChannel {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException{
		Channel channelOne=new Channel();
		channelOne.setChannelDetails("Asianet", 1);  
		//setting channel details by invoking setChannelDetails method
		
		InputStreamReader inReader=new InputStreamReader(System.in);
		BufferedReader inBuffer=new BufferedReader(inReader);
		//calling input reader
		
		
		Program channelPrograms[]=new Program[2]; //creating an array for many programs
		Viewers viewersFeedBack[]=new Viewers[2]; //creating an array for many programs
		
		for(int i=0;i<channelPrograms.length;i++)
		{
			System.out.println("Enter program name:");
			String programName=inBuffer.readLine();
			//taking program name as input from the user
			
			System.out.println("Type of program:");
			String typeOfProgram=inBuffer.readLine();
			//taking program type as input from the user
			
			Program program1=new Program();
			program1.setProgramDetails(programName, typeOfProgram);
			//setting program details in the object by invoking setProgramDetails method
			channelPrograms[i]=program1;
			
			channelOne.chPrograms=channelPrograms;
			
		}
		
		
		
		for(int i=0;i<viewersFeedBack.length;i++)
		{
			System.out.println("Enter Viewer name:");
			String viewerName=inBuffer.readLine();
			//taking viewer name as input from the user
			
			System.out.println("Email id:");
			String eId=inBuffer.readLine();
			//taking viewer email id as input from the user
			
			System.out.println("Feedback for:");
			String feedbackFor=inBuffer.readLine();
			//taking feedback type as input from the user
			
			System.out.println("Feedback Message:");
			String feedbackMessage=inBuffer.readLine();
			//taking feedback message as input from the user
		
			
			
			Viewers viewersFB=new Viewers();
			viewersFB.setViewerFeedbackDetails(viewerName, eId, feedbackFor, feedbackMessage);
			//setting feedback details in the object by invoking setViewerFeedbackDetails method
			
			
			viewersFeedBack[i]=viewersFB;
			channelOne.chViewers=viewersFeedBack;
			
					
		}
			
			channelOne.printChannelDetails(); 
			
			
			
			

		//printing channel details by invoking printChannelDetails
		
//		for(int i=0;i<channelOne.chPrograms.length;i++)
//		{
//			System.out.println();
//			channelOne.chPrograms[i].printProgramDetails();
//			//printing program details by invoking printProgramDetails
//			System.out.println();
//		}
		
//		for(int i=0;i<channelOne.chViewers.length;i++)
//		{
//			System.out.println();
//			channelOne.chViewers[i].printViewerFeedbackDetails();
//			//printing program details by invoking printViewerFeedbackDetails
//			System.out.println();
//		}
//		
//		System.out.println("Which feedback you want to view? ");
//		for(int i=0; i<channelOne.chViewers.length;i++)
//		{
//			String searchFB=inBuffer.readLine();
//			if(channelOne.chViewers[i].viewerFeedbackIsFor.equalsIgnoreCase(searchFB))
//			{
//				channelOne.chViewers[i].printViewerFeedbackDetails();
//			}
//			else
//			{
//				System.out.println("Sorry no such feedback");
//				break;
//			}
//			
			//checking feedback type
			
		
//		}
		
		 	
	}

}
