import java.io.*;
public class Employee {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		int i=0;
		while(true)
		{
			System.out.println("1.Add an employee:");
			System.out.println("2.View all employees");
			System.out.println("3.View the employees by last name");
			System.out.println("4.Quit");
			System.out.println("==========================");
			System.out.println("Enter your choice:");
			int choice=0;
			try
			{
				choice=Integer.parseInt(br.readLine());
			}
			catch(NumberFormatException e)
			{
				System.out.println("Please enter a valid number");
			}
			
			switch(choice)
			{
			case 1:
				{
					FileWriter fw=new FileWriter("Employees.txt",true);
					BufferedWriter bw=new BufferedWriter(fw);
					System.out.println("Enter employee id: ");
					String id=br.readLine();
					System.out.println("Enter First name: ");
					String fname=br.readLine();
					System.out.println("Enter last name: ");
					String lname=br.readLine();
					System.out.println("Enter employee salary:");
					int sal=Integer.parseInt(br.readLine());
					bw.write(id+",");
					bw.write(fname+",");
					bw.write(lname+",");
					bw.write(sal+",");
					bw.newLine();
					bw.close();
					fw.close();
					break;
				}
			case 2:
			{
				FileReader fr=new FileReader("Employees.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				System.out.println("=========Employee Details:==========");
				while(line!=null)
				{
					String arr[]=line.split(",");
					if(arr!=null && arr.length>1)
					{	
							System.out.println("Employee id: "+arr[0]);
							System.out.println("First name: "+arr[1]);
							System.out.println("Last name: "+arr[2]);
							System.out.println("Employee salary: "+arr[3]);
							System.out.println();
					}
					
					line=br1.readLine();
				}
				br1.close();
				fr.close();
				break;
			}
			case 3:
			{
				FileReader fr=new FileReader("Employees.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				
				while(line!=null)
				{
					
					String arr[]=line.split(",");
					if(arr!=null && arr.length>1 )
					{
						System.out.println("Employee first name: "+arr[1]);
					}
					
					line=br1.readLine();
				}
				br1.close();
				fr.close();
				break;
			}
			case 4:
			{
				  System.out.println("Thank you");
                  System.exit(0);
			}
			 default:
                 System.out.println("Enter a valid number");
				
			}
		}
		

	}

}
