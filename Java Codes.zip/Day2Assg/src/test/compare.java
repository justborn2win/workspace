package test;

public interface compare {
	double x=0; 
	double y=0;
	public void max(double x, double y);
}
