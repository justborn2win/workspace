import java.util.*;
import java.io.*;
public class Iterator1 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		HashMap hm=new HashMap();
		
		hm.put(1, "Sachin");
		hm.put(2, "Dhoni");
		hm.put(3, "Kohli");
		hm.put(4, "Prasad");
		hm.put(5, "Ashwin");
		hm.put(6, "Raina");
		hm.put(7, "Azhar");
		hm.put(8, "Sreesanth");
		
		
		Set keys=hm.keySet();
		
		Iterator it=keys.iterator();
		
		while (it.hasNext())
		{
			int key=(Integer)it.next();
			String playerName=(String)hm.get(key);
			System.out.println(key+":"+playerName);
		}


	}

}
