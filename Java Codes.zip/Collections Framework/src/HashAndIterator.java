import java.util.*;
import java.io.*;
public class HashAndIterator {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		HashMap hm=new HashMap();
		
		Employee e1=new Employee();
		e1.employeeId=1;
		e1.employeeName="Jesvin";
		
		Employee e2=new Employee();
		e2.employeeId=22;
		e2.employeeName="Sreenath";
		
		Employee e3=new Employee();
		e3.employeeId=3;
		e3.employeeName="Vaisakh";
		
		Employee e4=new Employee();
		e4.employeeId=4;
		e4.employeeName="Keith";
		
		Employee e5=new Employee();
		e5.employeeId=5;
		e5.employeeName="Abhirami";
		
		Employee e6=new Employee();
		e6.employeeId=6;
		e6.employeeName="Hari";
		
		Employee e7=new Employee();
		e7.employeeId=7;
		e7.employeeName="Fihad";
		
		Employee e8=new Employee();
		e8.employeeId=8;
		e8.employeeName="Eliza";
		
		Employee e9=new Employee();
		e9.employeeId=9;
		e9.employeeName="Nikhil";
		
		Employee e10=new Employee();
		e10.employeeId=55;
		e10.employeeName="Jackson";
		
		hm.put(1, e1);
		hm.put(2, e2);
		hm.put(3, e3);
		hm.put(4, e4);
		hm.put(5, e5);
		hm.put(6, e6);
		hm.put(7, e7);
		hm.put(8, e8);
		hm.put(9, e9);
		hm.put(10, e10);
		
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		System.out.println("Enter employee ID");
		int eid=Integer.parseInt(br.readLine());
		
		
		Set keys=hm.keySet();
		Iterator it=keys.iterator();
		
		while(it.hasNext())
		{
			int key=(Integer)it.next();
			Employee emp1=(Employee)hm.get(key);
			
			int empid=emp1.employeeId;
			
			if(eid==empid)
			{
				String employeeName=emp1.employeeName;
				System.out.println(eid+":"+employeeName);
			}
			
		}
		
		
		
		

	}

}
