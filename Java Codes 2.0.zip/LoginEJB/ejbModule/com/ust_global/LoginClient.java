package com.ust_global;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class LoginClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		MyUserEJBRemote mue=(MyUserEJBRemote) ctx.lookup("MyUserEJB/remote");
		
//		boolean found=mue.loginUser("Jesvin", "Jesvin");
//		
//		if(found==true)
//		{
//			System.out.println("Valid user");
//		} 
//		else
//		{
//			System.out.println("Invalid user");
//		}
		
		MyUsers user1=new MyUsers();
		user1.userName="Eliza";
		user1.password="Eliza";
		mue.signUpUser(user1);
		
		
		
		
	
	}

}
