
public class Products {
		
		String productType;
		String brandName;
		double price;
		double quantity;
		double totalPrice;
		double discount;
		double netPrice;
		
		public Products(String productName, String brandName, double price,
				double quantity) {
			super();
			this.productType = productName;
			this.brandName = brandName;
			this.price = price;
			this.quantity = quantity;
		}

		public String calculateDiscount()
		{
				totalPrice=quantity*price;
				discount=totalPrice*0.10;
				System.out.println("10% Discount for "+productType+" is Rs."+discount);
		 	return productType;
		}
		
		public String calculateDiscount(String productType)
		{
				totalPrice=quantity*price;
				discount=totalPrice*0.25;
				System.out.println("25% Discount for "+productType+" is Rs."+discount);
		 	return productType;
		}
		
		public void printPurchaseDetails()
		{
			System.out.println("Product name:"+brandName);
			System.out.println("Type:"+productType);
			System.out.println("Quantity:"+quantity);
			System.out.println("Total price:"+totalPrice);
			System.out.println("Discount:"+discount);
			System.out.println("Net price:"+(totalPrice-discount));
			System.out.println();
		}
}
