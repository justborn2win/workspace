import java.io.*;

public class CurrentBankAccount implements Serializable {

	public double balance;
	double debit;
	double deposit;

	public double getbalance() {
		return balance;
	}

	public double setbalance(double balance) {
		return this.balance = balance;
	}

	public double getdeposit() {
		return deposit;
	}

	public double setdeposit(double deposit) {
		return this.deposit = balance + deposit;
	}

	public double getdebit() {
		return deposit;
	}

	public double setdebit(double debit) {
		return this.debit = balance - debit;
	}

	public static void main(String[] args) throws Exception {

		CurrentBankAccount cba = new CurrentBankAccount();

		cba.setbalance(500);
		cba.setdeposit(2000);
		cba.setdebit(1000);

		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("bank.txt"));

		oos.writeObject(cba);

	}

}
