
public class increment_decrement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5;
		int b=a++;
		System.out.println(b);
		int c = ++a;
		System.out.println(c);
		
	}

}
