
class MinAndMax {
	
	public double findMinValue(double x[])
	{
		double min=x[0];
		for(int i=0;i<x.length;i++)
		{
			if(x[i]<min)
			{
				min=x[i];
				
			}
		}
		System.out.println(min);
		return min;
	}
	
	public double findMaxValue(double x[])
	{
		double max=0;
		for(int i=0;i<x.length;i++)
		{
			if(x[i]>max)
			{
				max=x[i];
				
			}
			
		}
		System.out.println(max);
		return max;
	}
}
