import java.io.*;

public class BankException extends Exception{
	
	public static void whyIamGettingThisMessage()
	{
		System.out.println("You dont have sufficient amount balance. Please enter a valid amount");
	}
	
	public static void withDraw(Double d)throws BankException, NumberFormatException, IOException
	{
		String nameOfTheCustomer="Jesvin Joy Koshy";
		double accountNumber=3330314;
		double balanceAmount=1000;
		double money=0;
		int ch=0;
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your choice:");
		ch=Integer.parseInt(br.readLine());

		switch(ch)
		{	
		case 1:
			System.out.println("Enter amount you want to Deposit");
			money=Double.parseDouble(br.readLine());
			balanceAmount=balanceAmount+money;
			System.out.println("The balance Amount is: "+ balanceAmount);
			break;
		case 2:
			System.out.println("Enter amount you want to withdraw:");
			money=Double.parseDouble(br.readLine());
			if(money<=balanceAmount)
			{
				System.out.println("You have withdrawn: "+money);
				System.out.println("Balance amount is: "+(balanceAmount-money));
			}
			else if(money>balanceAmount)
			{
				BankException ba=new BankException();
				throw ba;
			}
			break;
		case 3:
			System.out.println("The balance amount is: "+balanceAmount);
			break;
		case 4:
			System.out.println("Thank you for using the system");
		}
	}
}