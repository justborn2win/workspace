package com.ust_global.user;

import java.sql.SQLException;
import java.sql.Date;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/*private long ticketNumber;----x
		private String userName;-
		private String eventId;
		private String eventName;-
		private long selectedDate;-
		private String seatNumber;-
		*/

public class TestTicket 
{
	public static void main(String[] args) throws SQLException, NamingException 
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		//dd-mon-yy
		//Date date=new java.sql.Date(new java.util.Date(2016,08,17));
		
		java.util.Date utilDate=new java.util.Date(2016,8,18);
		long ms=utilDate.getTime();
		java.sql.Date sqlDate=new Date(ms);
		
		
		
		TicketBeanRemote ticketRemote=(TicketBeanRemote) ctx.lookup("TicketBean/remote");
//		Ticket ticket = new Ticket();
//		ticket.setTicketNumber(2);
//		ticket.setUserName("fihadh");
//		ticket.setEventName("Reception");
//		ticket.setSeatNumber("F15");
//		ticket.setEventId("R41");
//		ticket.setSelectedDate(sqlDate);
//		ticket.setTicketPrice(1500.00);
//		ticket.setNoOfSeats(2);
//		ticketRemote.createTicket(ticket);
		List<Ticket> allTicket=ticketRemote.viewAll();
		for (Ticket tckt:allTicket) 
		{
			System.out.println(tckt.getEventId()+","+tckt.getEventName()+","+tckt.getSeatNumber()+","+tckt.getSelectedDate()+","+tckt.getTicketNumber()+","+tckt.getUserName());
		}
		
	}
}
