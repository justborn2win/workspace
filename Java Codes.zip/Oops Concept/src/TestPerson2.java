
public class TestPerson2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person2 p=new Person2();
		p.setPersonDetails("Jesvin", 23);
		p.printDetails();

	}

}
