package com.ust_global;

public class TVSwitchOff implements Command{
	TV tv;
	
	void TVSwitchoff(TV tv)
	{
		this.tv=tv;
	}

	@Override
	public void execute() {
		tv.switchOff();
		
	}
	
	
}
