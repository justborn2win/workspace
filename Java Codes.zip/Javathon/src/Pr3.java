
public class Pr3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20;
		int div=b/a;
		System.out.println(div);


	}

}
