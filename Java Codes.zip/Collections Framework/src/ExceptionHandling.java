
public class ExceptionHandling extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public static void shop(String Product) throws ExceptionHandling{
	/**
	 * @param args
	 * @throws IOException 
	 */
		if(Product.equalsIgnoreCase("Laptop"))
				{
					System.out.println("HP lap, 4GB DDR3 RAM, 500GB HDD");
				}
		else if(Product.equalsIgnoreCase("Desktop"))
		{
			System.out.println("Dell Desktop, 8GB DDR3 RAM, 1TB HDD");
		}
		else
		{
			ExceptionHandling n=new ExceptionHandling();
			throw n;
		}
		
	}

}
