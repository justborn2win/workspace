import java.util.*;
public class Scanner1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		
		System.out.println("Enter a number");
		int no=scn.nextInt();
		System.out.println("Enter another number");
		int no1=scn.nextInt();
		
		int tot=no+no1;
		System.out.println("The sum is "+tot);
	}

}
