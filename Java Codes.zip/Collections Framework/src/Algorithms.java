import java.util.*;
import java.io.*;
public class Algorithms {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector v=new Vector();
		v.add("Jesvin");
		v.add("Joy");
		v.add("Koshy");
		
		
		System.out.println(v);
		
		Collections.rotate(v, -2);
		System.out.println(v);

	}

}
