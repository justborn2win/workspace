package com.ust_global;


import javax.ejb.Remote;

@Remote
public interface MyUserEJBRemote {
	public boolean loginUser(String name, String password);
	public void signUpUser(MyUsers newUser);
}
