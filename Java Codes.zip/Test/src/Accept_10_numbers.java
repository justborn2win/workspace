
public class Accept_10_numbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int small=Integer.parseInt(args[1]);
		  for (int i=0;i<args.length;i++)
		  {
		   if(small >Integer.parseInt(args[i]))
		    small=Integer.parseInt(args[i]);  
		  }

		 System.out.println(small);
		 }

	}


