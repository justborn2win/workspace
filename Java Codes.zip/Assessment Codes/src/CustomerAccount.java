import java.io.*;

class CustomerAccount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String custName;
	int accNo;
	double balance;
	String typeOfAccount;
	CustomerAccount c[];

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTypeOfAccount() {
		return typeOfAccount;
	}

	public void setTypeOfAccount(String typeOfAccount) {
		this.typeOfAccount = typeOfAccount;
	}
	

	public CustomerAccount(String custName, int accNo, double balance,
			String typeOfAccount) {
		super();
		this.custName = custName;
		this.accNo = accNo;
		this.balance = balance;
		this.typeOfAccount = typeOfAccount;
	}
	
	public void diplayAllDetails()
	{
		System.out.println("Account holder name: "+custName);
		System.out.println("Account number: "+accNo);
		System.out.println("Balance: "+balance);
		System.out.println("Account type: "+typeOfAccount);
		
	}
}
