
public class TestSales {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Customer j=new Customer();
		
		j.custId=1;
		j.custFirstName="Jesvin";
		j.custLastName="Joy";
		
		Customer s=new Customer();
		
		s.custId=2;
		s.custFirstName="Sreenath";
		s.custLastName="Raju";
		
		Customer v=new Customer();
		
		v.custId=3;
		v.custFirstName="Vaisakh";
		v.custLastName="Viswanath";
		
		Sales s1=new Sales();
		s1.setSalesDetails(10, 600, j);
		
		
		Sales s2=new Sales();
		s2.setSalesDetails(20, 500, s);
		
		Sales s3=new Sales();
		s3.setSalesDetails(30, 1000, v);
		
		s1.printSalesDetails();
		s2.printSalesDetails();
		s3.printSalesDetails();
		
		
		
	}

}
