package com.ust_global;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class MyUserEJB
 */
@Stateless
public class MyUserEJB implements MyUserEJBRemote {

    /**
     * Default constructor. 
     */
    public MyUserEJB() {
        // TODO Auto-generated constructor stub
    }
    @PersistenceContext(name="MyUsersUnit")
    private EntityManager entityManager;
    
	@Override
	public boolean loginUser(String name,String password) {
		MyUsers user1=entityManager.find(MyUsers.class, name);
		
		boolean registeredUser=false;
		
		if(user1!=null)
		{
			if(user1.userName.equals(name) && user1.password.equals(password))
			{
				registeredUser=true;
			}
		}
		
		return registeredUser;
	}

	@Override
	public void signUpUser(MyUsers newUser) {
		entityManager.persist(newUser);
	}

}
