package com.ust_global;

import java.util.Properties;
import javax.jms.*;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class MDBClient {
	public static void main(String[] args) throws NamingException, JMSException {
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		Queue queue = (Queue) ctx.lookup("/queue/GuruQueue");
		QueueConnectionFactory factory = (QueueConnectionFactory) ctx
				.lookup("ConnectionFactory");
		QueueConnection connection = factory.createQueueConnection();
		QueueSession session = connection.createQueueSession(false,
				QueueSession.AUTO_ACKNOWLEDGE);
		QueueSender sender = session.createSender(queue);
		ObjectMessage objectMessage = session.createObjectMessage("Hello");
		sender.send(objectMessage);
		System.out.println("Message successfully sent");
	}
}