
public class RepeatingElement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int marks[]={75,75,100,66,78,75,99,75,1,75};
		int c=0;
		for (int i=0; i<marks.length; i++)
		{
			if (marks[i]==75)
				c=c+1;			
		}
		System.out.println(c);

	}

}
