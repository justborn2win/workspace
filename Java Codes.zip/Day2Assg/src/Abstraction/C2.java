package Abstraction;

public abstract class C2 extends Parent{

	void m2() {
		// TODO Auto-generated method stub
		System.out.println("I am M2 from class c2");
	}

	abstract void m();
}
