
public class Sales {
		int saleId;
		double saleAmount;
		Customer customer;
		
	public void setSalesDetails(int sid, double sAmount, Customer cust){
		saleId=sid;
		saleAmount=sAmount;
		customer=cust;
	}
	
	public void printSalesDetails(){
		
		if(saleAmount>500)
			{
				System.out.println("Highest sales is done by: ");
				System.out.println("First name: "+customer.custFirstName);
				System.out.println("Last name: "+customer.custLastName);
			}

	}
}
