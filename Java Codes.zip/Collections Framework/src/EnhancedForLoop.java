import static java.lang.Math.*;
public class EnhancedForLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String countries[]={"India","USA","Mexico","Germany"};
		for(String name:countries)
			System.out.println(name);
		
		
		System.out.println(PI);
	}

}
