
public class Series_4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for(int i=4;i<=32;i=i+4)
		{
			System.out.println(i);
		}

	}

}
