package com.ust_global;


	public class Hello {
		public String sayHello(String name){
		return "Welcome to UST Global "+name;
}
}