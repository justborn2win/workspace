
public class Quadratic_equation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a = 2,b = 6;
		int equation;
		equation=(a*a)+(b*b)+(2*a*b);
		System.out.println(equation);
	}

}
