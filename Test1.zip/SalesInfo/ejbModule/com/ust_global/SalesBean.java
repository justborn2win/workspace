package com.ust_global;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class SalesBean
 */
@Stateless
public class SalesBean implements SalesBeanRemote {

    /**
     * Default constructor. 
     */
    public SalesBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="SalesUnit")
    private EntityManager entityManager;

	@Override
	public void addSales(Sales s) {
		entityManager.persist(s);		
	}

	@Override
	public Sales searchSales(int salesId) {
		Sales s1=entityManager.find(Sales.class, salesId);
		if(s1!=null)
		{
			s1.getSalesID();
			s1.getSalesDate();
			s1.getAmount();
			s1.getCity();
		}
		else
		{
			s1=null;
		}
		return s1;
	}

	@Override
	public List<Sales> showAllSales() {
		List<Sales> allSales=entityManager.createQuery("FROM SALES").getResultList();
		return allSales;
	}

	@Override
	public Sales updateSales(int salesId, String salesDate, double amount,
			String city) {
		Sales s2=entityManager.find(Sales.class, salesId);
		if(s2!=null)
		{
			s2.setSalesDate(salesDate);
			s2.setAmount(amount);
			s2.setCity(city);
			entityManager.merge(s2);
		}
		else
		{
			s2=null;
		}
		return s2;
	}

	@Override
	public Sales deleteSales(int salesId) {
		Sales s3=entityManager.find(Sales.class, salesId);
		if(s3!=null)
		{
			entityManager.remove(s3);
		}
		else
		{
			s3=null;
		}
		return s3;
	}

}