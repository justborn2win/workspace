
public class CountDown {
	 public CountDown()
	    {
	    } 
	    public static void main(String[] args)
	    {
	        try
	        {
	            System.out.println("Counting down ...");
	            System.out.print("5");
	            Thread.currentThread().sleep(500);
	            System.out.print("\r 4");
	            Thread.currentThread().sleep(500);
	            System.out.print("\r  3");
	            Thread.currentThread().sleep(500);
	            System.out.print("\r   2");
	            Thread.currentThread().sleep(500);
	            System.out.print("\r    1");
	            Thread.currentThread().sleep(500);
	            System.out.println("\rDone!");
	        }
	        catch (Exception ex)
	        {
	        }
	    }}
