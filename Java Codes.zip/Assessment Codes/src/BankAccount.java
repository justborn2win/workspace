import java.io.*;

public class BankAccount {

	/**
	 * @param args
	 * @throws IOException
	 * @throws NumberFormatException
	 */
	public static void main(String[] args) throws NumberFormatException,
			IOException {
		while (true) {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			System.out.println("Options ");
			System.out.println("1) Deposit ");
			System.out.println("2) Display the balance");
			System.out.println("3) Permit withdrawal and update the business");
			System.out.println("4) Check the minimum balance, impose penalty, and update the balance");
			System.out.println("Enter the options: ");
			int option = Integer.parseInt(br.readLine());

			switch (option) {
			case 1:

				FileWriter fw = new FileWriter("bank.txt");
				BufferedWriter bw = new BufferedWriter(fw);
				System.out.println("Enter the accname:");
				String acnme = br.readLine();
				System.out.println("Enter the accno: ");
				String acno = br.readLine();
				System.out.println("enter amount: ");
				double amt = Double.parseDouble(br.readLine());
				double bal = 500.0;
				amt = amt + bal;
				bw.write(acnme + "," + acno + "," + amt);
				bw.newLine();
				bw.close();
				fw.close();
				break;

			case 2:

				FileReader fr = new FileReader("bank.txt");
				BufferedReader br1 = new BufferedReader(fr);
				String line = br1.readLine();

				while (line != null) {

					String arr[] = line.split(",");
					System.out.println("Account name: " + arr[0]);
					System.out.println("Account number is: " + arr[1]);
					System.out.println("The available balance is: " + arr[2]);

					line = br1.readLine();
				}
				fr.close();
				br1.close();
				break;

			case 3:

				FileReader fr1 = new FileReader("bank.txt");
				BufferedReader br2 = new BufferedReader(fr1);
				FileWriter fw1 = new FileWriter("bank.txt", true);
				BufferedWriter bw1 = new BufferedWriter(fw1);
				String line1 = br2.readLine();
				double newBalance=0.0;
				while (line1 != null) {
					System.out.println("Enter Account name: ");
					String acname = br.readLine();
					System.out.println("Account no:");
					String acno1 = br.readLine();
					System.out.println("Amount for withdraw: ");
					double wdrw = Double.parseDouble(br.readLine());
					String arr[] = line1.split(",");
					if(wdrw<Double.parseDouble(arr[2]))
					{
						newBalance = Double.parseDouble(arr[2]) - wdrw;
						System.out.println("The balance is "+newBalance);
					}
					else
					{
						System.out.println("Insufficient balance");
					}
					System.out.println();
					bw1.write(acname + "," + acno1 + "," + newBalance);
					line1 = br2.readLine();
				}

				fr1.close();
				br2.close();
				break;

			case 4:
				FileReader fr2 = new FileReader("bank.txt");
				BufferedReader br3 = new BufferedReader(fr2);
				String line2 = br3.readLine();
				while (line2 != null) {
					String arr[] = line2.split(",");
					double amt1 = Double.parseDouble(arr[2]);
//					System.out.println(amt1);
					if (amt1 < 500) {
						amt = amt1 - 10;
						System.out.println("Due to low balance penality is imposed.");
						System.out.println("Your new Balance is "+amt);
					}
					line2 = br3.readLine();
				}
				break;
			case 5:

				System.out.println("Thank you");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option");

			}

		}

	}

}
