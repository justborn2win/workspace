
public class HelloConsole {

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		System.out.println(args[0]+ " works in " +args[1] );

	}

}
