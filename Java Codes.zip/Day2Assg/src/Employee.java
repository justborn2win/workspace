
public class Employee {
	int empId;
	String empName;
	double empSalary;
	
	
	public void setEmpDetails(int id, String name, double sal)
	{
		empId=id;
		empName=name;
		empSalary=sal;
	}
	public void printEmpDetails()
	{
		System.out.println("Employee id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Salary: "+empSalary);
	}

}
