
public class Rectangle {
	double xCoordinate;
	double yCoordinate;
	
	
	public Rectangle(){     //default constructor
		xCoordinate=5;
		yCoordinate=10;
	}
	
	public Rectangle(double a,double b){ //parameterized constructor
		xCoordinate=a; 
		yCoordinate=b;
	}
	
	public void setX(double x)  // set x coordinate
	{
		xCoordinate=x;
	}
	
	public void setY(double y)  // set y coordinate
	{
		yCoordinate=y;
	}
	
	public double getX()    // get x coordinate
	{
		return this.xCoordinate;
	}
	
	public double getY()   // get y coordinate
	{
		return this.yCoordinate;
	}
	
	
	public void getDimensions() //method to print dimensions
	{
		System.out.println("x-coordinate of the rectangle: "+xCoordinate);
		System.out.println("y-coordinate of the rectangle: "+yCoordinate);
	}
	
	public double getArea()  //method to calculate area
	{
		
		return xCoordinate*yCoordinate;
	}
}
