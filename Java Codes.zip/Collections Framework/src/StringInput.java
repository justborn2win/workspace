import java.io.*;
import java.util.*;
public class StringInput {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		int count=0;
		
		
		for(int i =1; i<10; i++)
		{
			System.out.println("Enter a string");
			String s=br.readLine();
			
			if(s.startsWith("A")||s.startsWith("a"))
				count++;
			
		}
		System.out.println("The number of names that begin with A or a are: "+count);
		
	}

}
