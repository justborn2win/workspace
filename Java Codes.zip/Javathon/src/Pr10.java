
public class Pr10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=10, b=20;
		if(a<b)
		System.out.println(a+" is smaller than "+b);
		else 
			System.out.println(b+" is smaller than "+a);
	}

}
