
public class TestPerson {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p1=new Person();
		p1.name="Jesvin";
		p1.age=23;
		p1.Profession="an Internship Trainee";
		p1.salary=12000;
		
		
		p1.whatIsYourName();
		p1.howOldAreYou();
		p1.whatJobAreYouIn();
		p1.whatIsYourSalary();
		p1.bonus();
		
		
		System.out.println();
		System.out.println();
		
		Person p2=new Person();
		p2.name="Destructo";
		p2.age=555;
		p2.Profession="the God of Destruction";
		p2.salary=99999;
		
		
		p2.whatIsYourName();
		p2.howOldAreYou();
		p2.whatJobAreYouIn();
		p2.whatIsYourSalary();
		p2.bonus();
	}

}
