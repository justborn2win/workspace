package com.ust_global;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SalesServlet
 */
public class SalesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099"); 
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory"); 
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces"); 
		
		
		PrintWriter pw=response.getWriter();
		
		String choice=request.getParameter("choice");
		try {
			Context ctx=new InitialContext(p);
			SalesBeanRemote sbr=(SalesBeanRemote) ctx.lookup("SalesBean/remote");
			
			if(choice.equalsIgnoreCase("add"))
			{
				Sales s1=new Sales();
				
				int id=Integer.parseInt(request.getParameter("salesId"));
				String date=request.getParameter("salesDate");
				double amount=Double.parseDouble(request.getParameter("amount"));
				String city=request.getParameter("city");
				try
				{
					s1.setSalesID(id);
					s1.setSalesDate(date);
					s1.setAmount(amount);
					s1.setCity(city);
					sbr.addSales(s1);
					pw.println("<p>Sucessfully added</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				catch(Exception e)
				{
					pw.println("<p>Existing id....Please use unique id</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				
				
			}
			else if(choice.equalsIgnoreCase("search"))
			{
				int id=Integer.parseInt(request.getParameter("salesId"));
				Sales s1=sbr.searchSales(id);
				if(s1!=null)
				{
					pw.println("<table border=1><tr><th>Sales_Id</th><th>Sales_Date</th><th>Amount</th><th>City</th></tr>");
					pw.println("<tr><td>"+s1.getSalesID()+"</td><td>"+s1.getSalesDate()+"</td><td>"+s1.getAmount()+"</td><td>"+s1.getCity()+"</td></tr>");
					pw.println("</table>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				else
				{
					pw.println("<p>No such record found</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				
			}
			else if(choice.equalsIgnoreCase("showAll"))
			{
				
				List<Sales> allSales=sbr.showAllSales();
				if(allSales.size()>0)
				{
					pw.println("<table border=1><tr><th>Sales_Id</th><th>Sales_Date</th><th>Amount</th><th>City</th></tr>");
					for(int i=0;i<allSales.size();i++)
					{
						pw.println("<tr><td>"+allSales.get(i).getSalesID()+"</td><td>"+allSales.get(i).getSalesDate()+"</td><td>"+allSales.get(i).getAmount()+"</td><td>"+allSales.get(i).getCity()+"</td></tr>");
						
					}
					pw.println("</table>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				else
				{	
					pw.println("No data in database....Please add some data");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				
			}
			else if(choice.equalsIgnoreCase("update"))
			{
				int id=Integer.parseInt(request.getParameter("salesId"));
				String date=request.getParameter("salesDate");
				double amount=Double.parseDouble(request.getParameter("amount"));
				String city=request.getParameter("city");
				
				Sales s1=sbr.updateSales(id, date, amount, city);
				if(s1!=null)
				{
					pw.println("<p>Successfully updated</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				else
				{
					pw.println("<p>No such record found</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				
			}
			else if(choice.equalsIgnoreCase("delete"))
			{
				int id=Integer.parseInt(request.getParameter("salesId"));
				Sales s1=sbr.searchSales(id);
				if(s1!=null)
				{
					sbr.deleteSales(id);
					pw.println("<p>Successfully deleted</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				else
				{
					pw.println("<p>No such record found</p>");
					pw.println("<a href=\"http://localhost:8082/SalesView/Sales.html\">Go Back</a>");
				}
				
				
			}
				
		} 
		catch (NamingException e1) 
		{
			e1.printStackTrace();
		}
		

	}

}
