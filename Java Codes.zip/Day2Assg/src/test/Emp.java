package test;

public class Emp implements compare{

	@Override
	public void max(double x, double y) {
		// TODO Auto-generated method stub
		if(x>y)
			System.out.println(x+" has a larger salary");
		else
			System.out.println(y+" has a larger salary");
	}
	
	
}
