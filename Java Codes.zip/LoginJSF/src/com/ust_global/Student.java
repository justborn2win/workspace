package com.ust_global;

public class Student {

	private String userName;

	private String userpassword;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	public String validate()

	{
		String msg = "";
		if ((this.userName).equalsIgnoreCase((this.userpassword)))
		{
			msg = "success";
		}
		else
		{
			msg = "failure";
		}
		return msg;
	}

}
