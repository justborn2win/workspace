
public class Biggest_no_in_array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int no[]={10,20,30,40,50,60,70,80,90,100};
		int big=0;
		for(int i=0;i<no.length;i++)
		{
			if(no[i]>big);
			{
				big=no[i];
			}
		}
		System.out.println("The biggest number in the array is " +big);


	}



}
