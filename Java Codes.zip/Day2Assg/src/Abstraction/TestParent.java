package Abstraction;

public class TestParent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C3 c=new C3();
		
		c.m();
		c.m1();
		c.m2();
		
		C1 d=new C1();
		d.m1();
		d.m2();
		d.m3();
	}

}
