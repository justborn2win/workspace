import java.io.*;
public class FileHandling2 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		while(true)
		{	
			System.out.println("1.Add books");
			System.out.println("2.Display books");
			System.out.println("3.Display Author");
			System.out.println("4.Exit");
			System.out.println("====================");
			System.out.println("Enter your choice:");
			int a=0;
			try{
				a=Integer.parseInt(br.readLine());
			}
			catch(NumberFormatException e)
			{
				System.out.println("Please enter a valid Number");
				
			}
			
			
			switch(a)
			{
			case 1:
				{
					FileWriter fw=new FileWriter("Books.txt",true);
					BufferedWriter bw=new BufferedWriter(fw);
					System.out.println("Enter Book Title:");
					String title=br.readLine();
					System.out.println("Enter Author");
					String author=br.readLine();
					fw.write(title+",");
					fw.write(author);
					bw.newLine();
					bw.close();
					fw.close();
					break;
				}
			case 2:
			{
				FileReader fr=new FileReader("Books.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				while(line!=null)
				{
					System.out.println(line);
					line=br1.readLine();
				}
				br1.close();
				fr.close();
				break;
			}
			case 3:
			{
				System.out.println("Author names are:");
				FileReader fr=new FileReader("Books.txt");
				BufferedReader br1=new BufferedReader(fr);
				String line=br1.readLine();
				while(line!=null)
				{
					String arr[]=line.split(",");
					if(arr!=null && arr.length>1)
					{
						System.out.println(arr[1]);
					}
					
					line=br1.readLine();
				}
				fr.close();
				br1.close();
				break;
			}
			case 4:
			{
				System.out.println("Thank you for using our facilty");
				System.exit(0);
			}
			default:
                   System.out.println("Enter a valid number");
			
			}
		}

	}

}
