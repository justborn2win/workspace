
public class TestTheatre {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Theatre t1=new Theatre();
		t1.setTheatreDetails("Nataraj", 300, true, true);
		
		Movie m1=new Movie();
		m1.setMovieDetails("Kabali", "Tamil", "Rajinikanth", "Radhika Apte", "Unknown Villian", "3 hours", null);

		Movie m2=new Movie();
		m2.setMovieDetails("Kali", "Malayalam", "Dulquer Salman", "Sai Pallavi", "Chemban Vinod", "2 hours", null);
		
		Movie movies[]=new Movie[2];
		movies[0]=m1;
		movies[1]=m2;
		
		
		
		t1.printTheatreDetails();
		m1.printMovieDetails();
		m2.printMovieDetails();
	}

}
