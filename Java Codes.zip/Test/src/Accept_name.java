
public class Accept_name {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello " +args[0]);

	}

}
