package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface Student1BeanRemote {
	public void addStudent(Student s);
	public Student updateStudent(int id,String name);
	public Student deleteStudent(int id);
	public List<Student> showAllStudent();
	public Student searchStudent(int id);
}
