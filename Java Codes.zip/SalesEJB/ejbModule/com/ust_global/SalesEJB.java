package com.ust_global;

import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class SalesEJB
 */
@Stateless
public class SalesEJB implements SalesEJBRemote {

    /**
     * Default constructor. 
     */
    public SalesEJB() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="SalesUnit")
    EntityManager etyManager;
    
	@Override
	public void totalPrice(int id, double qty) {
		Sales s1=etyManager.find(Sales.class, id);
		s1.setQuantity(qty);
		s1.totalPrice=s1.getQuantity()*s1.getProductPrice();
		
		
	}
    

}
