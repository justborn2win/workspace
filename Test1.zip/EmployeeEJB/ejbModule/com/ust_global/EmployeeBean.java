package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class EmployeeBean
 */
@Stateless
public class EmployeeBean implements EmployeeBeanRemote {

	/**
	 * Default constructor.
	 */
	public EmployeeBean() {
		// TODO Auto-generated constructor stub
	}

	@PersistenceContext(name = "EmployeeUnit")
	private EntityManager entityManager;

	@Override
	public List<MyEmployee> searchEmployees(String employeeManager) {
		@SuppressWarnings("unchecked")
		List<MyEmployee> allEmployees = entityManager.createQuery("FROM MYEMPLOYEE").getResultList();
		List<MyEmployee> employeesList = new ArrayList<MyEmployee>();
		if (!allEmployees.isEmpty()) 
		{
			for (MyEmployee emp : allEmployees)
			{
				if (emp.getEmployeeManager().equalsIgnoreCase(employeeManager)) 
				{
					employeesList.add(emp);
				}
			}
		}
		return employeesList;
	}

}
