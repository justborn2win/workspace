
public class Product {
	String nameOfTheProduct;
	double priceOfTheProduct;
	String offers;
	
	public void setProductDetails(String a, double b, String c)
	{
		nameOfTheProduct=a;
		priceOfTheProduct=b;
		offers=c;
	}
	public void displayProductDetails()
	{
		System.out.println("Name of the product-- "+nameOfTheProduct);
		System.out.println("Price of the product-- "+priceOfTheProduct);
		System.out.println("There is "+offers+ " offers on the product");
		
		
	}

}
