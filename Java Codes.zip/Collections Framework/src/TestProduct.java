import java.io.*;
import java.util.*;

public class TestProduct {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		
		double total=0;
		double average=0;
		double big=0;
		String bigPro="";
		
		HashMap hm=new HashMap();
		
//		while(true)
//		{
			for(int i=1;i<=2;i++)
			{
				Product2 p1=new Product2();
				
				
				try
				{
					System.out.println("Enter id:");
					p1.productId=Integer.parseInt(br.readLine());
					System.out.println("Enter product name:");
					p1.productName=br.readLine();
					System.out.println("Enter price:");
					p1.productPrice=Double.parseDouble(br.readLine());
					System.out.println("Enter discount:");
					p1.productDiscount=br.readLine();
				}
				catch(NumberFormatException e)
				{
					System.out.println("Enter a valid input");
				}
				
				hm.put(i,p1);
				
			}
//		}
		
		
		Set keys=hm.keySet();
		Iterator it=keys.iterator();
		
		while(it.hasNext())
		{
			int k1=(Integer)it.next();
			Product2 h1=(Product2)hm.get(k1);
			total=total+h1.productPrice;
			
			if(h1.productPrice>big)
			{	
				big=h1.productPrice;
				bigPro=h1.productName;
			}
			
		}
		System.out.println("Total price: "+total);
		
		average=total/hm.size();
		System.out.println("Average price: "+average);
		
		System.out.println("Product having highest price :"+bigPro);
		
		
	}

}
