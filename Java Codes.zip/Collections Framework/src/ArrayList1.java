import java.util.*;
public class ArrayList1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList a=new ArrayList(10);
		
		a.add("Bangalore");
		a.add("Mumbai");
		a.add("Chennai");
		a.add("Delhi");

		System.out.println(a);

	}

}
