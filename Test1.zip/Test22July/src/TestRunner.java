import org.junit.*;


public class TestRunner {
	@Test
	public void testPalindrome(){
		PalindromeSequence p=new PalindromeSequence();
		String Arr="Malayala2m";
		double act=p.checkPalindrome(Arr);
		Assert.assertEquals(Arr,act);
		
	}
	
}
