package com.ust_global;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface EmployeeBeanRemote {
	public List<MyEmployee> searchEmployees(String employeeManager);
}
